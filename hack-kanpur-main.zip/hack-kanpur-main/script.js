// Global variables
let map;
let reportMarkers = [];
let isUserLoggedIn = false;
let currentUser = null;
let allReports = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('=== DASHBOARD INITIALIZATION START ===');
    
    // Check if user is logged in
    checkAuthStatus();
    
    // Load reports from MongoDB
    loadReportsFromAPI();
    
    initializeMap();
    setupEventListeners();
    
    // Update auth UI based on current state
    updateAuthUI();
    
    console.log('=== DASHBOARD INITIALIZATION COMPLETE ===');
});

// Check authentication status
async function checkAuthStatus() {
    // Check for saved user from sign-in page
    const savedUser = localStorage.getItem('civic_user');
    if (savedUser) {
        try {
            const user = JSON.parse(savedUser);
            window.isUserLoggedIn = true;
            window.currentUser = user;
            console.log('User logged in from saved session:', user.email);
        } catch (error) {
            console.error('Failed to restore user session:', error);
            localStorage.removeItem('civic_user');
        }
    }
}

// Update authentication UI
function updateAuthUI() {
    const signinLink = document.querySelector('.btn-signin-link');
    const loginBtn = document.getElementById('loginBtn');
    const userInfo = document.getElementById('userInfo');
    
    if (window.isUserLoggedIn && window.currentUser) {
        // Hide sign-in link, show user info
        if (signinLink) signinLink.style.display = 'none';
        if (loginBtn) loginBtn.style.display = 'none';
        
        if (userInfo) {
            userInfo.style.display = 'flex';
            userInfo.innerHTML = `
                <div class="user-avatar">
                    ${window.currentUser.profileImage ? 
                        `<img src="${window.currentUser.profileImage}" alt="Profile" class="avatar-img">` :
                        `<div class="avatar-placeholder">${window.currentUser.email.charAt(0).toUpperCase()}</div>`
                    }
                </div>
                <div class="user-details">
                    <div class="user-email">${window.currentUser.email}</div>
                    <div class="user-wallet">${window.currentUser.wallet?.address?.slice(0, 6)}...${window.currentUser.wallet?.address?.slice(-4)}</div>
                </div>
                <button class="btn-logout" onclick="handleLogout()">
                    <i class="fas fa-sign-out-alt"></i>
                </button>
            `;
        }
    } else {
        // Show sign-in link, hide user info
        if (signinLink) signinLink.style.display = 'flex';
        if (loginBtn) loginBtn.style.display = 'none';
        if (userInfo) userInfo.style.display = 'none';
    }
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('civic_user');
    window.isUserLoggedIn = false;
    window.currentUser = null;
    
    updateAuthUI();
    showNotification('Successfully logged out!', 'success');
    
    // Redirect to sign-in page after a delay
    setTimeout(() => {
        window.location.href = 'signin.html';
    }, 1500);
}

// Load reports from API with fallback
async function loadReportsFromAPI() {
    try {
        console.log('Loading reports from MongoDB...');
        
        // Get reports and statistics
        const [reportsResponse, statsResponse] = await Promise.all([
            api.getReports({ limit: 50, sortBy: 'createdAt', sortOrder: 'desc' }),
            api.getReportStats()
        ]);

        if (reportsResponse.success) {
            allReports = reportsResponse.data.reports;
            console.log('Loaded reports from API:', allReports.length);
            
            // Update UI
            populateRecentActivity();
            addReportMarkers();
        }

        if (statsResponse.success) {
            updateStatisticsFromAPI(statsResponse.data.overview);
        }

    } catch (error) {
        console.error('Failed to load reports from API:', error);
        
        // Show error message
        showNotification('API server not available. Using offline mode.', 'info');
        
        // Fallback to dummy data for demonstration
        loadFallbackData();
    }
}

// Fallback data when API is not available
function loadFallbackData() {
    console.log('Loading fallback dummy data...');
    
    allReports = [
        {
            _id: '1001',
            title: 'Large pothole on Mall Road',
            description: 'Large pothole on Mall Road causing serious traffic issues and vehicle damage',
            category: 'pothole',
            priority: 'high',
            status: 'pending',
            location: {
                address: 'Mall Road, Civil Lines, Kanpur',
                coordinates: [80.3319, 26.4499] // [longitude, latitude] for MongoDB
            },
            reporter: { name: 'Rajesh Kumar' },
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 5,
            downvoteCount: 0,
            commentCount: 2
        },
        {
            _id: '1002',
            title: 'Broken streetlight in residential area',
            description: 'Broken streetlight creating safety concerns in residential area during night hours',
            category: 'streetlight',
            priority: 'medium',
            status: 'in-progress',
            location: {
                address: 'Swaroop Nagar Main Road, Kanpur',
                coordinates: [80.3496, 26.4850]
            },
            reporter: { name: 'Priya Sharma' },
            createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 3,
            downvoteCount: 0,
            commentCount: 1
        },
        {
            _id: '1003',
            title: 'Overflowing garbage bins near market',
            description: 'Overflowing garbage bins near market area attracting pests and creating unhygienic conditions',
            category: 'garbage',
            priority: 'high',
            status: 'resolved',
            location: {
                address: 'Phool Bagh Market, Kanpur',
                coordinates: [80.3318, 26.4609]
            },
            reporter: { name: 'Amit Singh' },
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 8,
            downvoteCount: 1,
            commentCount: 4
        },
        {
            _id: '1004',
            title: 'Water pipeline leakage',
            description: 'Water leakage from main pipeline causing road flooding and water wastage',
            category: 'water',
            priority: 'urgent',
            status: 'pending',
            location: {
                address: 'Kidwai Nagar, Kanpur',
                coordinates: [80.3311, 26.4729]
            },
            reporter: { name: 'Sunita Devi' },
            createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 12,
            downvoteCount: 0,
            commentCount: 6
        },
        {
            _id: '1005',
            title: 'Multiple potholes on GT Road',
            description: 'Multiple potholes on GT Road affecting heavy vehicle movement',
            category: 'pothole',
            priority: 'high',
            status: 'in-progress',
            location: {
                address: 'GT Road, Panki, Kanpur',
                coordinates: [80.2329, 26.4073]
            },
            reporter: { name: 'Vikash Gupta' },
            createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 7,
            downvoteCount: 1,
            commentCount: 3
        }
    ];
    
    // Update UI with fallback data
    populateRecentActivity();
    updateStatistics();
    addReportMarkers();
    
    console.log('Fallback data loaded:', allReports.length, 'reports');
}

// Initialize the map
function initializeMap() {
    // Check if Leaflet library is available and if we're on the dashboard page
    if (typeof L === 'undefined') {
        console.log('Leaflet library not available, skipping map initialization');
        return;
    }
    
    const mapElement = document.getElementById('map');
    if (!mapElement) {
        console.log('Map element not found, skipping map initialization');
        return;
    }
    
    console.log('Initializing map...');
    
    // Initialize map centered on Kanpur, Uttar Pradesh, India
    map = L.map('map').setView([26.4499, 80.3319], 12);
    
    console.log('Map created, adding tile layer...');
    
    // Add dark tile layer for dark mode
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '© OpenStreetMap contributors, © CARTO',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);
    
    console.log('Tile layer added, map initialization complete');
    
    // Add sample markers
    addReportMarkers();
}

// Add markers for reports on the map
function addReportMarkers() {
    if (!map) {
        console.log('❌ Map not initialized');
        return;
    }
    
    if (!allReports || allReports.length === 0) {
        console.log('❌ No reports available to display on map');
        return;
    }
    
    // Clear existing markers first
    reportMarkers.forEach(marker => {
        map.removeLayer(marker);
    });
    reportMarkers = [];
    
    console.log('🗺️ Adding markers for', allReports.length, 'reports to map');
    
    let markersAdded = 0;
    let markersSkipped = 0;
    
    // Group reports by coordinates to handle overlapping markers
    const locationGroups = new Map();
    
    allReports.forEach((report, index) => {
        // Handle both API format and legacy format
        const coordinates = report.location?.coordinates || report.coordinates;
        const reportType = report.category || report.type;
        const reportStatus = report.status;
        const reportTitle = report.title || `Report ${index + 1}`;
        
        console.log(`📍 Processing report ${index + 1}:`, {
            title: reportTitle,
            coordinates: coordinates,
            status: reportStatus,
            type: reportType
        });
        
        if (coordinates && Array.isArray(coordinates) && coordinates.length === 2) {
            // Validate coordinates are numbers
            const lng = parseFloat(coordinates[0]);
            const lat = parseFloat(coordinates[1]);
            
            if (isNaN(lng) || isNaN(lat)) {
                console.log(`❌ Invalid coordinates for report "${reportTitle}":`, coordinates);
                markersSkipped++;
                return;
            }
            
            // Validate coordinate ranges
            if (lng < -180 || lng > 180 || lat < -90 || lat > 90) {
                console.log(`❌ Coordinates out of valid range for report "${reportTitle}":`, { lng, lat });
                markersSkipped++;
                return;
            }
            
            // Create a location key for grouping
            const locationKey = `${lat.toFixed(6)},${lng.toFixed(6)}`;
            
            if (!locationGroups.has(locationKey)) {
                locationGroups.set(locationKey, {
                    lat: lat,
                    lng: lng,
                    reports: []
                });
            }
            
            locationGroups.get(locationKey).reports.push(report);
            
        } else {
            console.log(`❌ Invalid or missing coordinates for report "${reportTitle}":`, coordinates);
            markersSkipped++;
        }
    });
    
    console.log(`📊 Found ${locationGroups.size} unique locations for ${allReports.length} reports`);
    
    // Create markers for each location group
    locationGroups.forEach((locationGroup, locationKey) => {
        const { lat, lng, reports } = locationGroup;
        const leafletCoords = [lat, lng];
        
        try {
            if (reports.length === 1) {
                // Single report at this location
                const report = reports[0];
                const markerColor = getMarkerColor(report.status);
                const icon = getReportIcon(report.category || report.type, markerColor);
                
                const marker = L.marker(leafletCoords, { icon: icon })
                    .addTo(map)
                    .bindPopup(createSingleReportPopup(report), {
                        maxWidth: 350,
                        className: 'custom-popup'
                    });
                
                reportMarkers.push(marker);
                markersAdded++;
                
                console.log(`✅ Single marker added at [${lat}, ${lng}] for: "${report.title || 'Untitled'}"`);
                
            } else {
                // Multiple reports at this location - create clustered marker
                const primaryReport = reports[0]; // Use first report for primary display
                const markerColor = '#9b59b6'; // Purple color for clustered markers
                
                // Create clustered marker icon with count
                const clusterIcon = L.divIcon({
                    html: `<div style="background-color: ${markerColor}; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.4); position: relative;">
                               <i class="fas fa-layer-group" style="color: white; font-size: 14px;"></i>
                               <div style="position: absolute; top: -8px; right: -8px; background: #e74c3c; color: white; border-radius: 50%; width: 20px; height: 20px; display: flex; align-items: center; justify-content: center; font-size: 11px; font-weight: bold; border: 2px solid white;">
                                   ${reports.length}
                               </div>
                           </div>`,
                    iconSize: [35, 35],
                    className: 'cluster-marker-wrapper',
                    iconAnchor: [17.5, 17.5],
                    popupAnchor: [0, -17.5]
                });
                
                const marker = L.marker(leafletCoords, { icon: clusterIcon })
                    .addTo(map)
                    .bindPopup(createClusteredReportPopup(reports, lat, lng), {
                        maxWidth: 400,
                        className: 'custom-popup cluster-popup'
                    });
                
                reportMarkers.push(marker);
                markersAdded++;
                
                console.log(`✅ Clustered marker added at [${lat}, ${lng}] for ${reports.length} reports`);
            }
            
        } catch (error) {
            console.error(`❌ Error creating marker at [${lat}, ${lng}]:`, error);
            markersSkipped++;
        }
    });
    
    console.log(`🎯 Map markers summary:`);
    console.log(`   ✅ Successfully added: ${markersAdded} markers`);
    console.log(`   ❌ Skipped (invalid coords): ${markersSkipped} reports`);
    console.log(`   📊 Total reports processed: ${allReports.length}`);
    console.log(`   📍 Unique locations: ${locationGroups.size}`);
    
    // Fit map to show all markers if we have any
    if (reportMarkers.length > 0) {
        try {
            const group = new L.featureGroup(reportMarkers);
            map.fitBounds(group.getBounds().pad(0.1));
            console.log(`🗺️ Map bounds adjusted to show all ${reportMarkers.length} markers`);
        } catch (error) {
            console.error('Error fitting map bounds:', error);
            // Fallback to Kanpur center
            map.setView([26.4499, 80.3319], 12);
        }
    } else {
        console.log('⚠️ No markers to display, keeping default map view');
        // Center on Kanpur
        map.setView([26.4499, 80.3319], 12);
    }
}

// Create popup content for a single report
function createSingleReportPopup(report) {
    const reportTitle = report.title || 'Untitled Report';
    const reportType = report.category || report.type;
    const reportStatus = report.status;
    
    return `
        <div class="popup-content">
            <div class="popup-header">
                <h4 class="popup-title">
                    <i class="fas ${getCategoryIcon(reportType)}"></i>
                    ${reportTitle}
                </h4>
                <span class="popup-status ${getStatusClass(reportStatus)}">
                    ${formatStatus(reportStatus)}
                </span>
            </div>
            
            <div class="popup-body">
                <div class="popup-section">
                    <h5><i class="fas fa-info-circle"></i> Description</h5>
                    <p class="popup-description">${report.description || 'No description available'}</p>
                </div>
                
                <div class="popup-section">
                    <h5><i class="fas fa-map-marker-alt"></i> Location</h5>
                    <p class="popup-location">${report.location?.address || report.location || 'Location not specified'}</p>
                    <small class="popup-coordinates">
                        Coordinates: ${report.location?.coordinates?.[1]?.toFixed(6) || 'N/A'}, ${report.location?.coordinates?.[0]?.toFixed(6) || 'N/A'}
                    </small>
                </div>
                
                <div class="popup-meta">
                    <div class="popup-meta-item">
                        <i class="fas fa-exclamation-triangle"></i>
                        <span class="popup-priority ${getPriorityClass(report.priority || 'medium')}">
                            ${(report.priority || 'medium').toUpperCase()} Priority
                        </span>
                    </div>
                    
                    <div class="popup-meta-item">
                        <i class="fas fa-user"></i>
                        <span>Reported by: ${getReporterName(report.reporter)}</span>
                    </div>
                    
                    <div class="popup-meta-item">
                        <i class="fas fa-clock"></i>
                        <span>${formatTimeAgo(new Date(report.createdAt || report.timestamp || Date.now()))}</span>
                    </div>
                    
                    ${report.upvoteCount !== undefined ? `
                    <div class="popup-meta-item">
                        <i class="fas fa-thumbs-up"></i>
                        <span>${report.upvoteCount || 0} upvotes</span>
                    </div>
                    ` : ''}
                    
                    ${report.votes ? `
                    <div class="popup-meta-item">
                        <i class="fas fa-thumbs-up"></i>
                        <span>${report.votes.upvotes?.length || 0} upvotes</span>
                    </div>
                    ` : ''}
                </div>
                
                <div class="popup-actions">
                    <button class="popup-btn popup-btn-primary" onclick="viewReportDetails('${report._id || report.id}')">
                        <i class="fas fa-eye"></i> View Details
                    </button>
                    <button class="popup-btn popup-btn-secondary" onclick="shareReport('${report._id || report.id}')">
                        <i class="fas fa-share"></i> Share
                    </button>
                    ${reportStatus === 'pending' ? `
                    <button class="popup-btn popup-btn-vote" onclick="voteOnReportFromMap('${report._id || report.id}')">
                        <i class="fas fa-thumbs-up"></i> Support
                    </button>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
}

// Create popup content for clustered reports (multiple reports at same location)
function createClusteredReportPopup(reports, lat, lng) {
    const statusCounts = {
        pending: reports.filter(r => r.status === 'pending').length,
        'in-progress': reports.filter(r => r.status === 'in-progress').length,
        resolved: reports.filter(r => r.status === 'resolved').length
    };
    
    const categoryCounts = {};
    reports.forEach(report => {
        const category = report.category || report.type || 'other';
        categoryCounts[category] = (categoryCounts[category] || 0) + 1;
    });
    
    const recentReports = reports
        .sort((a, b) => new Date(b.createdAt || b.timestamp || 0) - new Date(a.createdAt || a.timestamp || 0))
        .slice(0, 3);
    
    return `
        <div class="popup-content cluster-popup-content">
            <div class="popup-header">
                <h4 class="popup-title">
                    <i class="fas fa-layer-group"></i>
                    ${reports.length} Reports at this Location
                </h4>
                <span class="popup-coordinates">
                    ${lat.toFixed(6)}, ${lng.toFixed(6)}
                </span>
            </div>
            
            <div class="popup-body">
                <div class="popup-section">
                    <h5><i class="fas fa-chart-pie"></i> Status Summary</h5>
                    <div class="status-summary">
                        ${statusCounts.pending > 0 ? `<span class="status-badge status-pending">${statusCounts.pending} Pending</span>` : ''}
                        ${statusCounts['in-progress'] > 0 ? `<span class="status-badge status-progress">${statusCounts['in-progress']} In Progress</span>` : ''}
                        ${statusCounts.resolved > 0 ? `<span class="status-badge status-resolved">${statusCounts.resolved} Resolved</span>` : ''}
                    </div>
                </div>
                
                <div class="popup-section">
                    <h5><i class="fas fa-tags"></i> Issue Types</h5>
                    <div class="category-summary">
                        ${Object.entries(categoryCounts).map(([category, count]) => 
                            `<span class="category-badge">
                                <i class="fas ${getCategoryIcon(category)}"></i>
                                ${getReportTypeLabel(category)}: ${count}
                            </span>`
                        ).join('')}
                    </div>
                </div>
                
                <div class="popup-section">
                    <h5><i class="fas fa-clock"></i> Recent Reports</h5>
                    <div class="recent-reports">
                        ${recentReports.map(report => `
                            <div class="recent-report-item">
                                <div class="report-title">
                                    <i class="fas ${getCategoryIcon(report.category || report.type)}"></i>
                                    ${report.title || getReportTypeLabel(report.category || report.type)}
                                </div>
                                <div class="report-meta">
                                    <span class="report-status ${getStatusClass(report.status)}">${formatStatus(report.status)}</span>
                                    <span class="report-time">${formatTimeAgo(new Date(report.createdAt || report.timestamp || Date.now()))}</span>
                                </div>
                            </div>
                        `).join('')}
                        ${reports.length > 3 ? `<div class="more-reports">... and ${reports.length - 3} more reports</div>` : ''}
                    </div>
                </div>
                
                <div class="popup-actions">
                    <button class="popup-btn popup-btn-primary" onclick="showAllReportsAtLocation(${lat}, ${lng})">
                        <i class="fas fa-list"></i> View All ${reports.length} Reports
                    </button>
                    <button class="popup-btn popup-btn-secondary" onclick="zoomToLocation(${lat}, ${lng})">
                        <i class="fas fa-search-plus"></i> Zoom Here
                    </button>
                </div>
            </div>
        </div>
    `;
}

// Show all reports at a specific location
window.showAllReportsAtLocation = function(lat, lng) {
    console.log(`Showing all reports at location [${lat}, ${lng}]`);
    
    const locationKey = `${lat.toFixed(6)},${lng.toFixed(6)}`;
    const reportsAtLocation = allReports.filter(report => {
        const coordinates = report.location?.coordinates || report.coordinates;
        if (coordinates && Array.isArray(coordinates) && coordinates.length === 2) {
            const reportLat = parseFloat(coordinates[1]);
            const reportLng = parseFloat(coordinates[0]);
            const reportLocationKey = `${reportLat.toFixed(6)},${reportLng.toFixed(6)}`;
            return reportLocationKey === locationKey;
        }
        return false;
    });
    
    if (reportsAtLocation.length === 0) {
        showNotification('No reports found at this location', 'error');
        return;
    }
    
    // Create detailed modal for all reports at this location
    const modal = document.createElement('div');
    modal.className = 'modal location-reports-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <i class="fas fa-map-marker-alt"></i>
                    ${reportsAtLocation.length} Reports at Location
                </h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="location-info">
                    <p><strong>Coordinates:</strong> ${lat.toFixed(6)}, ${lng.toFixed(6)}</p>
                    <p><strong>Address:</strong> ${reportsAtLocation[0].location?.address || 'Not specified'}</p>
                </div>
                
                <div class="reports-list">
                    ${reportsAtLocation.map((report, index) => `
                        <div class="report-card">
                            <div class="report-header">
                                <h4>
                                    <i class="fas ${getCategoryIcon(report.category || report.type)}"></i>
                                    ${report.title || `Report ${index + 1}`}
                                </h4>
                                <span class="status-badge ${getStatusClass(report.status)}">
                                    ${formatStatus(report.status)}
                                </span>
                            </div>
                            <div class="report-content">
                                <p>${report.description}</p>
                                <div class="report-meta">
                                    <span><i class="fas fa-exclamation-triangle"></i> ${(report.priority || 'medium').toUpperCase()} Priority</span>
                                    <span><i class="fas fa-user"></i> ${getReporterName(report.reporter)}</span>
                                    <span><i class="fas fa-clock"></i> ${formatTimeAgo(new Date(report.createdAt || report.timestamp || Date.now()))}</span>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Close modal when clicking outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            document.body.style.overflow = 'auto';
        }
    });
};

// Zoom to a specific location
window.zoomToLocation = function(lat, lng) {
    if (map) {
        map.setView([lat, lng], 16);
        showNotification(`Zoomed to location: ${lat.toFixed(6)}, ${lng.toFixed(6)}`, 'success');
    }
};

function getMarkerColor(status) {
    switch(status) {
        case 'pending': return '#e74c3c';
        case 'in-progress': return '#f39c12';
        case 'resolved': return '#27ae60';
        default: return '#95a5a6';
    }
}

// Create custom icon for reports
function getReportIcon(type, color) {
    const iconMap = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    
    return L.divIcon({
        html: `<div style="background-color: ${color}; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">
                   <i class="fas ${iconMap[type] || iconMap.other}" style="color: white; font-size: 14px;"></i>
               </div>`,
        iconSize: [30, 30],
        className: 'custom-marker-wrapper',
        iconAnchor: [15, 15],
        popupAnchor: [0, -15]
    });
}

// Get human-readable report type label
function getReportTypeLabel(type) {
    const labels = {
        'pothole': 'Pothole',
        'streetlight': 'Broken Streetlight',
        'garbage': 'Garbage Overflow',
        'water': 'Water Leakage',
        'construction': 'Construction Issue',
        'other': 'Other Issue'
    };
    return labels[type] || 'Unknown Issue';
}

// Get status class for styling
function getStatusClass(status) {
    switch(status) {
        case 'pending': return 'status-pending';
        case 'in-progress': return 'status-progress';
        case 'resolved': return 'status-resolved';
        default: return 'status-pending';
    }
}

// Get priority class for styling
function getPriorityClass(priority) {
    switch(priority) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'medium': return 'priority-medium';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}

// Format status text
function formatStatus(status) {
    return status.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
}

// Get reporter name
function getReporterName(reporter) {
    if (typeof reporter === 'string') {
        return reporter;
    }
    if (reporter && reporter.name) {
        return reporter.name;
    }
    return 'Anonymous';
}

// Get category icon
function getCategoryIcon(category) {
    const icons = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    return icons[category] || icons.other;
}

// Populate recent activity section
function populateRecentActivity() {
    const activityList = document.getElementById('activityList');
    
    // Check if element exists (only on dashboard page)
    if (!activityList) {
        return;
    }
    
    if (allReports.length === 0) {
        // Show empty state
        activityList.className = 'activity-list empty';
        activityList.innerHTML = `
            <i class="fas fa-clipboard-list"></i>
            <h4>No Recent Activity</h4>
            <p>Community reports will appear here once submitted</p>
        `;
        return;
    }
    
    activityList.className = 'activity-list';
    const sortedReports = [...allReports].sort((a, b) => new Date(b.createdAt || b.timestamp) - new Date(a.createdAt || a.timestamp));
    
    activityList.innerHTML = '';
    
    // Show only the 5 most recent reports
    sortedReports.slice(0, 5).forEach(report => {
        const activityItem = createActivityItem(report);
        activityList.appendChild(activityItem);
    });
}

// Create activity item element
function createActivityItem(report) {
    const item = document.createElement('div');
    item.className = 'activity-item';
    
    const reportType = report.category || report.type;
    const reportStatus = report.status;
    const reportLocation = report.location?.address || report.location;
    const reportTimestamp = new Date(report.createdAt || report.timestamp);
    
    const iconClass = getActivityIconClass(reportStatus);
    const statusText = getStatusText(reportStatus);
    
    item.innerHTML = `
        <div class="activity-icon ${iconClass}">
            <i class="fas ${getActivityIcon(reportStatus)}"></i>
        </div>
        <div class="activity-content">
            <div class="activity-title">${getReportTypeLabel(reportType)} - ${statusText}</div>
            <div class="activity-description">${reportLocation}</div>
            <div class="activity-time">${formatTimeAgo(reportTimestamp)}</div>
        </div>
    `;
    
    return item;
}

// Get activity icon class based on status
function getActivityIconClass(status) {
    switch(status) {
        case 'pending': return 'new';
        case 'in-progress': return 'progress';
        case 'resolved': return 'resolved';
        default: return 'new';
    }
}

// Get activity icon based on status
function getActivityIcon(status) {
    switch(status) {
        case 'pending': return 'fa-plus';
        case 'in-progress': return 'fa-clock';
        case 'resolved': return 'fa-check';
        default: return 'fa-info';
    }
}

// Get status text
function getStatusText(status) {
    switch(status) {
        case 'pending': return 'Reported';
        case 'in-progress': return 'In Progress';
        case 'resolved': return 'Resolved';
        default: return 'Unknown';
    }
}

// Update statistics from API response
function updateStatisticsFromAPI(stats) {
    const totalElement = document.getElementById('totalReports');
    const inProcessElement = document.getElementById('inProcessReports');
    const resolvedElement = document.getElementById('resolvedReports');
    
    if (totalElement) totalElement.textContent = stats.total.toLocaleString();
    if (inProcessElement) inProcessElement.textContent = stats.inProgress.toLocaleString();
    if (resolvedElement) resolvedElement.textContent = stats.resolved.toLocaleString();
    
    // Animate numbers only if elements exist
    if (totalElement && inProcessElement && resolvedElement) {
        animateNumbers();
    }
}

// Update statistics (fallback for when API is not available)
function updateStatistics() {
    const stats = calculateStatistics();
    
    const totalElement = document.getElementById('totalReports');
    const inProcessElement = document.getElementById('inProcessReports');
    const resolvedElement = document.getElementById('resolvedReports');
    
    // Check if elements exist (only on dashboard page)
    if (totalElement) totalElement.textContent = stats.total.toLocaleString();
    if (inProcessElement) inProcessElement.textContent = stats.inProcess.toLocaleString();
    if (resolvedElement) resolvedElement.textContent = stats.resolved.toLocaleString();
    
    // Animate numbers only if elements exist
    if (totalElement && inProcessElement && resolvedElement) {
        animateNumbers();
    }
}

// Calculate statistics from current data
function calculateStatistics() {
    const total = allReports.length;
    const inProcess = allReports.filter(r => r.status === 'in-progress').length;
    const resolved = allReports.filter(r => r.status === 'resolved').length;
    
    return { total, inProcess, resolved };
}

// Animate number counters
function animateNumbers() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent.replace(/,/g, ''));
        const increment = target / 50;
        let current = 0;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                counter.textContent = target.toLocaleString();
                clearInterval(timer);
            } else {
                counter.textContent = Math.floor(current).toLocaleString();
            }
        }, 30);
    });
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
        return 'Just now';
    }
}

// Setup event listeners
function setupEventListeners() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
    
    // Report form submission (only on dashboard page)
    const reportForm = document.querySelector('.report-form');
    if (reportForm) {
        reportForm.addEventListener('submit', handleReportSubmission);
    }
    
    // Login form submission (only on dashboard page)
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form submission (only on dashboard page)
    const registerForm = document.querySelector('.register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Close modal when clicking outside (only on dashboard page)
    window.addEventListener('click', (event) => {
        const reportModal = document.getElementById('reportModal');
        const authModal = document.getElementById('authModal');
        
        if (reportModal && event.target === reportModal) {
            closeReportModal();
        }
        if (authModal && event.target === authModal) {
            closeAuthModal();
        }
    });
    
    // File upload handling for dashboard report modal
    const fileInput = document.getElementById('reportImage');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileUpload);
    }
}

// Modal functions
function openReportModal() {
    // Check if user is logged in
    if (!window.isUserLoggedIn) {
        showNotification('Please sign in to report issues', 'info');
        // Redirect to sign-in page
        setTimeout(() => {
            window.location.href = 'signin.html';
        }, 1500);
        return;
    }
    
    const reportModal = document.getElementById('reportModal');
    if (reportModal) {
        reportModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeReportModal() {
    const reportModal = document.getElementById('reportModal');
    if (reportModal) {
        reportModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Reset form
        const reportForm = document.querySelector('.report-form');
        if (reportForm) {
            reportForm.reset();
        }
        
        // Reset file upload area
        const uploadArea = document.querySelector('.file-upload-area');
        if (uploadArea) {
            uploadArea.innerHTML = `
                <i class="fas fa-cloud-upload-alt"></i>
                <span>Click to upload or drag and drop</span>
                <small>PNG, JPG up to 5MB</small>
            `;
        }
        
        // Clear location data and status
        if (typeof currentLocationCoords !== 'undefined') {
            currentLocationCoords = null;
        }
        
        const locationStatus = document.getElementById('locationStatus');
        if (locationStatus) {
            locationStatus.classList.remove('show');
        }
        
        // Remove current location marker from map if it exists
        if (window.currentLocationMarker && map) {
            map.removeLayer(window.currentLocationMarker);
            window.currentLocationMarker = null;
        }
        
        // Remove preview location marker from map if it exists
        if (window.previewLocationMarker && map) {
            map.removeLayer(window.previewLocationMarker);
            window.previewLocationMarker = null;
        }
        
        // Hide location preview display
        const locationPreview = document.getElementById('locationPreview');
        if (locationPreview) {
            locationPreview.style.display = 'none';
        }
    }
}

// Authentication Modal functions
function openAuthModal() {
    const authModal = document.getElementById('authModal');
    if (authModal) {
        authModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        // Show login form by default
        switchToLogin();
    }
}

function closeAuthModal() {
    const authModal = document.getElementById('authModal');
    if (authModal) {
        authModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Reset forms
        const loginForm = document.querySelector('.login-form');
        const registerForm = document.querySelector('.register-form');
        
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
    }
}

function switchToLogin() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authTitle = document.getElementById('authTitle');
    
    if (loginForm && registerForm && authTitle) {
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
        authTitle.textContent = 'Login to Report Issues';
    }
}

function switchToRegister() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authTitle = document.getElementById('authTitle');
    
    if (loginForm && registerForm && authTitle) {
        registerForm.classList.add('active');
        loginForm.classList.remove('active');
        authTitle.textContent = 'Create Your Account';
    }
}

// Enhanced registration with API and fallback
async function handleRegister(event) {
    event.preventDefault();
    
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim().toLowerCase();
    const phone = document.getElementById('registerPhone').value.trim();
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    // Validate all fields
    if (!name || name.length < 2) {
        showNotification('Please enter a valid name (at least 2 characters).', 'error');
        return;
    }
    
    if (!validateEmail(email)) {
        showNotification('Please enter a valid email address.', 'error');
        return;
    }
    
    if (!validatePhone(phone)) {
        showNotification('Please enter a valid phone number.', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters long.', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match!', 'error');
        return;
    }
    
    if (!agreeTerms) {
        showNotification('Please agree to the Terms & Conditions', 'error');
        return;
    }
    
    try {
        // Try API registration first
        const response = await api.register({
            name,
            email,
            phone,
            password,
            confirmPassword
        });
        
        if (response.success) {
            // Reset register form
            document.querySelector('.register-form').reset();
            
            // Show success message and switch to login
            showNotification(`Account created successfully, ${name}! Please login with your credentials.`, 'success');
            
            // Switch to login form after successful registration
            setTimeout(() => {
                switchToLogin();
                // Pre-fill email in login form
                document.getElementById('loginEmail').value = email;
                document.getElementById('loginEmail').focus();
            }, 2000);
        }
        
    } catch (error) {
        console.error('Registration error:', error);
        
        // Fallback to offline mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Using offline demo mode.', 'info');
            
            // Simulate successful registration in offline mode
            isUserLoggedIn = true;
            currentUser = { name, email, _id: 'offline-user' };
            
            document.querySelector('.register-form').reset();
            closeAuthModal();
            showNotification(`Welcome ${name}! You're now in demo mode.`, 'success');
        } else {
            showNotification(error.message || 'Registration failed. Please try again.', 'error');
        }
    }
}

// Enhanced login with API and fallback
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    
    if (!validateEmail(email)) {
        showNotification('Please enter a valid email address.', 'error');
        return;
    }
    
    if (!password) {
        showNotification('Please enter your password.', 'error');
        return;
    }
    
    try {
        // Try API login first
        const response = await api.login({ email, password });
        
        if (response.success) {
            isUserLoggedIn = true;
            currentUser = response.data.user;
            
            closeAuthModal();
            showNotification(`Welcome back, ${currentUser.name}! You can now report issues.`, 'success');
            
            setTimeout(() => {
                openReportModal();
            }, 1500);
        }
        
    } catch (error) {
        console.error('Login error:', error);
        
        // Fallback to offline demo mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Using offline demo mode.', 'info');
            
            // Simulate successful login in offline mode
            isUserLoggedIn = true;
            currentUser = { name: 'Demo User', email, _id: 'offline-user' };
            
            closeAuthModal();
            showNotification(`Welcome Demo User! You're now in demo mode.`, 'success');
            
            setTimeout(() => {
                openReportModal();
            }, 1500);
        } else {
            showNotification(error.message || 'Login failed. Please try again.', 'error');
        }
    }
}

// Enhanced report submission with Web3Auth integration
async function handleReportSubmission(event) {
    event.preventDefault();
    
    // Check if user is logged in via Web3Auth
    if (!window.civicAuth || !window.civicAuth.getIsAuthenticated()) {
        showNotification('Please sign in first to submit a report.', 'error');
        return;
    }
    
    const user = window.civicAuth.getUser();
    if (!user) {
        showNotification('User information not available. Please sign in again.', 'error');
        return;
    }
    
    const formData = {
        title: document.getElementById('reportTitle').value,
        category: document.getElementById('issueType').value,
        priority: document.getElementById('reportPriority').value,
        description: document.getElementById('description').value,
        address: document.getElementById('location').value,
        coordinates: currentLocationCoords, // GPS coordinates if available
        image: document.getElementById('reportImage').files[0] || null
    };
    
    // Validate required fields
    if (!formData.title || !formData.category || !formData.priority || !formData.description || !formData.address) {
        showNotification('Please fill in all required fields.', 'error');
        return;
    }
    
    // If no GPS coordinates, try to geocode the address
    if (!formData.coordinates && formData.address) {
        showNotification('Finding location coordinates...', 'info');
        
        try {
            const geocodedCoords = await geocodeAddress(formData.address);
            if (geocodedCoords) {
                formData.coordinates = geocodedCoords;
                console.log('Geocoded coordinates:', geocodedCoords);
            } else {
                console.log('Geocoding failed, will let server use default coordinates');
                // Don't set coordinates, let server use default
            }
        } catch (error) {
            console.error('Geocoding error:', error);
            // Don't set coordinates, let server use default
        }
    }
    
    // Ensure coordinates are in the correct format [longitude, latitude] for storage
    if (formData.coordinates) {
        // Validate coordinates before sending
        let lng, lat;
        
        if (Array.isArray(formData.coordinates)) {
            lng = parseFloat(formData.coordinates[0]);
            lat = parseFloat(formData.coordinates[1]);
        } else if (typeof formData.coordinates === 'object') {
            lng = parseFloat(formData.coordinates.lng);
            lat = parseFloat(formData.coordinates.lat);
        } else {
            console.error('Invalid coordinate format:', formData.coordinates);
            showNotification('Invalid coordinate format. Server will use default location.', 'warning');
            delete formData.coordinates; // Remove invalid coordinates
        }
        
        // Only proceed if we have coordinates and they're valid numbers
        if (formData.coordinates && !isNaN(lng) && !isNaN(lat)) {
            // Validate coordinate ranges
            if (lng < -180 || lng > 180 || lat < -90 || lat > 90) {
                console.error('Coordinates out of valid range:', { lng, lat });
                showNotification('Coordinates out of valid range. Server will use default location.', 'warning');
                delete formData.coordinates; // Remove invalid coordinates
            } else {
                formData.coordinates = [lng, lat];
                console.log('Final coordinates for submission:', formData.coordinates);
            }
        } else if (formData.coordinates) {
            console.error('Coordinates are not valid numbers:', { lng, lat });
            showNotification('Invalid coordinates. Server will use default location.', 'warning');
            delete formData.coordinates; // Remove invalid coordinates
        }
    }
    
    console.log('Submitting report with coordinates:', formData.coordinates);
    console.log('Full form data being submitted:', formData);
    
    try {
        // Try API submission first
        const response = await api.createReport(formData);
        
        if (response.success) {
            // Add to local array for immediate UI update
            allReports.unshift(response.data.report);
            
            // Update UI
            populateRecentActivity();
            updateStatistics();
            
            // Refresh map markers to include the new report
            addReportMarkers();
            
            // Reload reports from API to get the latest data
            setTimeout(() => {
                loadReportsFromAPI();
            }, 1000);
            
            // Show success message
            showNotification('Thank you! Your report has been submitted successfully and located on the map.', 'success');
            
            // Close modal and reset form
            closeReportModal();
        }
        
    } catch (error) {
        console.error('Report submission error:', error);
        
        // Fallback to offline mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Report saved locally for demo.', 'info');
            
            // Create offline report
            const offlineReport = {
                _id: 'offline-' + Date.now(),
                title: formData.title,
                description: formData.description,
                category: formData.category,
                priority: formData.priority,
                status: 'pending',
                location: {
                    address: formData.address,
                    coordinates: formData.coordinates || [80.3319, 26.4499]
                },
                reporter: currentUser,
                createdAt: new Date().toISOString(),
                upvoteCount: 0,
                downvoteCount: 0,
                commentCount: 0
            };
            
            // Add to local array
            allReports.unshift(offlineReport);
            
            // Update UI
            populateRecentActivity();
            updateStatistics();
            
            // Refresh map markers to include the new report
            addReportMarkers();
            
            // Close modal
            closeReportModal();
        } else {
            showNotification(error.message || 'Failed to submit report. Please try again.', 'error');
        }
    }
    
    // Reset location data
    if (typeof currentLocationCoords !== 'undefined') {
        currentLocationCoords = null;
    }
    const locationStatus = document.getElementById('locationStatus');
    if (locationStatus) {
        locationStatus.classList.remove('show');
    }
}

// Validation helper functions
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// Handle file upload for dashboard report modal
function handleFileUpload(event) {
    const file = event.target.files[0];
    const uploadArea = document.querySelector('.file-upload-area');
    
    if (file) {
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            showNotification('File size must be less than 5MB.', 'error');
            event.target.value = '';
            return;
        }
        
        if (!file.type.startsWith('image/')) {
            showNotification('Please select an image file.', 'error');
            event.target.value = '';
            return;
        }
        
        uploadArea.innerHTML = `
            <i class="fas fa-check-circle" style="color: #00ff9d;"></i>
            <span style="color: #00ff9d;">Image uploaded: ${file.name}</span>
            <small>Click to change image</small>
        `;
    }
}

// Enhanced location functionality with geocoding
let currentLocationCoords = null;

// Geocode address to coordinates using Nominatim (OpenStreetMap)
async function geocodeAddress(address) {
    try {
        // Add bias towards Kanpur, UP, India for better local results
        const query = encodeURIComponent(`${address}, Kanpur, Uttar Pradesh, India`);
        const url = `https://nominatim.openstreetmap.org/search?format=json&q=${query}&limit=1&countrycodes=in&bounded=1&viewbox=80.2,26.3,80.5,26.6`;
        
        console.log('Geocoding address:', address);
        console.log('Geocoding URL:', url);
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data && data.length > 0) {
            const result = data[0];
            const lat = parseFloat(result.lat);
            const lng = parseFloat(result.lon);
            
            // Validate the geocoded coordinates
            if (isNaN(lat) || isNaN(lng)) {
                console.error('Geocoding returned invalid coordinates:', { lat, lng });
                return null;
            }
            
            if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
                console.error('Geocoding returned out-of-range coordinates:', { lat, lng });
                return null;
            }
            
            const coordinates = { lat, lng };
            console.log('Geocoding successful:', coordinates);
            return coordinates;
        } else {
            console.log('No geocoding results found');
            return null;
        }
    } catch (error) {
        console.error('Geocoding error:', error);
        return null;
    }
}

// Get current location using GPS
function getCurrentLocation() {
    const locationBtn = document.querySelector('.btn-location');
    const locationStatus = document.getElementById('locationStatus');
    const locationInput = document.getElementById('location');
    
    // Check if geolocation is supported
    if (!navigator.geolocation) {
        showLocationStatus('Geolocation is not supported by this browser.', 'error');
        return;
    }
    
    // Show loading state
    locationBtn.classList.add('loading');
    locationBtn.disabled = true;
    showLocationStatus('Getting your location...', 'loading');
    
    // Get current position
    navigator.geolocation.getCurrentPosition(
        // Success callback
        async function(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            const accuracy = position.coords.accuracy;
            
            currentLocationCoords = { lat: latitude, lng: longitude };
            
            // Try to reverse geocode to get a readable address
            try {
                const address = await reverseGeocode(latitude, longitude);
                locationInput.value = address || `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
                
                // Show location preview with GPS coordinates
                showLocationPreview(
                    address || `GPS Coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
                    { lat: latitude, lng: longitude }
                );
            } catch (error) {
                locationInput.value = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
                
                // Show location preview with coordinates
                showLocationPreview(
                    `GPS Coordinates: ${latitude.toFixed(6)}, ${longitude.toFixed(6)}`,
                    { lat: latitude, lng: longitude }
                );
            }
            
            showLocationStatus(`Location found (±${Math.round(accuracy)}m accuracy)`, 'success');
            
            // Add current location marker to map if map exists
            if (map) {
                // Remove existing current location marker
                if (window.currentLocationMarker) {
                    map.removeLayer(window.currentLocationMarker);
                }
                
                // Add new current location marker
                window.currentLocationMarker = L.marker([latitude, longitude], {
                    icon: L.divIcon({
                        html: `<div style="background-color: #00ff9d; border-radius: 50%; width: 20px; height: 20px; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);"></div>`,
                        iconSize: [20, 20],
                        className: 'current-location-marker',
                        iconAnchor: [10, 10]
                    })
                }).addTo(map).bindPopup('Your Current Location');
                
                // Center map on current location
                map.setView([latitude, longitude], 15);
            }
            
            // Reset button state
            locationBtn.classList.remove('loading');
            locationBtn.disabled = false;
        },
        // Error callback
        function(error) {
            let errorMessage = 'Unable to get your location. ';
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage += 'Location access denied by user.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage += 'Location information unavailable.';
                    break;
                case error.TIMEOUT:
                    errorMessage += 'Location request timed out.';
                    break;
                default:
                    errorMessage += 'An unknown error occurred.';
                    break;
            }
            
            showLocationStatus(errorMessage, 'error');
            
            // Reset button state
            locationBtn.classList.remove('loading');
            locationBtn.disabled = false;
        },
        // Options
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
        }
    );
}

// Reverse geocode coordinates to address
async function reverseGeocode(lat, lng) {
    try {
        const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data && data.display_name) {
            // Extract relevant parts of the address
            const address = data.address;
            let formattedAddress = '';
            
            if (address.road) formattedAddress += address.road;
            if (address.suburb) formattedAddress += (formattedAddress ? ', ' : '') + address.suburb;
            if (address.city || address.town || address.village) {
                formattedAddress += (formattedAddress ? ', ' : '') + (address.city || address.town || address.village);
            }
            
            return formattedAddress || data.display_name;
        }
        
        return null;
    } catch (error) {
        console.error('Reverse geocoding error:', error);
        return null;
    }
}

// Preview location on map
async function previewLocation() {
    const locationInput = document.getElementById('location');
    const address = locationInput.value.trim();
    
    if (!address) {
        showNotification('Please enter an address first.', 'error');
        return;
    }
    
    if (!map) {
        showNotification('Map is not available.', 'error');
        return;
    }
    
    showNotification('Finding location on map...', 'info');
    
    try {
        let coordinates;
        
        // If we have current GPS coordinates, use them
        if (currentLocationCoords) {
            coordinates = currentLocationCoords;
        } else {
            // Otherwise, geocode the address
            coordinates = await geocodeAddress(address);
        }
        
        if (coordinates) {
            // Remove existing preview marker
            if (window.previewLocationMarker) {
                map.removeLayer(window.previewLocationMarker);
            }
            
            // Add preview marker (simple marker without popup)
            window.previewLocationMarker = L.marker([coordinates.lat, coordinates.lng], {
                icon: L.divIcon({
                    html: `<div style="background-color: #ff6b35; border-radius: 50%; width: 25px; height: 25px; border: 3px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3); animation: pulse 2s infinite;">
                               <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); color: white; font-size: 12px;">
                                   <i class="fas fa-exclamation"></i>
                               </div>
                           </div>`,
                    iconSize: [25, 25],
                    className: 'preview-location-marker',
                    iconAnchor: [12.5, 12.5]
                })
            }).addTo(map);
            
            // Center map on preview location
            map.setView([coordinates.lat, coordinates.lng], 16);
            
            // Show permanent location preview display
            showLocationPreview(address, coordinates);
            
            showNotification('Location found and marked on map!', 'success');
        } else {
            showNotification('Could not find the specified location. Please check the address.', 'error');
        }
    } catch (error) {
        console.error('Preview location error:', error);
        showNotification('Error finding location. Please try again.', 'error');
    }
}

// Show location preview in permanent display area
function showLocationPreview(address, coordinates) {
    const previewDiv = document.getElementById('locationPreview');
    const previewAddress = document.getElementById('previewAddress');
    const previewCoordinates = document.getElementById('previewCoordinates');
    const previewMapStatus = document.getElementById('previewMapStatus');
    
    if (previewDiv && previewAddress && previewCoordinates && previewMapStatus) {
        // Update the content
        previewAddress.textContent = address;
        previewCoordinates.textContent = `${coordinates.lat.toFixed(6)}, ${coordinates.lng.toFixed(6)}`;
        previewMapStatus.textContent = 'Location marked on map ✓';
        
        // Show the preview area
        previewDiv.style.display = 'block';
        
        // Scroll to show the preview
        previewDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
}

// Clear location preview
function clearLocationPreview() {
    const previewDiv = document.getElementById('locationPreview');
    
    if (previewDiv) {
        previewDiv.style.display = 'none';
    }
    
    // Remove preview marker from map
    if (window.previewLocationMarker && map) {
        map.removeLayer(window.previewLocationMarker);
        window.previewLocationMarker = null;
    }
    
    showNotification('Location preview cleared.', 'info');
}

// Confirm the previewed location (legacy function for compatibility)
window.confirmLocation = function() {
    showNotification('Location confirmed! You can now submit your report.', 'success');
};

// Cancel the location preview (legacy function for compatibility)
window.cancelPreview = function() {
    clearLocationPreview();
};
function showLocationStatus(message, type) {
    const locationStatus = document.getElementById('locationStatus');
    if (!locationStatus) return;
    
    const iconMap = {
        loading: 'fa-spinner fa-spin',
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle'
    };
    
    locationStatus.innerHTML = `<i class="fas ${iconMap[type]}"></i> ${message}`;
    locationStatus.className = `location-status show ${type}`;
    
    // Auto-hide success/error messages after 4 seconds
    if (type !== 'loading') {
        setTimeout(() => {
            locationStatus.classList.remove('show');
        }, 4000);
    }
}

// Show notification function
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove notification after 4 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}

// Add custom CSS for markers
const style = document.createElement('style');
style.textContent = `
    .custom-marker {
        background-color: #e74c3c;
        border: 2px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    }
    
    .leaflet-popup-content-wrapper {
        background-color: #2f3349;
        color: #e4e6ea;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        border: 1px solid rgba(0, 255, 157, 0.2);
    }
    
    .leaflet-popup-tip {
        background-color: #2f3349;
        border: 1px solid rgba(0, 255, 157, 0.2);
    }
    
    .custom-popup .leaflet-popup-content {
        margin: 0;
        padding: 0;
    }
    
    .popup-content {
        font-family: 'Inter', sans-serif;
    }
    
    .popup-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        padding: 16px 16px 12px 16px;
        border-bottom: 1px solid rgba(160, 163, 189, 0.1);
        gap: 12px;
    }
    
    .popup-title {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 600;
        color: #e4e6ea;
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
    }
    
    .popup-title i {
        color: #00ff9d;
        font-size: 1rem;
    }
    
    .popup-status {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        white-space: nowrap;
    }
    
    .popup-status.status-pending {
        background: rgba(231, 76, 60, 0.2);
        color: #e74c3c;
        border: 1px solid rgba(231, 76, 60, 0.3);
    }
    
    .popup-status.status-progress {
        background: rgba(243, 156, 18, 0.2);
        color: #f39c12;
        border: 1px solid rgba(243, 156, 18, 0.3);
    }
    
    .popup-status.status-resolved {
        background: rgba(39, 174, 96, 0.2);
        color: #27ae60;
        border: 1px solid rgba(39, 174, 96, 0.3);
    }
    
    .popup-body {
        padding: 16px;
    }
    
    .popup-section {
        margin-bottom: 16px;
    }
    
    .popup-section h5 {
        margin: 0 0 8px 0;
        font-size: 0.9rem;
        font-weight: 600;
        color: #00ff9d;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .popup-section h5 i {
        font-size: 0.8rem;
    }
    
    .popup-description {
        margin: 0;
        font-size: 0.9rem;
        line-height: 1.5;
        color: #e4e6ea;
    }
    
    .popup-location {
        margin: 0 0 4px 0;
        font-size: 0.9rem;
        color: #e4e6ea;
    }
    
    .popup-coordinates {
        font-size: 0.75rem;
        color: #a0a3bd;
        font-family: monospace;
    }
    
    .popup-meta {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-bottom: 16px;
    }
    
    .popup-meta-item {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.85rem;
        color: #a0a3bd;
    }
    
    .popup-meta-item i {
        color: #00d4ff;
        font-size: 0.8rem;
        width: 12px;
    }
    
    .popup-priority {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        letter-spacing: 0.5px;
    }
    
    .popup-priority.priority-urgent {
        color: #e74c3c;
    }
    
    .popup-priority.priority-high {
        color: #ff6b35;
    }
    
    .popup-priority.priority-medium {
        color: #f39c12;
    }
    
    .popup-priority.priority-low {
        color: #3498db;
    }
    
    .popup-actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
    }
    
    .popup-btn {
        padding: 8px 12px;
        border: none;
        border-radius: 6px;
        font-size: 0.8rem;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        gap: 6px;
        text-decoration: none;
    }
    
    .popup-btn-primary {
        background: linear-gradient(135deg, #00ff9d 0%, #00d4ff 100%);
        color: #1a1d29;
    }
    
    .popup-btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 255, 157, 0.3);
    }
    
    .popup-btn-secondary {
        background: rgba(0, 212, 255, 0.2);
        color: #00d4ff;
        border: 1px solid rgba(0, 212, 255, 0.3);
    }
    
    .popup-btn-secondary:hover {
        background: rgba(0, 212, 255, 0.3);
        border-color: rgba(0, 212, 255, 0.5);
    }
    
    .popup-btn-vote {
        background: rgba(255, 107, 53, 0.2);
        color: #ff6b35;
        border: 1px solid rgba(255, 107, 53, 0.3);
    }
    
    .popup-btn-vote:hover {
        background: rgba(255, 107, 53, 0.3);
        border-color: rgba(255, 107, 53, 0.5);
    }
    
    /* Report Detail Modal Styles */
    .report-detail-modal .modal-content {
        max-width: 600px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .report-badges {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 20px;
    }
    
    .badge {
        padding: 6px 12px;
        border-radius: 16px;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .status-badge.status-pending {
        background: rgba(231, 76, 60, 0.2);
        color: #e74c3c;
        border: 1px solid rgba(231, 76, 60, 0.3);
    }
    
    .status-badge.status-progress {
        background: rgba(243, 156, 18, 0.2);
        color: #f39c12;
        border: 1px solid rgba(243, 156, 18, 0.3);
    }
    
    .status-badge.status-resolved {
        background: rgba(39, 174, 96, 0.2);
        color: #27ae60;
        border: 1px solid rgba(39, 174, 96, 0.3);
    }
    
    .priority-badge {
        background: rgba(255, 107, 53, 0.2);
        color: #ff6b35;
        border: 1px solid rgba(255, 107, 53, 0.3);
    }
    
    .category-badge {
        background: rgba(0, 255, 157, 0.2);
        color: #00ff9d;
        border: 1px solid rgba(0, 255, 157, 0.3);
    }
    
    .report-info h4 {
        color: #00ff9d;
        margin: 20px 0 10px 0;
        font-size: 1.1rem;
    }
    
    .report-info p {
        margin: 0 0 15px 0;
        line-height: 1.6;
        color: #e4e6ea;
    }
    
    .report-meta-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 12px;
        margin: 15px 0;
    }
    
    .meta-item {
        background: rgba(47, 51, 73, 0.6);
        padding: 12px;
        border-radius: 8px;
        border: 1px solid rgba(160, 163, 189, 0.1);
    }
    
    .meta-item strong {
        color: #00d4ff;
        display: block;
        margin-bottom: 4px;
        font-size: 0.85rem;
    }
    
    .vote-stats {
        display: flex;
        gap: 20px;
        margin: 15px 0;
    }
    
    .vote-item {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 15px;
        background: rgba(47, 51, 73, 0.6);
        border-radius: 8px;
        border: 1px solid rgba(160, 163, 189, 0.1);
    }
    
    .vote-item i {
        color: #00ff9d;
    }
    
    /* Preview Popup Styles */
    .preview-popup .leaflet-popup-content-wrapper {
        background-color: #2f3349;
        color: #e4e6ea;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        border: 2px solid #ff6b35;
    }
    
    .preview-popup .leaflet-popup-tip {
        background-color: #2f3349;
        border: 2px solid #ff6b35;
    }
    
    .preview-popup .leaflet-popup-content {
        margin: 0;
        padding: 0;
    }
    
    .preview-popup-content {
        font-family: 'Inter', sans-serif;
        min-width: 250px;
    }
    
    .preview-popup-header {
        padding: 16px 16px 12px 16px;
        border-bottom: 1px solid rgba(255, 107, 53, 0.2);
        background: linear-gradient(135deg, rgba(255, 107, 53, 0.1) 0%, rgba(255, 107, 53, 0.05) 100%);
    }
    
    .preview-popup-title {
        margin: 0;
        font-size: 1.1rem;
        font-weight: 600;
        color: #ff6b35;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .preview-popup-title i {
        color: #ff6b35;
        font-size: 1rem;
    }
    
    .preview-popup-body {
        padding: 16px;
    }
    
    .preview-location-info {
        margin-bottom: 16px;
    }
    
    .preview-location-info p {
        margin: 0 0 12px 0;
        display: flex;
        align-items: flex-start;
        gap: 8px;
        font-size: 0.9rem;
        line-height: 1.4;
    }
    
    .preview-location-info p:last-child {
        margin-bottom: 0;
    }
    
    .preview-location-info i {
        color: #ff6b35;
        font-size: 0.8rem;
        margin-top: 2px;
        flex-shrink: 0;
    }
    
    .preview-address strong {
        color: #e4e6ea;
        font-weight: 600;
    }
    
    .preview-coordinates {
        color: #a0a3bd;
        font-family: monospace;
        font-size: 0.85rem !important;
    }
    
    .preview-description {
        color: #a0a3bd;
        font-style: italic;
    }
    
    .preview-actions {
        display: flex;
        gap: 8px;
        justify-content: space-between;
    }
    
    .preview-btn {
        flex: 1;
        padding: 10px 12px;
        border: none;
        border-radius: 8px;
        font-size: 0.85rem;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
    }
    
    .preview-btn-confirm {
        background: linear-gradient(135deg, #00ff9d 0%, #00d4ff 100%);
        color: #1a1d29;
    }
    
    .preview-btn-confirm:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 255, 157, 0.3);
    }
    
    .preview-btn-cancel {
        background: rgba(255, 107, 53, 0.2);
        color: #ff6b35;
        border: 1px solid rgba(255, 107, 53, 0.3);
    }
    
    .preview-btn-cancel:hover {
        background: rgba(255, 107, 53, 0.3);
        border-color: rgba(255, 107, 53, 0.5);
    }
    
    /* Clustered Marker Styles */
    .cluster-popup-content {
        min-width: 320px;
    }
    
    .status-summary, .category-summary {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 12px;
    }
    
    .status-summary .status-badge {
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .category-summary .category-badge {
        padding: 4px 8px;
        border-radius: 8px;
        font-size: 0.8rem;
        background: rgba(0, 255, 157, 0.2);
        color: #00ff9d;
        border: 1px solid rgba(0, 255, 157, 0.3);
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    .recent-reports {
        max-height: 200px;
        overflow-y: auto;
    }
    
    .recent-report-item {
        background: rgba(26, 29, 41, 0.6);
        padding: 10px;
        border-radius: 6px;
        margin-bottom: 8px;
        border: 1px solid rgba(160, 163, 189, 0.1);
    }
    
    .recent-report-item .report-title {
        font-weight: 600;
        color: #e4e6ea;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .recent-report-item .report-meta {
        display: flex;
        gap: 12px;
        font-size: 0.8rem;
        color: #a0a3bd;
    }
    
    .recent-report-item .report-status {
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.7rem;
    }
    
    .more-reports {
        text-align: center;
        color: #a0a3bd;
        font-style: italic;
        padding: 8px;
        border-top: 1px solid rgba(160, 163, 189, 0.1);
        margin-top: 8px;
    }
    
    /* Location Reports Modal Styles */
    .location-reports-modal .modal-content {
        max-width: 700px;
        max-height: 80vh;
        overflow-y: auto;
    }
    
    .location-info {
        background: rgba(47, 51, 73, 0.6);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        border: 1px solid rgba(160, 163, 189, 0.1);
    }
    
    .location-info p {
        margin: 0 0 8px 0;
        color: #e4e6ea;
    }
    
    .location-info p:last-child {
        margin-bottom: 0;
    }
    
    .reports-list {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    
    .report-card {
        background: rgba(47, 51, 73, 0.6);
        border-radius: 12px;
        padding: 16px;
        border: 1px solid rgba(160, 163, 189, 0.1);
        transition: all 0.2s ease;
    }
    
    .report-card:hover {
        border-color: rgba(0, 255, 157, 0.3);
        box-shadow: 0 4px 12px rgba(0, 255, 157, 0.1);
    }
    
    .report-card .report-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 12px;
        gap: 12px;
    }
    
    .report-card .report-header h4 {
        margin: 0;
        color: #00ff9d;
        font-size: 1.1rem;
        display: flex;
        align-items: center;
        gap: 8px;
        flex: 1;
    }
    
    .report-card .report-content p {
        margin: 0 0 12px 0;
        color: #e4e6ea;
        line-height: 1.5;
    }
    
    .report-card .report-meta {
        display: flex;
        gap: 15px;
        font-size: 0.85rem;
        color: #a0a3bd;
        flex-wrap: wrap;
    }
    
    .report-card .report-meta span {
        display: flex;
        align-items: center;
        gap: 5px;
    }
    
    .report-card .report-meta i {
        color: #00d4ff;
        font-size: 0.8rem;
    }
`;
document.head.appendChild(style);

// Global functions for testing (accessible from browser console)
window.refreshMapMarkers = function() {
    console.log('Manually refreshing map markers...');
    addReportMarkers();
};

window.reloadReportsData = function() {
    console.log('Manually reloading reports data...');
    loadReportsFromAPI();
};

window.debugMapData = function() {
    console.log('Current reports data:', allReports);
    console.log('Map object:', map);
    console.log('Current markers:', reportMarkers);
};

window.testCoordinateValidation = function(coordinates) {
    console.log('Testing coordinate validation for:', coordinates);
    
    let lng, lat;
    
    if (Array.isArray(coordinates)) {
        lng = parseFloat(coordinates[0]);
        lat = parseFloat(coordinates[1]);
    } else if (typeof coordinates === 'object') {
        lng = parseFloat(coordinates.lng);
        lat = parseFloat(coordinates.lat);
    } else {
        console.error('Invalid coordinate format');
        return false;
    }
    
    console.log('Parsed coordinates:', { lng, lat });
    
    if (isNaN(lng) || isNaN(lat)) {
        console.error('Coordinates are not valid numbers');
        return false;
    }
    
    if (lng < -180 || lng > 180 || lat < -90 || lat > 90) {
        console.error('Coordinates out of valid range');
        return false;
    }
    
    console.log('✅ Coordinates are valid');
    return true;
};

// Popup action functions
window.viewReportDetails = function(reportId) {
    console.log('Viewing details for report:', reportId);
    
    const report = allReports.find(r => (r._id || r.id) === reportId);
    if (!report) {
        showNotification('Report not found', 'error');
        return;
    }
    
    // Create detailed modal
    const modal = document.createElement('div');
    modal.className = 'modal report-detail-modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>
                    <i class="fas ${getCategoryIcon(report.category || report.type)}"></i>
                    ${report.title || getReportTypeLabel(report.category || report.type)}
                </h2>
                <span class="close" onclick="this.closest('.modal').remove()">&times;</span>
            </div>
            <div class="modal-body">
                <div class="report-detail-content">
                    <div class="report-badges">
                        <span class="badge status-badge ${getStatusClass(report.status)}">
                            ${formatStatus(report.status)}
                        </span>
                        <span class="badge priority-badge ${getPriorityClass(report.priority || 'medium')}">
                            ${(report.priority || 'medium').toUpperCase()} Priority
                        </span>
                        <span class="badge category-badge">
                            <i class="fas ${getCategoryIcon(report.category || report.type)}"></i>
                            ${getReportTypeLabel(report.category || report.type)}
                        </span>
                    </div>
                    
                    <div class="report-info">
                        <h4>Description</h4>
                        <p>${report.description}</p>
                        
                        <h4>Location</h4>
                        <p><i class="fas fa-map-marker-alt"></i> ${report.location?.address || report.location}</p>
                        
                        <h4>Report Details</h4>
                        <div class="report-meta-grid">
                            <div class="meta-item">
                                <strong>Reported by:</strong> ${getReporterName(report.reporter)}
                            </div>
                            <div class="meta-item">
                                <strong>Date:</strong> ${new Date(report.createdAt || report.timestamp).toLocaleDateString()}
                            </div>
                            <div class="meta-item">
                                <strong>Time:</strong> ${new Date(report.createdAt || report.timestamp).toLocaleTimeString()}
                            </div>
                            <div class="meta-item">
                                <strong>Report ID:</strong> ${reportId}
                            </div>
                        </div>
                        
                        ${report.votes || report.upvoteCount !== undefined ? `
                        <h4>Community Support</h4>
                        <div class="vote-stats">
                            <div class="vote-item">
                                <i class="fas fa-thumbs-up"></i>
                                <span>${report.votes?.upvotes?.length || report.upvoteCount || 0} Upvotes</span>
                            </div>
                            ${report.votes?.downvotes ? `
                            <div class="vote-item">
                                <i class="fas fa-thumbs-down"></i>
                                <span>${report.votes.downvotes.length} Downvotes</span>
                            </div>
                            ` : ''}
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Close modal when clicking outside
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.remove();
            document.body.style.overflow = 'auto';
        }
    });
};

window.shareReport = function(reportId) {
    console.log('Sharing report:', reportId);
    
    const report = allReports.find(r => (r._id || r.id) === reportId);
    if (!report) {
        showNotification('Report not found', 'error');
        return;
    }
    
    const shareText = `Check out this civic issue: ${report.title || getReportTypeLabel(report.category || report.type)} - ${window.location.origin}#report-${reportId}`;
    
    if (navigator.share) {
        navigator.share({
            title: report.title || getReportTypeLabel(report.category || report.type),
            text: report.description,
            url: `${window.location.origin}#report-${reportId}`
        }).then(() => {
            showNotification('Report shared successfully!', 'success');
        }).catch(() => {
            // Fallback to clipboard
            copyToClipboard(shareText);
        });
    } else {
        copyToClipboard(shareText);
    }
};

window.voteOnReportFromMap = function(reportId) {
    console.log('Voting on report from map:', reportId);
    
    if (!isUserLoggedIn) {
        showNotification('Please login to vote on reports', 'info');
        openAuthModal();
        return;
    }
    
    // Find and update the report
    const report = allReports.find(r => (r._id || r.id) === reportId);
    if (!report) {
        showNotification('Report not found', 'error');
        return;
    }
    
    // Simulate voting (in a real app, this would call the API)
    if (!report.votes) {
        report.votes = { upvotes: [], downvotes: [] };
    }
    
    const userId = currentUser?.id || currentUser?._id || 'current-user';
    
    if (!report.votes.upvotes.includes(userId)) {
        report.votes.upvotes.push(userId);
        showNotification('Vote added! Thank you for supporting this issue.', 'success');
        
        // Refresh map markers to update vote count
        addReportMarkers();
    } else {
        showNotification('You have already voted on this report', 'info');
    }
};

// Helper function to copy text to clipboard
function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            showNotification('Report link copied to clipboard!', 'success');
        }).catch(() => {
            showNotification('Unable to copy link', 'error');
        });
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            showNotification('Report link copied to clipboard!', 'success');
        } catch (err) {
            showNotification('Unable to copy link', 'error');
        }
        document.body.removeChild(textArea);
    }
}