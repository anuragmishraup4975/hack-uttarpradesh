// Enhanced Report page JavaScript - Community View with API integration

// Community reports data
let communityReports = [];
let filteredReports = [];
let currentFilters = {
    category: 'all',
    status: 'all',
    priority: 'all',
    sortBy: 'newest',
    search: ''
};
let currentView = 'grid';
let currentPage = 1;
let reportsPerPage = 12;

// Initialize report page
document.addEventListener('DOMContentLoaded', function() {
    console.log('=== COMMUNITY PAGE INITIALIZATION START ===');
    
    if (document.getElementById('reportsGrid')) {
        console.log('Reports grid found, loading community data...');
        
        // Load reports from API
        loadReportsFromAPI();
        setupReportFilters();
        setupReportEventListeners();
        
        console.log('=== COMMUNITY PAGE INITIALIZATION COMPLETE ===');
    } else {
        console.log('Reports grid not found, skipping community initialization');
    }
});

// Load reports from API
async function loadReportsFromAPI() {
    try {
        console.log('Loading reports from API...');
        
        const response = await api.getReports({ 
            limit: 100, 
            sortBy: 'createdAt', 
            sortOrder: 'desc' 
        });
        
        if (response.success) {
            communityReports = response.data.reports.map(report => ({
                id: report.id,
                title: report.title,
                description: report.description,
                category: report.category,
                priority: report.priority,
                status: report.status,
                location: report.location?.address || 'Unknown Location',
                coordinates: report.location?.coordinates || [80.3319, 26.4499],
                reporter: getReporterName(report.reporter),
                createdAt: report.createdAt,
                votes: report.votes || { upvotes: [], downvotes: [] },
                comments: report.comments || [],
                images: report.images || []
            }));
            
            console.log('Loaded reports from API:', communityReports.length);
            updateStatsSummary();
            applyFiltersAndDisplay();
        }
        
    } catch (error) {
        console.error('Failed to load reports from API:', error);
        
        // Fallback to dummy data
        loadFallbackReports();
    }
}

// Get reporter name (handle different data formats)
function getReporterName(reporter) {
    if (typeof reporter === 'string') {
        return 'Community Member';
    }
    if (reporter && reporter.name) {
        return reporter.name;
    }
    return 'Anonymous';
}

// Fallback reports when API is not available
function loadFallbackReports() {
    console.log('Loading fallback reports...');
    
    communityReports = [
        {
            id: '1001',
            title: 'Large pothole on Mall Road',
            description: 'Large pothole on Mall Road causing serious traffic issues and vehicle damage. Multiple vehicles have been damaged due to this pothole.',
            category: 'pothole',
            priority: 'high',
            status: 'pending',
            location: 'Mall Road, Civil Lines, Kanpur',
            coordinates: [80.3319, 26.4499],
            reporter: 'Rajesh Kumar',
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: ['user1', 'user2', 'user3', 'user4', 'user5'], downvotes: [] },
            comments: [
                { user: 'Priya S.', text: 'This is really dangerous, especially at night!', time: '2 hours ago' },
                { user: 'Amit K.', text: 'My car tire got damaged here yesterday.', time: '4 hours ago' }
            ],
            images: []
        },
        {
            id: '1002',
            title: 'Broken streetlight in residential area',
            description: 'Broken streetlight creating safety concerns in residential area during night hours. The area becomes very dark and unsafe for pedestrians.',
            category: 'streetlight',
            priority: 'medium',
            status: 'in-progress',
            location: 'Swaroop Nagar Main Road, Kanpur',
            coordinates: [80.3496, 26.4850],
            reporter: 'Priya Sharma',
            createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: ['user1', 'user2', 'user3'], downvotes: [] },
            comments: [
                { user: 'Local Resident', text: 'Work has started, should be fixed soon.', time: '1 hour ago' }
            ],
            images: []
        },
        {
            id: '1003',
            title: 'Overflowing garbage bins near market',
            description: 'Overflowing garbage bins near market area attracting pests and creating unhygienic conditions. Immediate attention required for public health.',
            category: 'garbage',
            priority: 'high',
            status: 'resolved',
            location: 'Phool Bagh Market, Kanpur',
            coordinates: [80.3318, 26.4609],
            reporter: 'Amit Singh',
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: ['user1', 'user2', 'user3', 'user4', 'user5', 'user6', 'user7', 'user8'], downvotes: ['user9'] },
            comments: [
                { user: 'Municipal Worker', text: 'Issue has been resolved. New bins installed.', time: '6 hours ago' },
                { user: 'Shop Owner', text: 'Thank you for the quick response!', time: '8 hours ago' },
                { user: 'Resident', text: 'Much better now, area is clean.', time: '10 hours ago' },
                { user: 'Health Inspector', text: 'Regular monitoring will continue.', time: '12 hours ago' }
            ],
            images: []
        },
        {
            id: '1004',
            title: 'Water pipeline leakage causing road flooding',
            description: 'Water leakage from main pipeline causing road flooding and water wastage. The road is becoming muddy and difficult to pass through.',
            category: 'water',
            priority: 'urgent',
            status: 'pending',
            location: 'Kidwai Nagar, Kanpur',
            coordinates: [80.3311, 26.4729],
            reporter: 'Sunita Devi',
            createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: ['user1', 'user2', 'user3', 'user4', 'user5', 'user6', 'user7', 'user8', 'user9', 'user10', 'user11', 'user12'], downvotes: [] },
            comments: [
                { user: 'Water Dept', text: 'Team has been dispatched to investigate.', time: '30 minutes ago' },
                { user: 'Local Resident', text: 'Water is flowing into nearby houses too.', time: '2 hours ago' },
                { user: 'Concerned Citizen', text: 'This is wasting so much water!', time: '3 hours ago' },
                { user: 'Traffic Police', text: 'Road is partially blocked due to flooding.', time: '4 hours ago' },
                { user: 'Shop Owner', text: 'Affecting business, please fix urgently.', time: '5 hours ago' },
                { user: 'Resident', text: 'Been going on for hours now.', time: '6 hours ago' }
            ],
            images: []
        },
        {
            id: '1005',
            title: 'Multiple potholes on GT Road affecting traffic',
            description: 'Multiple potholes on GT Road affecting heavy vehicle movement. Truck drivers are complaining about vehicle damage and traffic congestion.',
            category: 'pothole',
            priority: 'high',
            status: 'in-progress',
            location: 'GT Road, Panki, Kanpur',
            coordinates: [80.2329, 26.4073],
            reporter: 'Vikash Gupta',
            createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: ['user1', 'user2', 'user3', 'user4', 'user5', 'user6', 'user7'], downvotes: ['user8'] },
            comments: [
                { user: 'PWD Engineer', text: 'Road repair work scheduled for next week.', time: '2 hours ago' },
                { user: 'Truck Driver', text: 'Very difficult to drive heavy vehicles here.', time: '5 hours ago' },
                { user: 'Commuter', text: 'Daily traffic jams due to these potholes.', time: '8 hours ago' }
            ],
            images: []
        }
    ];
    
    console.log('Fallback reports loaded:', communityReports.length);
    updateStatsSummary();
    applyFiltersAndDisplay();
}

// Update stats summary in header
function updateStatsSummary() {
    const total = communityReports.length;
    const active = communityReports.filter(r => r.status === 'pending' || r.status === 'in-progress').length;
    const resolved = communityReports.filter(r => r.status === 'resolved').length;
    
    document.getElementById('totalReportsCount').textContent = total;
    document.getElementById('activeReportsCount').textContent = active;
    document.getElementById('resolvedReportsCount').textContent = resolved;
}

// Apply filters and display reports
function applyFiltersAndDisplay() {
    filteredReports = [...communityReports];
    
    // Apply search filter
    if (currentFilters.search) {
        const searchTerm = currentFilters.search.toLowerCase();
        filteredReports = filteredReports.filter(report => 
            report.title.toLowerCase().includes(searchTerm) ||
            report.description.toLowerCase().includes(searchTerm) ||
            report.location.toLowerCase().includes(searchTerm) ||
            report.reporter.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply category filter
    if (currentFilters.category !== 'all') {
        filteredReports = filteredReports.filter(report => report.category === currentFilters.category);
    }
    
    // Apply status filter
    if (currentFilters.status !== 'all') {
        filteredReports = filteredReports.filter(report => report.status === currentFilters.status);
    }
    
    // Apply priority filter
    if (currentFilters.priority !== 'all') {
        filteredReports = filteredReports.filter(report => report.priority === currentFilters.priority);
    }
    
    // Apply sorting
    filteredReports.sort((a, b) => {
        switch (currentFilters.sortBy) {
            case 'newest':
                return new Date(b.createdAt) - new Date(a.createdAt);
            case 'oldest':
                return new Date(a.createdAt) - new Date(b.createdAt);
            case 'priority':
                const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
                return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
            case 'status':
                const statusOrder = { pending: 3, 'in-progress': 2, resolved: 1 };
                return (statusOrder[b.status] || 0) - (statusOrder[a.status] || 0);
            case 'location':
                return a.location.localeCompare(b.location);
            default:
                return 0;
        }
    });
    
    // Reset to first page when filters change
    currentPage = 1;
    
    displayReports();
    updateResultsCount();
}

// Display reports with pagination
function displayReports() {
    const reportsGrid = document.getElementById('reportsGrid');
    if (!reportsGrid) return;
    
    // Calculate pagination
    const totalPages = Math.ceil(filteredReports.length / reportsPerPage);
    const startIndex = (currentPage - 1) * reportsPerPage;
    const endIndex = startIndex + reportsPerPage;
    const reportsToShow = filteredReports.slice(startIndex, endIndex);
    
    if (reportsToShow.length === 0) {
        reportsGrid.innerHTML = `
            <div class="no-reports">
                <i class="fas fa-search"></i>
                <h3>No Reports Found</h3>
                <p>No reports match your current search and filter criteria.<br>Try adjusting your filters or search terms.</p>
            </div>
        `;
        document.getElementById('paginationContainer').style.display = 'none';
        return;
    }
    
    // Apply view class
    reportsGrid.className = `reports-grid ${currentView}-view`;
    
    reportsGrid.innerHTML = '';
    
    reportsToShow.forEach(report => {
        const reportCard = createReportCard(report);
        reportsGrid.appendChild(reportCard);
    });
    
    // Update pagination
    updatePagination(totalPages);
}

// Create enhanced report card element
function createReportCard(report) {
    const card = document.createElement('div');
    card.className = 'report-card';
    card.dataset.reportId = report.id;
    
    const statusClass = getStatusClass(report.status);
    const priorityClass = getPriorityClass(report.priority);
    const categoryIcon = getCategoryIcon(report.category);
    
    card.innerHTML = `
        <div class="report-header">
            <div class="report-category">
                <i class="fas ${categoryIcon}"></i>
                <span>${getCategoryLabel(report.category)}</span>
            </div>
            <div class="report-status ${statusClass}">
                ${formatStatus(report.status)}
            </div>
        </div>
        
        <div class="report-content">
            <h3 class="report-title">${report.title}</h3>
            <p class="report-description">${report.description}</p>
            
            <div class="report-location">
                <i class="fas fa-map-marker-alt"></i>
                <span>${report.location}</span>
            </div>
        </div>
        
        <div class="report-meta">
            <div class="report-priority ${priorityClass}">
                <i class="fas fa-exclamation-triangle"></i>
                ${report.priority} priority
            </div>
            <div class="report-time">
                <i class="fas fa-clock"></i>
                ${formatTimeAgo(new Date(report.createdAt))}
            </div>
        </div>
        
        <div class="report-actions">
            <button class="btn-vote upvote" onclick="voteOnReport('${report.id}', 'upvote')" title="Upvote">
                <i class="fas fa-thumbs-up"></i>
                <span>${report.votes.upvotes.length}</span>
            </button>
            <button class="btn-vote downvote" onclick="voteOnReport('${report.id}', 'downvote')" title="Downvote">
                <i class="fas fa-thumbs-down"></i>
                <span>${report.votes.downvotes.length}</span>
            </button>
            <button class="btn-comment" onclick="openReportDetail('${report.id}')" title="View Details">
                <i class="fas fa-comment"></i>
                <span>${report.comments.length}</span>
            </button>
            <button class="btn-share" onclick="shareReport('${report.id}')" title="Share">
                <i class="fas fa-share"></i>
            </button>
        </div>
    `;
    
    // Add click handler for card
    card.addEventListener('click', (e) => {
        // Don't trigger if clicking on action buttons
        if (!e.target.closest('.report-actions')) {
            openReportDetail(report.id);
        }
    });
    
    return card;
}

// Helper functions for styling
function getStatusClass(status) {
    switch (status) {
        case 'pending': return 'status-pending';
        case 'in-progress': return 'status-progress';
        case 'resolved': return 'status-resolved';
        default: return 'status-pending';
    }
}

function getPriorityClass(priority) {
    switch (priority) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'medium': return 'priority-medium';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}

function getCategoryIcon(category) {
    const icons = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    return icons[category] || icons.other;
}

function getCategoryLabel(category) {
    const labels = {
        'pothole': 'Pothole',
        'streetlight': 'Streetlight',
        'garbage': 'Garbage',
        'water': 'Water Issue',
        'construction': 'Construction',
        'other': 'Other'
    };
    return labels[category] || 'Other';
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
        return 'Just now';
    }
}

// Setup filter event listeners
function setupReportFilters() {
    // Category filter
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', (e) => {
            currentFilters.category = e.target.value;
            displayReports();
        });
    }
    
    // Status filter
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilters.status = e.target.value;
            displayReports();
        });
    }
    
    // Priority filter
    const priorityFilter = document.getElementById('priorityFilter');
    if (priorityFilter) {
        priorityFilter.addEventListener('change', (e) => {
            currentFilters.priority = e.target.value;
            displayReports();
        });
    }
    
    // Sort filter
    const sortFilter = document.getElementById('sortFilter');
    if (sortFilter) {
        sortFilter.addEventListener('change', (e) => {
            currentFilters.sortBy = e.target.value;
            displayReports();
        });
    }
    
    // Search functionality
    const searchInput = document.getElementById('searchReports');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
    }
}

// Handle search
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase().trim();
    
    if (searchTerm === '') {
        displayReports();
        return;
    }
    
    const filteredReports = communityReports.filter(report => 
        report.title.toLowerCase().includes(searchTerm) ||
        report.description.toLowerCase().includes(searchTerm) ||
        report.location.toLowerCase().includes(searchTerm)
    );
    
    displayFilteredReports(filteredReports);
}

// Display filtered reports (for search)
function displayFilteredReports(reports) {
    const reportsGrid = document.getElementById('reportsGrid');
    if (!reportsGrid) return;
    
    if (reports.length === 0) {
        reportsGrid.innerHTML = `
            <div class="no-reports">
                <i class="fas fa-search"></i>
                <h3>No Results Found</h3>
                <p>Try adjusting your search terms.</p>
            </div>
        `;
        return;
    }
    
    reportsGrid.innerHTML = '';
    
    reports.forEach(report => {
        const reportCard = createReportCard(report);
        reportsGrid.appendChild(reportCard);
    });
    
    updateResultsCount(reports.length);
}

// Update results count
function updateResultsCount(count) {
    const resultsCount = document.getElementById('resultsCount');
    if (resultsCount) {
        resultsCount.textContent = `${count} report${count !== 1 ? 's' : ''} found`;
    }
}

// Setup other event listeners
function setupReportEventListeners() {
    // New report button
    const newReportBtn = document.getElementById('newReportBtn');
    if (newReportBtn) {
        newReportBtn.addEventListener('click', openNewReportModal);
    }
    
    // Close modal buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal') || e.target.classList.contains('close-modal')) {
            closeAllModals();
        }
    });
}

// Voting functionality
async function voteOnReport(reportId, voteType) {
    try {
        const response = await api.voteOnReport(reportId, voteType);
        
        if (response.success) {
            // Update local data
            const report = communityReports.find(r => r.id === reportId);
            if (report) {
                if (voteType === 'upvote') {
                    report.votes.upvotes.push('current-user');
                } else {
                    report.votes.downvotes.push('current-user');
                }
                displayReports();
            }
            
            showNotification(`Vote ${voteType === 'upvote' ? 'added' : 'removed'} successfully!`, 'success');
        }
        
    } catch (error) {
        console.error('Vote error:', error);
        showNotification('Please login to vote on reports.', 'info');
    }
}

// Comment functionality
function openCommentModal(reportId) {
    // For now, just show a notification
    showNotification('Comment feature coming soon!', 'info');
}

// Share functionality
function shareReport(reportId) {
    const report = communityReports.find(r => r.id === reportId);
    if (report) {
        const shareText = `Check out this civic issue: ${report.title} - ${window.location.origin}/report.html#${reportId}`;
        
        if (navigator.share) {
            navigator.share({
                title: report.title,
                text: report.description,
                url: `${window.location.origin}/report.html#${reportId}`
            });
        } else {
            navigator.clipboard.writeText(shareText).then(() => {
                showNotification('Report link copied to clipboard!', 'success');
            });
        }
    }
}

// New report modal
function openNewReportModal() {
    showNotification('Please use the main dashboard to submit new reports.', 'info');
}

// Close all modals
function closeAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}
// Helper functions for styling
function getStatusClass(status) {
    switch (status) {
        case 'pending': return 'status-pending';
        case 'in-progress': return 'status-progress';
        case 'resolved': return 'status-resolved';
        default: return 'status-pending';
    }
}

function getPriorityClass(priority) {
    switch (priority) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'medium': return 'priority-medium';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}

function getCategoryIcon(category) {
    const icons = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    return icons[category] || icons.other;
}

function getCategoryLabel(category) {
    const labels = {
        'pothole': 'Pothole',
        'streetlight': 'Streetlight',
        'garbage': 'Garbage',
        'water': 'Water Issue',
        'construction': 'Construction',
        'other': 'Other'
    };
    return labels[category] || 'Other';
}

function formatStatus(status) {
    return status.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
        return 'Just now';
    }
}

// Update results count
function updateResultsCount() {
    const resultsCount = document.getElementById('resultsCount');
    if (resultsCount) {
        const count = filteredReports.length;
        const total = communityReports.length;
        
        if (count === total) {
            resultsCount.textContent = `Showing all ${count} report${count !== 1 ? 's' : ''}`;
        } else {
            resultsCount.textContent = `Showing ${count} of ${total} report${total !== 1 ? 's' : ''}`;
        }
    }
}

// Update pagination
function updatePagination(totalPages) {
    const paginationContainer = document.getElementById('paginationContainer');
    const prevBtn = document.getElementById('prevPage');
    const nextBtn = document.getElementById('nextPage');
    const pageInfo = document.getElementById('pageInfo');
    
    if (totalPages <= 1) {
        paginationContainer.style.display = 'none';
        return;
    }
    
    paginationContainer.style.display = 'flex';
    
    // Update buttons
    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= totalPages;
    
    // Update page info
    pageInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    
    // Add event listeners
    prevBtn.onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            displayReports();
        }
    };
    
    nextBtn.onclick = () => {
        if (currentPage < totalPages) {
            currentPage++;
            displayReports();
        }
    };
}

// Setup filter event listeners
function setupReportFilters() {
    // Search input
    const searchInput = document.getElementById('searchReports');
    const clearSearch = document.getElementById('clearSearch');
    
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
        
        // Show/hide clear button
        searchInput.addEventListener('input', (e) => {
            clearSearch.style.display = e.target.value ? 'block' : 'none';
        });
    }
    
    if (clearSearch) {
        clearSearch.addEventListener('click', () => {
            searchInput.value = '';
            clearSearch.style.display = 'none';
            currentFilters.search = '';
            applyFiltersAndDisplay();
        });
    }
    
    // Category filter
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', (e) => {
            currentFilters.category = e.target.value;
            applyFiltersAndDisplay();
        });
    }
    
    // Status filter
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilters.status = e.target.value;
            applyFiltersAndDisplay();
        });
    }
    
    // Priority filter
    const priorityFilter = document.getElementById('priorityFilter');
    if (priorityFilter) {
        priorityFilter.addEventListener('change', (e) => {
            currentFilters.priority = e.target.value;
            applyFiltersAndDisplay();
        });
    }
    
    // Sort filter
    const sortFilter = document.getElementById('sortFilter');
    if (sortFilter) {
        sortFilter.addEventListener('change', (e) => {
            currentFilters.sortBy = e.target.value;
            applyFiltersAndDisplay();
        });
    }
    
    // View toggle buttons
    const viewBtns = document.querySelectorAll('.view-btn');
    viewBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            viewBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentView = btn.dataset.view;
            displayReports();
        });
    });
}

// Handle search
function handleSearch(e) {
    currentFilters.search = e.target.value.toLowerCase().trim();
    applyFiltersAndDisplay();
}

// Reset all filters
function resetFilters() {
    currentFilters = {
        category: 'all',
        status: 'all',
        priority: 'all',
        sortBy: 'newest',
        search: ''
    };
    
    // Reset form elements
    document.getElementById('searchReports').value = '';
    document.getElementById('clearSearch').style.display = 'none';
    document.getElementById('categoryFilter').value = 'all';
    document.getElementById('statusFilter').value = 'all';
    document.getElementById('priorityFilter').value = 'all';
    document.getElementById('sortFilter').value = 'newest';
    
    applyFiltersAndDisplay();
}

// Setup other event listeners
function setupReportEventListeners() {
    // Mobile menu toggle (inherited from main script)
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
}

// Voting functionality
async function voteOnReport(reportId, voteType) {
    try {
        const response = await api.voteOnReport(reportId, voteType);
        
        if (response.success) {
            // Update local data
            const report = communityReports.find(r => r.id === reportId);
            if (report) {
                if (voteType === 'upvote') {
                    report.votes.upvotes.push('current-user');
                } else {
                    report.votes.downvotes.push('current-user');
                }
                applyFiltersAndDisplay();
            }
            
            showNotification(`Vote ${voteType === 'upvote' ? 'added' : 'removed'} successfully!`, 'success');
        }
        
    } catch (error) {
        console.error('Vote error:', error);
        
        // Simulate voting for demo
        const report = communityReports.find(r => r.id === reportId);
        if (report) {
            if (voteType === 'upvote') {
                report.votes.upvotes.push('demo-user');
            } else {
                report.votes.downvotes.push('demo-user');
            }
            applyFiltersAndDisplay();
            showNotification('Vote recorded (demo mode)', 'info');
        }
    }
}

// Open report detail modal
function openReportDetail(reportId) {
    const report = communityReports.find(r => r.id === reportId);
    if (!report) return;
    
    const modal = document.getElementById('reportDetailModal');
    const title = document.getElementById('modalReportTitle');
    const content = document.getElementById('modalReportContent');
    
    title.textContent = report.title;
    
    content.innerHTML = `
        <div class="report-detail-content">
            <div class="report-detail-header">
                <div class="report-badges">
                    <span class="badge category-badge">
                        <i class="fas ${getCategoryIcon(report.category)}"></i>
                        ${getCategoryLabel(report.category)}
                    </span>
                    <span class="badge status-badge ${getStatusClass(report.status)}">
                        ${formatStatus(report.status)}
                    </span>
                    <span class="badge priority-badge ${getPriorityClass(report.priority)}">
                        <i class="fas fa-exclamation-triangle"></i>
                        ${report.priority.toUpperCase()} Priority
                    </span>
                </div>
                
                <div class="report-meta-info">
                    <div class="meta-item">
                        <i class="fas fa-user"></i>
                        <span>Reported by ${report.reporter}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-clock"></i>
                        <span>${formatTimeAgo(new Date(report.createdAt))}</span>
                    </div>
                    <div class="meta-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${report.location}</span>
                    </div>
                </div>
            </div>
            
            <div class="report-detail-body">
                <h4>Description</h4>
                <p>${report.description}</p>
                
                <div class="report-stats">
                    <div class="stat-item">
                        <i class="fas fa-thumbs-up"></i>
                        <span>${report.votes.upvotes.length} Upvotes</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-thumbs-down"></i>
                        <span>${report.votes.downvotes.length} Downvotes</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-comments"></i>
                        <span>${report.comments.length} Comments</span>
                    </div>
                </div>
                
                ${report.comments.length > 0 ? `
                    <div class="comments-section">
                        <h4>Comments</h4>
                        <div class="comments-list">
                            ${report.comments.map(comment => `
                                <div class="comment-item">
                                    <div class="comment-header">
                                        <strong>${comment.user}</strong>
                                        <span class="comment-time">${comment.time}</span>
                                    </div>
                                    <p>${comment.text}</p>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
    
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
}

// Close report detail modal
function closeReportDetailModal() {
    const modal = document.getElementById('reportDetailModal');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Share functionality
function shareReport(reportId) {
    const report = communityReports.find(r => r.id === reportId);
    if (report) {
        const shareText = `Check out this civic issue: ${report.title} - ${window.location.origin}/report.html#${reportId}`;
        
        if (navigator.share) {
            navigator.share({
                title: report.title,
                text: report.description,
                url: `${window.location.origin}/report.html#${reportId}`
            });
        } else {
            navigator.clipboard.writeText(shareText).then(() => {
                showNotification('Report link copied to clipboard!', 'success');
            }).catch(() => {
                showNotification('Unable to copy link', 'error');
            });
        }
    }
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Show notification
function showNotification(message, type = 'info') {
    // Use the notification system from main script if available
    if (window.showNotification) {
        window.showNotification(message, type);
        return;
    }
    
    // Fallback notification
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}

// Close modal when clicking outside
window.addEventListener('click', (event) => {
    const modal = document.getElementById('reportDetailModal');
    if (event.target === modal) {
        closeReportDetailModal();
    }
});