@echo off
echo ========================================
echo CivicPulse Sign-In Page Demo
echo ========================================
echo.
echo [1/2] Starting server...
start /B node server-simple.js

echo Waiting for server to start...
timeout /t 3 /nobreak > nul

echo.
echo [2/2] Opening sign-in page...
echo.
echo Sign-In Page: http://localhost:5000/signin.html
echo Dashboard: http://localhost:5000
echo.
echo Demo Instructions:
echo 1. Enter any valid email address
echo 2. Use OTP code: 123456
echo 3. Get your embedded wallet
echo 4. Access the dashboard
echo.

start http://localhost:5000/signin.html

echo ========================================
echo Demo is ready! Press Ctrl+C to stop.
echo ========================================
pause