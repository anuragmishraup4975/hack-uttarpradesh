// Sign In Page JavaScript - Real World Authentication
class SignInManager {
    constructor() {
        this.currentForm = 'signin'; // 'signin', 'signup', 'forgot'
        this.isLoading = false;
        this.users = this.loadUsers(); // Load existing users from localStorage
        
        this.init();
    }
    
    async init() {
        console.log('Initializing Sign In Manager...');
        
        try {
            // Check if user is already logged in
            const currentUser = this.getCurrentUser();
            if (currentUser) {
                this.redirectToDashboard();
                return;
            }
            
            // Setup event listeners
            this.setupEventListeners();
            
            console.log('Sign In Manager initialized successfully');
        } catch (error) {
            console.error('Failed to initialize Sign In Manager:', error);
            this.showNotification('Failed to initialize authentication. Please refresh the page.', 'error');
        }
    }
    
    
    loadUsers() {
        try {
            const users = localStorage.getItem('civic_users');
            return users ? JSON.parse(users) : [];
        } catch (error) {
            console.error('Error loading users:', error);
            return [];
        }
    }
    
    saveUsers() {
        try {
            localStorage.setItem('civic_users', JSON.stringify(this.users));
        } catch (error) {
            console.error('Error saving users:', error);
        }
    }
    
    getCurrentUser() {
        try {
            const user = localStorage.getItem('civic_user');
            return user ? JSON.parse(user) : null;
        } catch (error) {
            console.error('Error getting current user:', error);
            return null;
        }
    }
    
    setCurrentUser(user) {
        try {
            localStorage.setItem('civic_user', JSON.stringify(user));
            
            // Dispatch auth state change event
            window.dispatchEvent(new CustomEvent('authStateChanged', {
                detail: { user, isAuthenticated: true }
            }));
        } catch (error) {
            console.error('Error setting current user:', error);
        }
    }
    
    setupEventListeners() {
        // Form switching
        this.setupFormSwitching();
        
        // Sign In Form
        this.setupSignInForm();
        
        // Sign Up Form
        this.setupSignUpForm();
        
        // Forgot Password Form
        this.setupForgotPasswordForm();
        
        // Social Login
        this.setupSocialLogin();
        
        // Password toggles
        this.setupPasswordToggles();
        
        // Real-time validation
        this.setupRealTimeValidation();
        
        // Animate stats on load
        this.animateStats();
    }
    
    
    setupFormSwitching() {
        // Make functions globally available
        window.showSignIn = () => this.showForm('signin');
        window.showSignUp = () => this.showForm('signup');
        window.showForgotPassword = () => this.showForm('forgot');
    }
    
    showForm(formType) {
        // Hide all forms
        document.getElementById('signinForm').style.display = 'none';
        document.getElementById('signupForm').style.display = 'none';
        document.getElementById('forgotForm').style.display = 'none';
        
        // Show selected form
        const formMap = {
            'signin': 'signinForm',
            'signup': 'signupForm',
            'forgot': 'forgotForm'
        };
        
        const formId = formMap[formType];
        if (formId) {
            document.getElementById(formId).style.display = 'block';
            this.currentForm = formType;
            
            // Clear any previous validation messages
            this.clearValidationMessages();
            
            // Focus first input
            setTimeout(() => {
                const firstInput = document.querySelector(`#${formId} input:not([type="checkbox"])`);
                if (firstInput) firstInput.focus();
            }, 100);
        }
    }
    
    setupSignInForm() {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleSignIn();
            });
        }
    }
    
    setupSignUpForm() {
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleSignUp();
            });
        }
    }
    
    setupForgotPasswordForm() {
        const resetForm = document.getElementById('resetForm');
        if (resetForm) {
            resetForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleForgotPassword();
            });
        }
    }
    
    setupSocialLogin() {
        // Make functions globally available
        window.signInWithGoogle = () => this.handleSocialLogin('google', 'signin');
        window.signInWithGitHub = () => this.handleSocialLogin('github', 'signin');
        window.signUpWithGoogle = () => this.handleSocialLogin('google', 'signup');
        window.signUpWithGitHub = () => this.handleSocialLogin('github', 'signup');
    }
    
    setupPasswordToggles() {
        window.togglePassword = (inputId) => {
            const input = document.getElementById(inputId);
            const toggle = input.parentElement.querySelector('.password-toggle i');
            
            if (input.type === 'password') {
                input.type = 'text';
                toggle.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                toggle.className = 'fas fa-eye';
            }
        };
    }
    
    setupRealTimeValidation() {
        // Email validation
        const emailInputs = ['loginEmail', 'registerEmail', 'resetEmail'];
        emailInputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('input', () => this.validateEmail(inputId));
                input.addEventListener('blur', () => this.validateEmail(inputId));
            }
        });
        
        // Password validation
        const registerPassword = document.getElementById('registerPassword');
        if (registerPassword) {
            registerPassword.addEventListener('input', () => {
                this.validatePassword('registerPassword');
                this.validatePasswordMatch();
            });
        }
        
        const confirmPassword = document.getElementById('confirmPassword');
        if (confirmPassword) {
            confirmPassword.addEventListener('input', () => this.validatePasswordMatch());
        }
        
        // Name validation
        const registerName = document.getElementById('registerName');
        if (registerName) {
            registerName.addEventListener('input', () => this.validateName());
        }
    }
    
    
    // Validation Methods
    validateEmail(inputId) {
        const input = document.getElementById(inputId);
        const validation = document.getElementById(inputId + 'Validation');
        
        if (!input || !validation) return false;
        
        const email = input.value.trim();
        
        if (!email) {
            this.setValidation(input, validation, '', '');
            return false;
        }
        
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValid = emailRegex.test(email);
        
        if (isValid) {
            this.setValidation(input, validation, '✓ Valid email address', 'success');
            return true;
        } else {
            this.setValidation(input, validation, '✗ Please enter a valid email address', 'error');
            return false;
        }
    }
    
    validatePassword(inputId) {
        const input = document.getElementById(inputId);
        const validation = document.getElementById(inputId + 'Validation');
        const strengthContainer = document.getElementById('passwordStrength');
        
        if (!input) return false;
        
        const password = input.value;
        const strength = this.calculatePasswordStrength(password);
        
        // Update strength indicator
        if (strengthContainer && inputId === 'registerPassword') {
            this.updatePasswordStrength(strengthContainer, strength, password);
        }
        
        if (password.length === 0) {
            if (validation) this.setValidation(input, validation, '', '');
            return false;
        }
        
        if (password.length < 8) {
            if (validation) this.setValidation(input, validation, '✗ Password must be at least 8 characters', 'error');
            return false;
        }
        
        if (strength.score < 2) {
            if (validation) this.setValidation(input, validation, '⚠ Password is too weak', 'warning');
            return false;
        }
        
        if (validation) this.setValidation(input, validation, '✓ Password strength is good', 'success');
        return true;
    }
    
    validatePasswordMatch() {
        const password = document.getElementById('registerPassword');
        const confirmPassword = document.getElementById('confirmPassword');
        const validation = document.getElementById('confirmPasswordValidation');
        
        if (!password || !confirmPassword || !validation) return false;
        
        if (!confirmPassword.value) {
            this.setValidation(confirmPassword, validation, '', '');
            return false;
        }
        
        if (password.value !== confirmPassword.value) {
            this.setValidation(confirmPassword, validation, '✗ Passwords do not match', 'error');
            return false;
        }
        
        this.setValidation(confirmPassword, validation, '✓ Passwords match', 'success');
        return true;
    }
    
    validateName() {
        const input = document.getElementById('registerName');
        const validation = document.getElementById('registerNameValidation');
        
        if (!input || !validation) return false;
        
        const name = input.value.trim();
        
        if (!name) {
            this.setValidation(input, validation, '', '');
            return false;
        }
        
        if (name.length < 2) {
            this.setValidation(input, validation, '✗ Name must be at least 2 characters', 'error');
            return false;
        }
        
        if (!/^[a-zA-Z\s]+$/.test(name)) {
            this.setValidation(input, validation, '✗ Name can only contain letters and spaces', 'error');
            return false;
        }
        
        this.setValidation(input, validation, '✓ Valid name', 'success');
        return true;
    }
    
    setValidation(input, validation, message, type) {
        validation.textContent = message;
        validation.className = `input-validation ${type}`;
        
        // Update input styling
        input.classList.remove('error', 'success', 'warning');
        if (type) {
            input.classList.add(type);
        }
    }
    
    calculatePasswordStrength(password) {
        let score = 0;
        const checks = {
            length: password.length >= 8,
            lowercase: /[a-z]/.test(password),
            uppercase: /[A-Z]/.test(password),
            numbers: /\d/.test(password),
            symbols: /[^A-Za-z0-9]/.test(password)
        };
        
        // Calculate score
        Object.values(checks).forEach(check => {
            if (check) score++;
        });
        
        // Bonus for length
        if (password.length >= 12) score++;
        
        return {
            score: Math.min(score, 5),
            checks,
            level: score < 2 ? 'weak' : score < 4 ? 'medium' : 'strong'
        };
    }
    
    updatePasswordStrength(container, strength, password) {
        if (!password) {
            container.innerHTML = '';
            return;
        }
        
        const bars = Array.from({ length: 4 }, (_, i) => {
            const isActive = i < strength.score;
            const level = strength.level;
            return `<div class="strength-bar ${isActive ? level : ''}"></div>`;
        }).join('');
        
        const text = strength.level === 'weak' ? 'Weak password' :
                    strength.level === 'medium' ? 'Medium strength' :
                    'Strong password';
        
        container.innerHTML = `
            <div class="password-strength">
                ${bars}
            </div>
            <div class="strength-text ${strength.level}">${text}</div>
        `;
    }
    
    clearValidationMessages() {
        const validations = document.querySelectorAll('.input-validation');
        validations.forEach(validation => {
            validation.textContent = '';
            validation.className = 'input-validation';
        });
        
        const inputs = document.querySelectorAll('.input-field');
        inputs.forEach(input => {
            input.classList.remove('error', 'success', 'warning');
        });
        
        // Clear password strength
        const strengthContainer = document.getElementById('passwordStrength');
        if (strengthContainer) {
            strengthContainer.innerHTML = '';
        }
    }
    
    
    // Authentication Handlers
    async handleSignIn() {
        if (this.isLoading) return;
        
        const email = document.getElementById('loginEmail').value.trim();
        const password = document.getElementById('loginPassword').value;
        
        // Validate inputs
        if (!this.validateSignInForm(email, password)) {
            return;
        }
        
        this.setButtonLoading('signinBtn', true);
        this.isLoading = true;
        
        try {
            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Find user
            const user = this.users.find(u => u.email === email);
            
            if (!user) {
                throw new Error('No account found with this email address');
            }
            
            // Verify password (in real app, this would be hashed)
            if (user.password !== password) {
                throw new Error('Incorrect password');
            }
            
            // Login successful
            this.setCurrentUser(user);
            this.showNotification('Welcome back! Redirecting to dashboard...', 'success');
            
            // Redirect after short delay
            setTimeout(() => {
                this.redirectToDashboard();
            }, 1500);
            
        } catch (error) {
            console.error('Sign in failed:', error);
            this.showNotification(error.message, 'error');
        } finally {
            this.setButtonLoading('signinBtn', false);
            this.isLoading = false;
        }
    }
    
    async handleSignUp() {
        if (this.isLoading) return;
        
        const name = document.getElementById('registerName').value.trim();
        const email = document.getElementById('registerEmail').value.trim();
        const password = document.getElementById('registerPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const agreeTerms = document.getElementById('agreeTerms').checked;
        
        // Validate inputs
        if (!this.validateSignUpForm(name, email, password, confirmPassword, agreeTerms)) {
            return;
        }
        
        this.setButtonLoading('signupBtn', true);
        this.isLoading = true;
        
        try {
            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Check if user already exists
            const existingUser = this.users.find(u => u.email === email);
            if (existingUser) {
                throw new Error('An account with this email already exists');
            }
            
            // Create new user
            const newUser = {
                id: 'user_' + Date.now(),
                name: name,
                email: email,
                password: password, // In real app, this would be hashed
                profileImage: null,
                wallet: {
                    address: '0x' + Math.random().toString(16).substr(2, 40),
                    chainId: 'eip155:1'
                },
                createdAt: new Date().toISOString(),
                isVerified: true // In real app, would require email verification
            };
            
            // Add to users array and save
            this.users.push(newUser);
            this.saveUsers();
            
            // Set as current user
            this.setCurrentUser(newUser);
            
            this.showNotification('Account created successfully! Welcome to CivicPulse!', 'success');
            
            // Redirect after short delay
            setTimeout(() => {
                this.redirectToDashboard();
            }, 1500);
            
        } catch (error) {
            console.error('Sign up failed:', error);
            this.showNotification(error.message, 'error');
        } finally {
            this.setButtonLoading('signupBtn', false);
            this.isLoading = false;
        }
    }
    
    async handleForgotPassword() {
        if (this.isLoading) return;
        
        const email = document.getElementById('resetEmail').value.trim();
        
        if (!this.validateEmail('resetEmail')) {
            this.showNotification('Please enter a valid email address', 'error');
            return;
        }
        
        this.setButtonLoading('resetBtn', true);
        this.isLoading = true;
        
        try {
            // Simulate API delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Check if user exists
            const user = this.users.find(u => u.email === email);
            if (!user) {
                // Don't reveal if email exists for security
                this.showNotification('If an account with this email exists, you will receive a password reset link.', 'info');
            } else {
                this.showNotification('Password reset link sent to your email address.', 'success');
            }
            
            // Switch back to sign in form
            setTimeout(() => {
                this.showForm('signin');
            }, 2000);
            
        } catch (error) {
            console.error('Password reset failed:', error);
            this.showNotification('Failed to send reset link. Please try again.', 'error');
        } finally {
            this.setButtonLoading('resetBtn', false);
            this.isLoading = false;
        }
    }
    
    async handleSocialLogin(provider, action) {
        if (this.isLoading) return;
        
        this.isLoading = true;
        
        try {
            this.showNotification(`Connecting to ${provider}...`, 'info');
            
            // Simulate social login delay
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Create mock social user
            const socialUser = {
                id: 'user_' + Date.now(),
                name: provider === 'google' ? 'John Doe' : 'GitHub User',
                email: `user@${provider}.com`,
                profileImage: null,
                provider: provider,
                wallet: {
                    address: '0x' + Math.random().toString(16).substr(2, 40),
                    chainId: 'eip155:1'
                },
                createdAt: new Date().toISOString(),
                isVerified: true
            };
            
            // For signup, add to users array
            if (action === 'signup') {
                this.users.push(socialUser);
                this.saveUsers();
            }
            
            // Set as current user
            this.setCurrentUser(socialUser);
            
            this.showNotification(`Successfully connected with ${provider}! Redirecting...`, 'success');
            
            // Redirect after short delay
            setTimeout(() => {
                this.redirectToDashboard();
            }, 1500);
            
        } catch (error) {
            console.error(`${provider} login failed:`, error);
            this.showNotification(`Failed to connect with ${provider}. Please try again.`, 'error');
        } finally {
            this.isLoading = false;
        }
    }
    
    
    // Form Validation
    validateSignInForm(email, password) {
        let isValid = true;
        
        if (!email) {
            this.setValidation(
                document.getElementById('loginEmail'),
                document.getElementById('loginEmailValidation'),
                '✗ Email is required',
                'error'
            );
            isValid = false;
        } else if (!this.validateEmail('loginEmail')) {
            isValid = false;
        }
        
        if (!password) {
            this.setValidation(
                document.getElementById('loginPassword'),
                document.getElementById('loginPasswordValidation'),
                '✗ Password is required',
                'error'
            );
            isValid = false;
        }
        
        return isValid;
    }
    
    validateSignUpForm(name, email, password, confirmPassword, agreeTerms) {
        let isValid = true;
        
        if (!this.validateName()) {
            isValid = false;
        }
        
        if (!this.validateEmail('registerEmail')) {
            isValid = false;
        }
        
        if (!this.validatePassword('registerPassword')) {
            isValid = false;
        }
        
        if (!this.validatePasswordMatch()) {
            isValid = false;
        }
        
        if (!agreeTerms) {
            this.showNotification('Please agree to the Terms of Service and Privacy Policy', 'error');
            isValid = false;
        }
        
        return isValid;
    }
    
    
    // Utility Methods
    setButtonLoading(buttonId, isLoading) {
        const button = document.getElementById(buttonId);
        if (!button) return;
        
        const btnText = button.querySelector('.btn-text');
        const btnLoading = button.querySelector('.btn-loading');
        
        if (isLoading) {
            button.disabled = true;
            if (btnText) btnText.style.display = 'none';
            if (btnLoading) btnLoading.style.display = 'flex';
        } else {
            button.disabled = false;
            if (btnText) btnText.style.display = 'flex';
            if (btnLoading) btnLoading.style.display = 'none';
        }
    }
    
    redirectToDashboard() {
        this.showNotification('Opening dashboard...', 'success');
        
        // Small delay for better UX
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 500);
    }
    
    animateStats() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(stat => {
            const target = parseInt(stat.textContent.replace(/,/g, ''));
            const increment = target / 100;
            let current = 0;
            
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    stat.textContent = target.toLocaleString();
                    clearInterval(timer);
                } else {
                    stat.textContent = Math.floor(current).toLocaleString();
                }
            }, 20);
        });
    }
    
    showNotification(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        const icon = type === 'success' ? 'fa-check-circle' : 
                    type === 'error' ? 'fa-exclamation-circle' : 
                    'fa-info-circle';
        
        notification.innerHTML = `
            <i class="fas ${icon}"></i>
            <span>${message}</span>
        `;
        
        container.appendChild(notification);
        
        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        // Remove notification after 4 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (container.contains(notification)) {
                    container.removeChild(notification);
                }
            }, 300);
        }, 4000);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    new SignInManager();
});

// Add some interactive effects
document.addEventListener('mousemove', function(e) {
    const shapes = document.querySelectorAll('.shape');
    const mouseX = e.clientX / window.innerWidth;
    const mouseY = e.clientY / window.innerHeight;
    
    shapes.forEach((shape, index) => {
        const speed = (index + 1) * 0.5;
        const x = mouseX * speed;
        const y = mouseY * speed;
        
        shape.style.transform = `translate(${x}px, ${y}px) rotate(${x + y}deg)`;
    });
});