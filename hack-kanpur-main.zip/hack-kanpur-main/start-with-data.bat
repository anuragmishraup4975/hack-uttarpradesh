@echo off
echo ========================================
echo Starting CivicPulse with File Storage
echo ========================================
echo.

echo [1/3] Checking if sample data exists...
if not exist "data\users.json" (
    echo Creating sample data...
    node data/sample-data.js
    if %errorlevel% neq 0 (
        echo ERROR: Failed to create sample data
        pause
        exit /b 1
    )
    echo ✓ Sample data created successfully
) else (
    echo ✓ Data files already exist
)

echo.
echo [2/3] Starting the server...
echo Server will be available at: http://localhost:5000
echo Frontend will be available at: http://localhost:5000
echo API Health check: http://localhost:5000/api/health
echo.
echo Press Ctrl+C to stop the server
echo.

echo [3/3] Launching server...
npm start