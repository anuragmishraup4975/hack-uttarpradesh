@echo off
echo Testing Permanent Location Display for CivicPulse...
echo.

echo 1. Starting server...
start "CivicPulse Server" cmd /k "node server-simple.js"

echo 2. Waiting for server to start...
timeout /t 3 /nobreak > nul

echo 3. Opening permanent preview test page...
start "" "http://localhost:5000/test-permanent-preview.html"

echo 4. Opening main dashboard with permanent display...
start "" "http://localhost:5000"

echo.
echo Permanent Location Display Features:
echo ✅ No popup - information stays in form
echo ✅ Clear address display with icon
echo ✅ Formatted coordinates in monospace
echo ✅ Map status indicator
echo ✅ Clear button to remove preview
echo ✅ Smooth animations and transitions
echo ✅ Works with both GPS and manual addresses
echo.
echo Test Instructions:
echo 1. Enter an address (e.g., "Mall Road, Kanpur")
echo 2. Click the orange preview button
echo 3. See permanent display appear in the form
echo 4. Information stays visible until cleared
echo 5. Try the main dashboard report form too
echo.
echo The location information now displays permanently in the form!
echo Press any key to continue...
pause > nul