// Report page specific JavaScript - Community View with API integration

// Community reports data
let communityReports = [];
let currentFilters = {
    category: 'all',
    status: 'all',
    priority: 'all',
    sortBy: 'newest'
};

// Initialize report page
document.addEventListener('DOMContentLoaded', function() {
    console.log('=== COMMUNITY PAGE INITIALIZATION START ===');
    
    if (document.getElementById('reportsGrid')) {
        console.log('Reports grid found, loading community data...');
        
        // Load reports from API
        loadReportsFromAPI();
        setupReportFilters();
        setupReportEventListeners();
        
        console.log('=== COMMUNITY PAGE INITIALIZATION COMPLETE ===');
    } else {
        console.log('Reports grid not found, skipping community initialization');
    }
});

// Load reports from API
async function loadReportsFromAPI() {
    try {
        console.log('Loading reports from API...');
        
        const response = await api.getReports({ 
            limit: 50, 
            sortBy: 'createdAt', 
            sortOrder: 'desc' 
        });
        
        if (response.success) {
            communityReports = response.data.reports.map(report => ({
                id: report.id,
                title: report.title,
                description: report.description,
                category: report.category,
                priority: report.priority,
                status: report.status,
                location: report.location?.address || 'Unknown Location',
                coordinates: report.location?.coordinates || [80.3319, 26.4499],
                reporter: report.reporter || 'Anonymous',
                createdAt: report.createdAt,
                votes: report.votes || { upvotes: [], downvotes: [] },
                comments: report.comments || []
            }));
            
            console.log('Loaded reports from API:', communityReports.length);
            displayReports();
        }
        
    } catch (error) {
        console.error('Failed to load reports from API:', error);
        
        // Fallback to dummy data
        loadFallbackReports();
    }
}

// Fallback reports when API is not available
function loadFallbackReports() {
    console.log('Loading fallback reports...');
    
    communityReports = [
        {
            id: '1001',
            title: 'Large pothole on Mall Road',
            description: 'Large pothole on Mall Road causing serious traffic issues and vehicle damage',
            category: 'pothole',
            priority: 'high',
            status: 'pending',
            location: 'Mall Road, Civil Lines, Kanpur',
            coordinates: [80.3319, 26.4499],
            reporter: 'Rajesh Kumar',
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: [], downvotes: [] },
            comments: []
        },
        {
            id: '1002',
            title: 'Broken streetlight in residential area',
            description: 'Broken streetlight creating safety concerns in residential area during night hours',
            category: 'streetlight',
            priority: 'medium',
            status: 'in-progress',
            location: 'Swaroop Nagar Main Road, Kanpur',
            coordinates: [80.3496, 26.4850],
            reporter: 'Priya Sharma',
            createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: [], downvotes: [] },
            comments: []
        },
        {
            id: '1003',
            title: 'Overflowing garbage bins near market',
            description: 'Overflowing garbage bins near market area attracting pests and creating unhygienic conditions',
            category: 'garbage',
            priority: 'high',
            status: 'resolved',
            location: 'Phool Bagh Market, Kanpur',
            coordinates: [80.3318, 26.4609],
            reporter: 'Amit Singh',
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: [], downvotes: [] },
            comments: []
        },
        {
            id: '1004',
            title: 'Water pipeline leakage',
            description: 'Water leakage from main pipeline causing road flooding and water wastage',
            category: 'water',
            priority: 'urgent',
            status: 'pending',
            location: 'Kidwai Nagar, Kanpur',
            coordinates: [80.3311, 26.4729],
            reporter: 'Sunita Devi',
            createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: [], downvotes: [] },
            comments: []
        },
        {
            id: '1005',
            title: 'Multiple potholes on GT Road',
            description: 'Multiple potholes on GT Road affecting heavy vehicle movement',
            category: 'pothole',
            priority: 'high',
            status: 'in-progress',
            location: 'GT Road, Panki, Kanpur',
            coordinates: [80.2329, 26.4073],
            reporter: 'Vikash Gupta',
            createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            votes: { upvotes: [], downvotes: [] },
            comments: []
        }
    ];
    
    console.log('Fallback reports loaded:', communityReports.length);
    displayReports();
}

// Display reports in the grid
function displayReports() {
    const reportsGrid = document.getElementById('reportsGrid');
    if (!reportsGrid) return;
    
    // Apply filters
    const filteredReports = applyFilters(communityReports);
    
    if (filteredReports.length === 0) {
        reportsGrid.innerHTML = `
            <div class="no-reports">
                <i class="fas fa-clipboard-list"></i>
                <h3>No Reports Found</h3>
                <p>No reports match your current filters.</p>
            </div>
        `;
        return;
    }
    
    reportsGrid.innerHTML = '';
    
    filteredReports.forEach(report => {
        const reportCard = createReportCard(report);
        reportsGrid.appendChild(reportCard);
    });
    
    // Update results count
    updateResultsCount(filteredReports.length);
}

// Apply filters to reports
function applyFilters(reports) {
    let filtered = [...reports];
    
    // Category filter
    if (currentFilters.category !== 'all') {
        filtered = filtered.filter(report => report.category === currentFilters.category);
    }
    
    // Status filter
    if (currentFilters.status !== 'all') {
        filtered = filtered.filter(report => report.status === currentFilters.status);
    }
    
    // Priority filter
    if (currentFilters.priority !== 'all') {
        filtered = filtered.filter(report => report.priority === currentFilters.priority);
    }
    
    // Sort reports
    filtered.sort((a, b) => {
        switch (currentFilters.sortBy) {
            case 'newest':
                return new Date(b.createdAt) - new Date(a.createdAt);
            case 'oldest':
                return new Date(a.createdAt) - new Date(b.createdAt);
            case 'priority':
                const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
                return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
            case 'status':
                const statusOrder = { pending: 3, 'in-progress': 2, resolved: 1 };
                return (statusOrder[b.status] || 0) - (statusOrder[a.status] || 0);
            default:
                return 0;
        }
    });
    
    return filtered;
}

// Create report card element
function createReportCard(report) {
    const card = document.createElement('div');
    card.className = 'report-card';
    card.dataset.reportId = report.id;
    
    const statusClass = getStatusClass(report.status);
    const priorityClass = getPriorityClass(report.priority);
    const categoryIcon = getCategoryIcon(report.category);
    
    card.innerHTML = `
        <div class="report-header">
            <div class="report-category">
                <i class="fas ${categoryIcon}"></i>
                <span>${getCategoryLabel(report.category)}</span>
            </div>
            <div class="report-status ${statusClass}">
                ${report.status.replace('-', ' ')}
            </div>
        </div>
        
        <div class="report-content">
            <h3 class="report-title">${report.title}</h3>
            <p class="report-description">${report.description}</p>
            
            <div class="report-location">
                <i class="fas fa-map-marker-alt"></i>
                <span>${report.location}</span>
            </div>
        </div>
        
        <div class="report-meta">
            <div class="report-priority ${priorityClass}">
                <i class="fas fa-exclamation-triangle"></i>
                ${report.priority} priority
            </div>
            <div class="report-time">
                <i class="fas fa-clock"></i>
                ${formatTimeAgo(new Date(report.createdAt))}
            </div>
        </div>
        
        <div class="report-actions">
            <button class="btn-vote upvote" onclick="voteOnReport('${report.id}', 'upvote')">
                <i class="fas fa-thumbs-up"></i>
                <span>${report.votes.upvotes.length}</span>
            </button>
            <button class="btn-vote downvote" onclick="voteOnReport('${report.id}', 'downvote')">
                <i class="fas fa-thumbs-down"></i>
                <span>${report.votes.downvotes.length}</span>
            </button>
            <button class="btn-comment" onclick="openCommentModal('${report.id}')">
                <i class="fas fa-comment"></i>
                <span>${report.comments.length}</span>
            </button>
            <button class="btn-share" onclick="shareReport('${report.id}')">
                <i class="fas fa-share"></i>
            </button>
        </div>
    `;
    
    return card;
}

// Helper functions for styling
function getStatusClass(status) {
    switch (status) {
        case 'pending': return 'status-pending';
        case 'in-progress': return 'status-progress';
        case 'resolved': return 'status-resolved';
        default: return 'status-pending';
    }
}

function getPriorityClass(priority) {
    switch (priority) {
        case 'urgent': return 'priority-urgent';
        case 'high': return 'priority-high';
        case 'medium': return 'priority-medium';
        case 'low': return 'priority-low';
        default: return 'priority-medium';
    }
}

function getCategoryIcon(category) {
    const icons = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    return icons[category] || icons.other;
}

function getCategoryLabel(category) {
    const labels = {
        'pothole': 'Pothole',
        'streetlight': 'Streetlight',
        'garbage': 'Garbage',
        'water': 'Water Issue',
        'construction': 'Construction',
        'other': 'Other'
    };
    return labels[category] || 'Other';
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
        return 'Just now';
    }
}

// Setup filter event listeners
function setupReportFilters() {
    // Category filter
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', (e) => {
            currentFilters.category = e.target.value;
            displayReports();
        });
    }
    
    // Status filter
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
            currentFilters.status = e.target.value;
            displayReports();
        });
    }
    
    // Priority filter
    const priorityFilter = document.getElementById('priorityFilter');
    if (priorityFilter) {
        priorityFilter.addEventListener('change', (e) => {
            currentFilters.priority = e.target.value;
            displayReports();
        });
    }
    
    // Sort filter
    const sortFilter = document.getElementById('sortFilter');
    if (sortFilter) {
        sortFilter.addEventListener('change', (e) => {
            currentFilters.sortBy = e.target.value;
            displayReports();
        });
    }
    
    // Search functionality
    const searchInput = document.getElementById('searchReports');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
    }
}

// Handle search
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase().trim();
    
    if (searchTerm === '') {
        displayReports();
        return;
    }
    
    const filteredReports = communityReports.filter(report => 
        report.title.toLowerCase().includes(searchTerm) ||
        report.description.toLowerCase().includes(searchTerm) ||
        report.location.toLowerCase().includes(searchTerm)
    );
    
    displayFilteredReports(filteredReports);
}

// Display filtered reports (for search)
function displayFilteredReports(reports) {
    const reportsGrid = document.getElementById('reportsGrid');
    if (!reportsGrid) return;
    
    if (reports.length === 0) {
        reportsGrid.innerHTML = `
            <div class="no-reports">
                <i class="fas fa-search"></i>
                <h3>No Results Found</h3>
                <p>Try adjusting your search terms.</p>
            </div>
        `;
        return;
    }
    
    reportsGrid.innerHTML = '';
    
    reports.forEach(report => {
        const reportCard = createReportCard(report);
        reportsGrid.appendChild(reportCard);
    });
    
    updateResultsCount(reports.length);
}

// Update results count
function updateResultsCount(count) {
    const resultsCount = document.getElementById('resultsCount');
    if (resultsCount) {
        resultsCount.textContent = `${count} report${count !== 1 ? 's' : ''} found`;
    }
}

// Setup other event listeners
function setupReportEventListeners() {
    // New report button
    const newReportBtn = document.getElementById('newReportBtn');
    if (newReportBtn) {
        newReportBtn.addEventListener('click', openNewReportModal);
    }
    
    // Close modal buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal') || e.target.classList.contains('close-modal')) {
            closeAllModals();
        }
    });
}

// Voting functionality
async function voteOnReport(reportId, voteType) {
    try {
        const response = await api.voteOnReport(reportId, voteType);
        
        if (response.success) {
            // Update local data
            const report = communityReports.find(r => r.id === reportId);
            if (report) {
                if (voteType === 'upvote') {
                    report.votes.upvotes.push('current-user');
                } else {
                    report.votes.downvotes.push('current-user');
                }
                displayReports();
            }
            
            showNotification(`Vote ${voteType === 'upvote' ? 'added' : 'removed'} successfully!`, 'success');
        }
        
    } catch (error) {
        console.error('Vote error:', error);
        showNotification('Please login to vote on reports.', 'info');
    }
}

// Comment functionality
function openCommentModal(reportId) {
    // For now, just show a notification
    showNotification('Comment feature coming soon!', 'info');
}

// Share functionality
function shareReport(reportId) {
    const report = communityReports.find(r => r.id === reportId);
    if (report) {
        const shareText = `Check out this civic issue: ${report.title} - ${window.location.origin}/report.html#${reportId}`;
        
        if (navigator.share) {
            navigator.share({
                title: report.title,
                text: report.description,
                url: `${window.location.origin}/report.html#${reportId}`
            });
        } else {
            navigator.clipboard.writeText(shareText).then(() => {
                showNotification('Report link copied to clipboard!', 'success');
            });
        }
    }
}

// New report modal
function openNewReportModal() {
    showNotification('Please use the main dashboard to submit new reports.', 'info');
}

// Close all modals
function closeAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.style.display = 'none';
    });
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}