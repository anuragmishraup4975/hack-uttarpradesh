# CivicPulse Authentication Setup

This guide explains how to set up authentication for your CivicPulse civic issue reporting system.

## Authentication Options

The system supports two authentication methods:

### Option 1: Web3Auth (Recommended)
- **Email OTP Authentication**: Users sign in with their email and receive a one-time password
- **Embedded Wallet**: Automatically creates a blockchain wallet for each user
- **Professional UI**: Clean, modern authentication modal

### Option 2: Fallback Authentication (Demo Mode)
- **Simple Email Login**: Basic email authentication with demo OTP (123456)
- **Simulated Wallet**: Creates a mock wallet address for testing
- **Works Offline**: No external dependencies required

## Setup Instructions

### For Web3Auth (Production)

1. **Get Web3Auth Client ID**:
   - Visit [Web3Auth Dashboard](https://dashboard.web3auth.io/)
   - Create a new project
   - Copy your Client ID

2. **Update Configuration**:
   - Open `js/auth-config.js`
   - Replace the `clientId` with your actual Web3Auth Client ID:
   ```javascript
   clientId: "YOUR_ACTUAL_CLIENT_ID_HERE"
   ```

3. **Configure Domain**:
   - In Web3Auth Dashboard, add your domain to allowed origins
   - For local development: `http://localhost:5000`
   - For production: `https://yourdomain.com`

### For Demo Mode (Current Setup)

The system is currently configured to work in demo mode with fallback authentication:

1. **Click "Sign In with Email"**
2. **Enter any valid email address**
3. **Enter OTP: 123456** (demo code)
4. **You're logged in!**

## Features

### Email OTP Authentication
- Users enter their email address
- System sends (or simulates) an OTP code
- Users verify with the code to complete login
- Session persists across browser refreshes

### Embedded Wallet Creation
- Each user automatically gets a blockchain wallet
- Wallet address is displayed in the user interface
- Can be used for future blockchain integrations

### Clean UI Integration
- Authentication seamlessly integrates with existing design
- User info displays in the navigation bar
- Login/logout states are properly managed

## File Structure

```
js/
├── auth-config.js          # Authentication configuration
├── web3auth-integration.js # Main authentication logic
└── api.js                  # Existing API functions

index.html                  # Updated with auth UI elements
styles.css                  # Updated with auth styles
script.js                   # Updated to use new auth system
```

## Usage in Your Code

### Check Authentication Status
```javascript
// Check if user is logged in
if (window.civicAuth && window.civicAuth.getIsAuthenticated()) {
    const user = window.civicAuth.getUser();
    console.log('User email:', user.email);
    console.log('Wallet address:', user.wallet.address);
}
```

### Listen for Auth Changes
```javascript
// Listen for authentication state changes
window.addEventListener('authStateChanged', function(event) {
    const { user, isAuthenticated } = event.detail;
    
    if (isAuthenticated) {
        console.log('User logged in:', user.email);
        // Enable authenticated features
    } else {
        console.log('User logged out');
        // Disable authenticated features
    }
});
```

### Manual Login/Logout
```javascript
// Trigger login
await window.civicAuth.loginWithEmail();

// Trigger logout
await window.civicAuth.logout();
```

## Security Notes

1. **Client ID Security**: Keep your Web3Auth Client ID secure but note it's visible in frontend code
2. **Domain Restrictions**: Configure allowed domains in Web3Auth Dashboard
3. **Session Management**: Sessions are stored in localStorage and persist across browser sessions
4. **Wallet Security**: Embedded wallets are managed by Web3Auth's secure infrastructure

## Troubleshooting

### Web3Auth Not Loading
- Check browser console for errors
- Verify Client ID is correct
- Ensure domain is whitelisted in Web3Auth Dashboard
- System will automatically fall back to demo mode

### Demo Mode Issues
- Ensure you enter "123456" as the OTP code
- Check browser console for JavaScript errors
- Clear localStorage if experiencing session issues

### Integration Issues
- Verify all script files are loaded in correct order
- Check that `window.civicAuth` is available
- Ensure authentication functions are called after DOM is loaded

## Next Steps

1. **Get Production Web3Auth Account**: Replace demo Client ID with production credentials
2. **Customize UI**: Modify authentication styles in `styles.css`
3. **Add Features**: Extend authentication with additional user profile fields
4. **Blockchain Integration**: Use embedded wallets for blockchain transactions

## Support

For Web3Auth specific issues, visit their [documentation](https://web3auth.io/docs/).
For CivicPulse integration questions, check the browser console for detailed error messages.