# CivicPulse + Kanpur Sewa Integration Guide

## Overview

This project integrates two applications:
1. **CivicPulse** - Main civic issue reporting platform (Node.js/Express)
2. **Kanpur Sewa Portal** - Advanced governance dashboard (React/Vite)

## Architecture

```
CivicPulse Main App (Port 5000)
├── Dashboard (index.html)
├── Community Reports (report.html)  
├── Authentication (signin.html)
├── Track Reports (Embedded Integration)
└── API Routes (/api/*)

Kanpur Sewa Portal (Port 5173)
├── React Application (Vite Dev Server)
├── Advanced Dashboard
├── Escalation Matrix
└── Neural Map Interface
```

## Quick Start

### Option 1: Integrated Startup (Recommended)
```bash
# Run the integrated startup script
start-integrated-app.bat
```

This will:
- Install dependencies for both applications
- Start the main CivicPulse server on port 5000
- Automatically start the React Vite server on port 5173
- Handle routing and integration between both apps

### Option 2: Manual Startup
```bash
# Terminal 1: Start main server
npm install
node server-simple.js

# Terminal 2: Start React app
cd hackshood-hacthon
npm install
npm run dev
```

## Application URLs

| Application | URL | Description |
|-------------|-----|-------------|
| Main Dashboard | http://localhost:5000 | CivicPulse main interface |
| Community Reports | http://localhost:5000/community | Report management |
| Track Reports (Embedded) | http://localhost:5000/track-reports-embedded.html | Integrated view |
| Track Reports (Direct) | http://localhost:5000/hackshood-hacthon | Direct React app |
| Kanpur Sewa Portal | http://localhost:5173 | Standalone React app |
| API Health | http://localhost:5000/api/health | Server status |

## Integration Features

### 1. Seamless Navigation
- Click "Track Reports" in the navbar to access the Kanpur Sewa Portal
- Embedded iframe integration maintains consistent UI/UX
- Fallback to external window if embedding fails

### 2. Automatic Server Management
- Main server automatically starts and manages the Vite dev server
- Graceful shutdown of both servers
- Health monitoring and status indicators

### 3. Routing System
- `/hackshood-hacthon` routes redirect to the React application
- `/track-reports-embedded.html` provides integrated view
- API endpoints remain separate and functional

### 4. Authentication Sync
- User authentication state is maintained across both applications
- Consistent user interface and session management

## Technical Implementation

### Server Integration (server-simple.js)
```javascript
// Vite process management
let viteProcess = null;

function startViteServer() {
    viteProcess = spawn('npm', ['run', 'dev'], {
        cwd: path.join(__dirname, 'hackshood-hacthon'),
        stdio: 'pipe',
        shell: true
    });
}

// Routing
app.get('/hackshood-hacthon', (req, res) => {
    res.redirect(`http://localhost:${VITE_PORT}`);
});
```

### Embedded Integration (track-reports-embedded.html)
```javascript
// Connection monitoring
async function checkViteServer() {
    const response = await fetch('/api/vite-status');
    const data = await response.json();
    
    if (data.viteRunning) {
        loadReactApp();
    }
}

// Iframe embedding
const appFrame = document.getElementById('appFrame');
appFrame.src = 'http://localhost:5173';
```

## Development Workflow

### 1. Making Changes to CivicPulse
- Edit files in the root directory
- Server automatically restarts on file changes
- Refresh browser to see changes

### 2. Making Changes to Kanpur Sewa Portal
- Edit files in `hackshood-hacthon/src/`
- Vite provides hot module replacement
- Changes appear instantly in the browser

### 3. Adding New Routes
- Add routes to `server-simple.js`
- Update navigation in HTML files
- Test both embedded and direct access

## Troubleshooting

### Common Issues

1. **Vite Server Not Starting**
   ```bash
   # Check if port 5173 is available
   netstat -an | findstr :5173
   
   # Manually start Vite server
   cd hackshood-hacthon
   npm run dev
   ```

2. **Integration Not Loading**
   - Check browser console for CORS errors
   - Verify both servers are running
   - Try accessing http://localhost:5173 directly

3. **Authentication Issues**
   - Clear browser localStorage
   - Check network tab for API calls
   - Verify JWT tokens are valid

### Debug Commands
```bash
# Check server status
curl http://localhost:5000/api/health

# Check Vite status
curl http://localhost:5000/api/vite-status

# View server logs
# Check console output from start-integrated-app.bat
```

## File Structure

```
hackkanpur/
├── hackshood-hacthon/          # React application
│   ├── src/
│   │   ├── App.jsx             # Main React component
│   │   └── main.jsx            # React entry point
│   ├── package.json            # React dependencies
│   └── vite.config.js          # Vite configuration
├── server-simple.js            # Main Express server
├── track-reports-embedded.html # Embedded integration page
├── start-integrated-app.bat    # Startup script
└── INTEGRATION_GUIDE.md        # This file
```

## Production Deployment

For production deployment:

1. **Build React App**
   ```bash
   cd hackshood-hacthon
   npm run build
   ```

2. **Serve Static Files**
   - Configure Express to serve built React files
   - Update routing to serve production build
   - Remove Vite dev server dependency

3. **Environment Configuration**
   - Set production environment variables
   - Configure proper CORS settings
   - Enable security middleware

## API Integration

The integration maintains separate API endpoints:

- **CivicPulse API**: `/api/*` (reports, users, auth)
- **React App**: Standalone with its own state management
- **Future Enhancement**: Shared API endpoints for data synchronization

## Security Considerations

- CORS is configured for local development
- Authentication tokens are shared via localStorage
- Production deployment requires proper security headers
- File upload handling is implemented with validation

## Performance Optimization

- Vite provides fast development builds
- Production builds are optimized and minified
- Static file serving is handled by Express
- API responses are cached where appropriate

## Contributing

1. Make changes to the appropriate application
2. Test both embedded and standalone modes
3. Verify integration points work correctly
4. Update documentation if needed

## Support

For issues with:
- **CivicPulse**: Check main application logs
- **Kanpur Sewa Portal**: Check Vite dev server output
- **Integration**: Check browser console and network tab