@echo off
echo Testing Coordinate Fix for CivicPulse...
echo.

echo 1. Starting server with detailed logging...
start "CivicPulse Server" cmd /k "node server-simple.js"

echo 2. Waiting for server to start...
timeout /t 3 /nobreak > nul

echo 3. Opening simple test page...
start "" "http://localhost:5000/test-simple-report.html"

echo 4. Opening coordinate test page...
start "" "http://localhost:5000/test-coordinates.html"

echo.
echo Test Instructions:
echo 1. Try the simple test first (without coordinates)
echo 2. Then try with coordinates
echo 3. Check server console for detailed logs
echo 4. Look for any "Invalid coordinates" errors
echo.
echo Server logs will show detailed coordinate processing info.
echo Press any key to continue...
pause > nul