@echo off
echo ========================================
echo Starting CivicPulse Server
echo ========================================
echo.

echo Checking if MongoDB is running...
netstat -an | find "27017" >nul
if %errorlevel% neq 0 (
    echo WARNING: MongoDB might not be running on port 27017
    echo Please start MongoDB before running the server
    echo.
)

echo Starting CivicPulse API server...
echo Server will be available at: http://localhost:5000
echo Health check: http://localhost:5000/api/health
echo.
echo Press Ctrl+C to stop the server
echo.

npm run dev