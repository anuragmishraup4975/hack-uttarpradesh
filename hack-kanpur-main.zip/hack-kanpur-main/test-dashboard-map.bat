@echo off
echo ========================================
echo Testing CivicPulse Dashboard Map
echo ========================================
echo.
echo [1/3] Checking server status...
curl -s http://localhost:5000/api/health > nul
if %errorlevel% neq 0 (
    echo ❌ Server is not running. Please start the server first.
    echo Run: start-with-data.bat
    pause
    exit /b 1
)
echo ✅ Server is running

echo.
echo [2/3] Testing API endpoints...
echo Testing reports endpoint...
curl -s http://localhost:5000/api/reports | findstr "success" > nul
if %errorlevel% neq 0 (
    echo ❌ Reports API is not working
    pause
    exit /b 1
)
echo ✅ Reports API is working

echo.
echo [3/3] Opening test pages...
echo Opening main dashboard: http://localhost:5000
start http://localhost:5000

echo Opening comprehensive test page: http://localhost:5000/test-all-reports-map.html
start http://localhost:5000/test-all-reports-map.html

echo Opening all reports map: http://localhost:5000/all-reports-map.html
start http://localhost:5000/all-reports-map.html

echo.
echo ========================================
echo Test pages opened successfully!
echo ========================================
echo.
echo Instructions:
echo 1. Check the main dashboard map for markers
echo 2. Use the comprehensive test page to debug issues
echo 3. Verify all reports show on the all-reports map
echo.
echo If markers are not showing:
echo - Check the browser console for errors
echo - Use the test page debug information
echo - Verify coordinates in the reports data
echo.
pause