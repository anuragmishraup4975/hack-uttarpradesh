const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
require('dotenv').config();

// Import file storage
const storage = require('./utils/fileStorage');

const app = express();
const PORT = process.env.PORT || 5000;

// Security middleware
app.use(helmet({
    contentSecurityPolicy: false, // Disable for development
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'Too many requests from this IP, please try again later.'
});
app.use(limiter);

// CORS configuration
app.use(cors({
    origin: ['http://localhost:3000', 'http://127.0.0.1:5500', 'http://localhost:5500', 'file://', 'null'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve static files
app.use(express.static('.'));

// Serve React app build files
app.use('/hackshood-hacthon', express.static(path.join(__dirname, 'hackshood-hacthon/dist')));

// Configure multer for file uploads
const upload = multer({
    dest: 'uploads/',
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB
    },
    fileFilter: (req, file, cb) => {
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (allowedTypes.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Invalid file type. Only images are allowed.'), false);
        }
    }
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Authentication middleware
const auth = async (req, res, next) => {
    try {
        const authHeader = req.header('Authorization');
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({
                success: false,
                message: 'Access denied. No valid token provided.'
            });
        }

        const token = authHeader.substring(7);
        const decoded = jwt.verify(token, JWT_SECRET);
        
        const user = await storage.findUserById(decoded.userId);
        if (!user || user.isActive === false) {
            return res.status(401).json({
                success: false,
                message: 'Access denied. User not found or inactive.'
            });
        }

        req.user = {
            userId: decoded.userId,
            email: decoded.email,
            role: user.role || 'user'
        };

        next();
    } catch (error) {
        console.error('Auth middleware error:', error);
        
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                success: false,
                message: 'Access denied. Invalid token.'
            });
        }
        
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Access denied. Token expired.'
            });
        }

        res.status(500).json({
            success: false,
            message: 'Authentication failed.'
        });
    }
};

// Routes

// Health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        message: 'CivicPulse API is running',
        timestamp: new Date().toISOString(),
        database: 'File Storage Connected'
    });
});

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
    try {
        const { name, email, phone, password, confirmPassword } = req.body;

        // Validation
        if (!name || !email || !phone || !password || !confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'All fields are required'
            });
        }

        if (password !== confirmPassword) {
            return res.status(400).json({
                success: false,
                message: 'Passwords do not match'
            });
        }

        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters long'
            });
        }

        // Check if user already exists
        const existingUser = await storage.findUserByEmail(email);
        if (existingUser) {
            return res.status(400).json({
                success: false,
                message: 'User with this email already exists'
            });
        }

        // Hash password
        const salt = await bcrypt.genSalt(12);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create new user
        const newUser = await storage.addUser({
            name: name.trim(),
            email: email.toLowerCase().trim(),
            phone: phone.trim(),
            password: hashedPassword,
            role: 'user',
            isActive: true,
            reportsSubmitted: 0
        });

        // Remove password from response
        const { password: _, ...userResponse } = newUser;

        // Generate JWT token
        const token = jwt.sign(
            { userId: newUser.id, email: newUser.email },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.status(201).json({
            success: true,
            message: 'User registered successfully',
            data: {
                user: userResponse,
                token
            }
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Registration failed. Please try again.'
        });
    }
});

app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Email and password are required'
            });
        }

        const user = await storage.findUserByEmail(email);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        if (user.isActive === false) {
            return res.status(401).json({
                success: false,
                message: 'Account is deactivated. Please contact support.'
            });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Update last login
        await storage.updateUser(user.id, { lastLogin: new Date().toISOString() });

        // Remove password from response
        const { password: _, ...userResponse } = user;

        const token = jwt.sign(
            { userId: user.id, email: user.email },
            JWT_SECRET,
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            message: 'Login successful',
            data: {
                user: userResponse,
                token
            }
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed. Please try again.'
        });
    }
});

app.get('/api/auth/profile', auth, async (req, res) => {
    try {
        const user = await storage.findUserById(req.user.userId);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        const { password: _, ...userResponse } = user;

        res.json({
            success: true,
            data: { user: userResponse }
        });

    } catch (error) {
        console.error('Profile fetch error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch profile'
        });
    }
});

// Report Routes
app.get('/api/reports', async (req, res) => {
    try {
        const result = await storage.getReportsWithFilters(req.query);
        
        res.json({
            success: true,
            data: {
                reports: result.reports,
                pagination: {
                    currentPage: result.page,
                    totalPages: result.totalPages,
                    totalReports: result.total,
                    hasNext: result.page < result.totalPages,
                    hasPrev: result.page > 1
                }
            }
        });

    } catch (error) {
        console.error('Get reports error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch reports'
        });
    }
});

app.get('/api/reports/stats', async (req, res) => {
    try {
        const stats = await storage.getReportStats();
        
        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch statistics'
        });
    }
});

app.get('/api/reports/:id', async (req, res) => {
    try {
        const report = await storage.findReportById(req.params.id);

        if (!report) {
            return res.status(404).json({
                success: false,
                message: 'Report not found'
            });
        }

        res.json({
            success: true,
            data: { report }
        });

    } catch (error) {
        console.error('Get report error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch report'
        });
    }
});

app.post('/api/reports', auth, upload.single('image'), async (req, res) => {
    try {
        console.log('=== REPORT SUBMISSION DEBUG ===');
        console.log('Request body:', req.body);
        console.log('Request file:', req.file);
        
        const {
            title,
            description,
            category,
            priority,
            address,
            coordinates
        } = req.body;

        console.log('Extracted coordinates:', coordinates);
        console.log('Coordinates type:', typeof coordinates);

        if (!title || !description || !category || !priority || !address) {
            return res.status(400).json({
                success: false,
                message: 'All required fields must be provided'
            });
        }

        let parsedCoordinates;
        if (coordinates) {
            console.log('Processing coordinates:', coordinates);
            try {
                // Handle both string and object coordinates
                if (typeof coordinates === 'string') {
                    console.log('Coordinates is string, parsing...');
                    parsedCoordinates = JSON.parse(coordinates);
                } else if (Array.isArray(coordinates)) {
                    console.log('Coordinates is array');
                    parsedCoordinates = coordinates;
                } else if (typeof coordinates === 'object' && coordinates.lng && coordinates.lat) {
                    console.log('Coordinates is object with lng/lat');
                    parsedCoordinates = [coordinates.lng, coordinates.lat];
                } else if (typeof coordinates === 'object' && coordinates.lat && coordinates.lng) {
                    console.log('Coordinates is object with lat/lng');
                    parsedCoordinates = [coordinates.lng, coordinates.lat];
                } else {
                    console.log('Coordinates format not recognized, using as-is');
                    parsedCoordinates = coordinates;
                }
                
                console.log('Parsed coordinates:', parsedCoordinates);
                
                if (!Array.isArray(parsedCoordinates) || parsedCoordinates.length !== 2) {
                    console.error('Coordinates validation failed: not array of 2 elements');
                    throw new Error('Coordinates must be an array of 2 numbers [longitude, latitude]');
                }
                
                // Ensure coordinates are numbers and valid
                parsedCoordinates = [
                    parseFloat(parsedCoordinates[0]),
                    parseFloat(parsedCoordinates[1])
                ];
                
                console.log('Final parsed coordinates:', parsedCoordinates);
                
                // Validate coordinate ranges
                if (isNaN(parsedCoordinates[0]) || isNaN(parsedCoordinates[1])) {
                    console.error('Coordinates contain NaN values');
                    throw new Error('Coordinates must be valid numbers');
                }
                
                if (parsedCoordinates[0] < -180 || parsedCoordinates[0] > 180) {
                    console.error('Longitude out of range:', parsedCoordinates[0]);
                    throw new Error('Longitude must be between -180 and 180');
                }
                
                if (parsedCoordinates[1] < -90 || parsedCoordinates[1] > 90) {
                    console.error('Latitude out of range:', parsedCoordinates[1]);
                    throw new Error('Latitude must be between -90 and 90');
                }
                
                console.log('✅ Coordinates validation passed:', parsedCoordinates);
            } catch (error) {
                console.error('Coordinate parsing error:', error);
                console.error('Original coordinates value:', coordinates);
                console.error('Coordinates type:', typeof coordinates);
                
                return res.status(400).json({
                    success: false,
                    message: `Invalid coordinates format: ${error.message}. Received: ${JSON.stringify(coordinates)}`
                });
            }
        } else {
            console.log('No coordinates provided, using default Kanpur coordinates');
            parsedCoordinates = [80.3319, 26.4499]; // Default to Kanpur
        }

        const reportData = {
            title: title.trim(),
            description: description.trim(),
            category: category.toLowerCase(),
            priority: priority.toLowerCase(),
            status: 'pending',
            location: {
                address: address.trim(),
                coordinates: parsedCoordinates || [80.3319, 26.4499] // Default to Kanpur
            },
            reporter: req.user.userId,
            votes: {
                upvotes: [],
                downvotes: []
            },
            comments: [],
            statusHistory: [{
                status: 'pending',
                changedAt: new Date().toISOString(),
                reason: 'Initial submission'
            }],
            isPublic: true
        };

        if (req.file) {
            reportData.images = [{
                filename: req.file.filename,
                originalName: req.file.originalname,
                mimetype: req.file.mimetype,
                size: req.file.size,
                uploadDate: new Date().toISOString()
            }];
        }

        const report = await storage.addReport(reportData);
        
        console.log('Report created successfully:', {
            id: report.id,
            title: report.title,
            coordinates: report.location?.coordinates
        });

        // Update user's report count
        const user = await storage.findUserById(req.user.userId);
        if (user) {
            await storage.updateUser(req.user.userId, {
                reportsSubmitted: (user.reportsSubmitted || 0) + 1
            });
        }

        res.status(201).json({
            success: true,
            message: 'Report submitted successfully',
            data: { report }
        });

    } catch (error) {
        console.error('Create report error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit report'
        });
    }
});

// User Routes
app.get('/api/users/stats', async (req, res) => {
    try {
        const stats = await storage.getUserStats();
        
        res.json({
            success: true,
            data: stats
        });

    } catch (error) {
        console.error('Get user stats error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to fetch user statistics'
        });
    }
});

// Serve frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/community', (req, res) => {
    res.sendFile(path.join(__dirname, 'report.html'));
});

app.get('/track-reports', (req, res) => {
    res.sendFile(path.join(__dirname, 'track-reports.html'));
});

app.get('/track-reports-embedded', (req, res) => {
    res.sendFile(path.join(__dirname, 'track-reports-embedded.html'));
});

app.get('/signin', (req, res) => {
    res.sendFile(path.join(__dirname, 'signin.html'));
});

// Route for hackshood-hacthon React app - serve the built files
app.get('/hackshood-hacthon', (req, res) => {
    res.sendFile(path.join(__dirname, 'hackshood-hacthon/dist/index.html'));
});

// API endpoint to check React app status
app.get('/api/react-status', (req, res) => {
    const fs = require('fs');
    const reactBuildExists = fs.existsSync(path.join(__dirname, 'hackshood-hacthon/dist/index.html'));
    
    res.json({
        success: true,
        reactBuilt: reactBuildExists,
        reactUrl: `/hackshood-hacthon`
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'API endpoint not found'
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Error:', error);
    res.status(error.status || 500).json({
        success: false,
        message: error.message || 'Internal server error'
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 CivicPulse server running on port ${PORT}`);
    console.log(`🌐 API URL: http://localhost:${PORT}/api`);
    console.log(`🏥 Health check: http://localhost:${PORT}/api/health`);
    console.log(`📱 Frontend: http://localhost:${PORT}`);
    console.log(`🎯 Track Reports: http://localhost:${PORT}/hackshood-hacthon`);
    console.log(`💾 Using File Storage (JSON files)`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('\n🛑 Shutting down server...');
    process.exit(0);
});