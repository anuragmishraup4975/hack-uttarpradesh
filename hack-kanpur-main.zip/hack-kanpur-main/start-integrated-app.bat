@echo off
echo ========================================
echo   CivicPulse Integrated Application
echo ========================================
echo.
echo Starting CivicPulse with integrated Kanpur Sewa Portal
echo.

REM Check if Node.js is installed
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Node.js is not installed or not in PATH
    echo Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)

echo Installing main application dependencies...
call npm install

echo.
echo Building React application...
cd hackshood-hacthon
call npm install
call npm run build
cd ..

echo.
echo ========================================
echo   Starting Server
echo ========================================
echo.
echo CivicPulse server will start with:
echo - Main Dashboard: http://localhost:5000
echo - Community Reports: http://localhost:5000/community  
echo - Track Reports: http://localhost:5000/track-reports-embedded.html
echo - Kanpur Sewa Portal: http://localhost:5000/hackshood-hacthon
echo - API Health: http://localhost:5000/api/health
echo.
echo Press Ctrl+C to stop the server
echo.

node server-simple.js