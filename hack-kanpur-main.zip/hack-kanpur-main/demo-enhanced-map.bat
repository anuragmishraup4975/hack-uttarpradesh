@echo off
echo Starting Enhanced Map Demo for CivicPulse...
echo.

echo 1. Starting server...
start "CivicPulse Server" cmd /k "node server-simple.js"

echo 2. Waiting for server to start...
timeout /t 3 /nobreak > nul

echo 3. Opening enhanced map demo...
start "" "http://localhost:5000/enhanced-map-demo.html"

echo 4. Opening main dashboard for comparison...
start "" "http://localhost:5000"

echo.
echo Enhanced Map Features Demo:
echo ✅ Detailed popup information for each report
echo ✅ Color-coded status indicators
echo ✅ Interactive buttons (View Details, Share, Support)
echo ✅ Comprehensive report information display
echo ✅ Priority and category indicators
echo ✅ Vote counts and reporter information
echo ✅ Precise coordinate display
echo.
echo Click on any marker to see the enhanced popup!
echo Press any key to continue...
pause > nul