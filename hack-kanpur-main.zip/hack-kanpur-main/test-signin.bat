@echo off
echo Testing Sign-In Page...
echo.
echo Opening sign-in page in browser...
start signin.html
echo.
echo Test Instructions:
echo 1. Try signing up with a new account
echo 2. Try signing in with existing credentials
echo 3. Test password strength indicator
echo 4. Test form validation
echo 5. Test social login buttons (demo mode)
echo.
echo Demo Credentials for Testing:
echo Email: test@example.com
echo Password: password123
echo.
echo The page should automatically redirect to dashboard after successful authentication.
echo.
pause