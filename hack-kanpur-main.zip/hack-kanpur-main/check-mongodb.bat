@echo off
echo ========================================
echo MongoDB Connection Check
echo ========================================
echo.

echo Checking if MongoDB is running on port 27017...
netstat -an | find "27017" >nul

if %errorlevel% equ 0 (
    echo ✓ MongoDB is running on port 27017
    echo.
    echo You can now start the CivicPulse server:
    echo   npm run dev
) else (
    echo ❌ MongoDB is not running on port 27017
    echo.
    echo To start MongoDB:
    echo   Windows: net start MongoDB
    echo   macOS:   brew services start mongodb-community  
    echo   Linux:   sudo systemctl start mongod
    echo.
    echo Or you can use the app in demo mode by just opening index.html
)

echo.
echo ========================================
pause