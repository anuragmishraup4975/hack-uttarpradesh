# Coordinate Error Fix - CivicPulse

## Issue
Users were getting "Invalid coordinates format" error when submitting reports.

## Root Causes Identified
1. **Inconsistent Coordinate Formats**: Frontend sending different formats than server expects
2. **Missing Validation**: No proper validation of coordinate values before sending
3. **Type Conversion Issues**: String/number conversion problems
4. **Range Validation**: No validation of coordinate ranges (lat/lng bounds)

## Fixes Applied

### 1. Frontend Validation (script.js)
```javascript
// Enhanced coordinate validation before submission
if (formData.coordinates) {
    let lng, lat;
    
    // Handle different input formats
    if (Array.isArray(formData.coordinates)) {
        lng = parseFloat(formData.coordinates[0]);
        lat = parseFloat(formData.coordinates[1]);
    } else if (typeof formData.coordinates === 'object') {
        lng = parseFloat(formData.coordinates.lng);
        lat = parseFloat(formData.coordinates.lat);
    }
    
    // Validate ranges and convert to numbers
    if (isNaN(lng) || isNaN(lat) || 
        lng < -180 || lng > 180 || 
        lat < -90 || lat > 90) {
        // Use default Kanpur coordinates
        lng = 80.3319;
        lat = 26.4499;
    }
    
    formData.coordinates = [lng, lat];
}
```

### 2. API Layer Validation (js/api.js)
```javascript
// Validate and format coordinates before sending
if (reportData.coordinates) {
    let coordinates = reportData.coordinates;
    
    // Ensure proper format [lng, lat]
    if (typeof coordinates === 'object' && !Array.isArray(coordinates)) {
        coordinates = [parseFloat(coordinates.lng), parseFloat(coordinates.lat)];
    } else if (Array.isArray(coordinates)) {
        coordinates = [parseFloat(coordinates[0]), parseFloat(coordinates[1])];
    }
    
    // Validate values
    const [lng, lat] = coordinates;
    if (isNaN(lng) || isNaN(lat) || 
        lng < -180 || lng > 180 || 
        lat < -90 || lat > 90) {
        coordinates = null; // Will use server default
    }
    
    reportData.coordinates = coordinates;
}
```

### 3. Server-Side Validation (server-simple.js)
```javascript
// Enhanced server coordinate validation
if (coordinates) {
    try {
        // Handle multiple input formats
        if (typeof coordinates === 'string') {
            parsedCoordinates = JSON.parse(coordinates);
        } else if (Array.isArray(coordinates)) {
            parsedCoordinates = coordinates;
        } else if (typeof coordinates === 'object' && coordinates.lng && coordinates.lat) {
            parsedCoordinates = [coordinates.lng, coordinates.lat];
        }
        
        // Validate array format
        if (!Array.isArray(parsedCoordinates) || parsedCoordinates.length !== 2) {
            throw new Error('Coordinates must be an array of 2 numbers');
        }
        
        // Convert to numbers and validate ranges
        parsedCoordinates = [
            parseFloat(parsedCoordinates[0]),
            parseFloat(parsedCoordinates[1])
        ];
        
        if (isNaN(parsedCoordinates[0]) || isNaN(parsedCoordinates[1])) {
            throw new Error('Coordinates must be valid numbers');
        }
        
        if (parsedCoordinates[0] < -180 || parsedCoordinates[0] > 180) {
            throw new Error('Longitude must be between -180 and 180');
        }
        
        if (parsedCoordinates[1] < -90 || parsedCoordinates[1] > 90) {
            throw new Error('Latitude must be between -90 and 90');
        }
        
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: `Invalid coordinates: ${error.message}`
        });
    }
}
```

### 4. Geocoding Validation
```javascript
// Enhanced geocoding with validation
async function geocodeAddress(address) {
    // ... geocoding logic ...
    
    const lat = parseFloat(result.lat);
    const lng = parseFloat(result.lon);
    
    // Validate geocoded results
    if (isNaN(lat) || isNaN(lng)) {
        console.error('Geocoding returned invalid coordinates');
        return null;
    }
    
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        console.error('Geocoding returned out-of-range coordinates');
        return null;
    }
    
    return { lat, lng };
}
```

## Testing Tools Created

### 1. Coordinate Validation Test Page
- **File**: `test-coordinates.html`
- **URL**: `http://localhost:5000/test-coordinates.html`
- **Features**:
  - Test valid coordinate formats
  - Test invalid coordinate rejection
  - Test geocoding results
  - Real-time validation feedback

### 2. Browser Console Testing
```javascript
// Test coordinate validation
testCoordinateValidation([80.3319, 26.4499]);
testCoordinateValidation({lng: 80.3319, lat: 26.4499});
testCoordinateValidation([200, 100]); // Should fail

// Debug current data
debugMapData();
```

## Coordinate Format Standards

### Input Formats Accepted
1. **Array**: `[longitude, latitude]` - e.g., `[80.3319, 26.4499]`
2. **Object**: `{lng: number, lat: number}` - e.g., `{lng: 80.3319, lat: 26.4499}`
3. **GPS Object**: `{lat: number, lng: number}` - from geolocation API

### Storage Format
- **Database**: `[longitude, latitude]` (GeoJSON standard)
- **Range**: Longitude: -180 to 180, Latitude: -90 to 90

### Validation Rules
1. Must be valid numbers (not NaN)
2. Must be within valid coordinate ranges
3. Must be an array of exactly 2 elements for storage
4. Fallback to Kanpur center (80.3319, 26.4499) if invalid

## Error Messages Improved
- **Before**: "Invalid coordinates format"
- **After**: Specific messages like:
  - "Coordinates must be valid numbers"
  - "Longitude must be between -180 and 180"
  - "Latitude must be between -90 and 90"

## How to Test the Fix

### Method 1: Use Test Page
1. Run server: `node server-simple.js`
2. Open: `http://localhost:5000/test-coordinates.html`
3. Click test buttons to verify validation

### Method 2: Manual Testing
1. Open dashboard: `http://localhost:5000`
2. Try submitting reports with:
   - GPS location
   - Manual addresses
   - Invalid addresses
3. Check that no "invalid coordinates" errors occur

### Method 3: Browser Console
```javascript
// Test different coordinate formats
testCoordinateValidation([80.3319, 26.4499]); // Valid
testCoordinateValidation([200, 100]); // Invalid range
testCoordinateValidation(['abc', 'def']); // Invalid type
```

## Expected Results After Fix
- ✅ No more "invalid coordinates" errors
- ✅ Graceful fallback to default coordinates
- ✅ Clear error messages for debugging
- ✅ Support for multiple coordinate input formats
- ✅ Proper validation at all layers (frontend, API, server)

## Files Modified
- `script.js` - Frontend coordinate validation
- `js/api.js` - API layer validation
- `server-simple.js` - Server-side validation
- `test-coordinates.html` - Testing tool (new)