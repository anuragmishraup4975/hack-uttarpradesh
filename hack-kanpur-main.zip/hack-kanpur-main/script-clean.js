// Global variables
let map;
let reportMarkers = [];
let isUserLoggedIn = false;
let currentUser = null;
let allReports = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('=== DASHBOARD INITIALIZATION START ===');
    
    // Check if user is logged in
    checkAuthStatus();
    
    // Load reports from MongoDB
    loadReportsFromAPI();
    
    initializeMap();
    setupEventListeners();
    
    console.log('=== DASHBOARD INITIALIZATION COMPLETE ===');
});

// Check authentication status
async function checkAuthStatus() {
    const token = localStorage.getItem('civicPulseToken');
    if (token) {
        try {
            const response = await api.getProfile();
            if (response.success) {
                isUserLoggedIn = true;
                currentUser = response.data.user;
                console.log('User logged in:', currentUser.name);
            }
        } catch (error) {
            console.error('Auth check failed:', error);
            // Clear invalid token
            localStorage.removeItem('civicPulseToken');
            api.setToken(null);
        }
    }
}

// Load reports from API with fallback
async function loadReportsFromAPI() {
    try {
        console.log('Loading reports from MongoDB...');
        
        // Get reports and statistics
        const [reportsResponse, statsResponse] = await Promise.all([
            api.getReports({ limit: 50, sortBy: 'createdAt', sortOrder: 'desc' }),
            api.getReportStats()
        ]);

        if (reportsResponse.success) {
            allReports = reportsResponse.data.reports;
            console.log('Loaded reports from API:', allReports.length);
            
            // Update UI
            populateRecentActivity();
            addReportMarkers();
        }

        if (statsResponse.success) {
            updateStatisticsFromAPI(statsResponse.data.overview);
        }

    } catch (error) {
        console.error('Failed to load reports from API:', error);
        
        // Show error message
        showNotification('API server not available. Using offline mode.', 'info');
        
        // Fallback to dummy data for demonstration
        loadFallbackData();
    }
}

// Fallback data when API is not available
function loadFallbackData() {
    console.log('Loading fallback dummy data...');
    
    allReports = [
        {
            _id: '1001',
            title: 'Large pothole on Mall Road',
            description: 'Large pothole on Mall Road causing serious traffic issues and vehicle damage',
            category: 'pothole',
            priority: 'high',
            status: 'pending',
            location: {
                address: 'Mall Road, Civil Lines, Kanpur',
                coordinates: [80.3319, 26.4499] // [longitude, latitude] for MongoDB
            },
            reporter: { name: 'Rajesh Kumar' },
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 5,
            downvoteCount: 0,
            commentCount: 2
        },
        {
            _id: '1002',
            title: 'Broken streetlight in residential area',
            description: 'Broken streetlight creating safety concerns in residential area during night hours',
            category: 'streetlight',
            priority: 'medium',
            status: 'in-progress',
            location: {
                address: 'Swaroop Nagar Main Road, Kanpur',
                coordinates: [80.3496, 26.4850]
            },
            reporter: { name: 'Priya Sharma' },
            createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 3,
            downvoteCount: 0,
            commentCount: 1
        },
        {
            _id: '1003',
            title: 'Overflowing garbage bins near market',
            description: 'Overflowing garbage bins near market area attracting pests and creating unhygienic conditions',
            category: 'garbage',
            priority: 'high',
            status: 'resolved',
            location: {
                address: 'Phool Bagh Market, Kanpur',
                coordinates: [80.3318, 26.4609]
            },
            reporter: { name: 'Amit Singh' },
            createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 8,
            downvoteCount: 1,
            commentCount: 4
        },
        {
            _id: '1004',
            title: 'Water pipeline leakage',
            description: 'Water leakage from main pipeline causing road flooding and water wastage',
            category: 'water',
            priority: 'urgent',
            status: 'pending',
            location: {
                address: 'Kidwai Nagar, Kanpur',
                coordinates: [80.3311, 26.4729]
            },
            reporter: { name: 'Sunita Devi' },
            createdAt: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 12,
            downvoteCount: 0,
            commentCount: 6
        },
        {
            _id: '1005',
            title: 'Multiple potholes on GT Road',
            description: 'Multiple potholes on GT Road affecting heavy vehicle movement',
            category: 'pothole',
            priority: 'high',
            status: 'in-progress',
            location: {
                address: 'GT Road, Panki, Kanpur',
                coordinates: [80.2329, 26.4073]
            },
            reporter: { name: 'Vikash Gupta' },
            createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
            upvoteCount: 7,
            downvoteCount: 1,
            commentCount: 3
        }
    ];
    
    // Update UI with fallback data
    populateRecentActivity();
    updateStatistics();
    addReportMarkers();
    
    console.log('Fallback data loaded:', allReports.length, 'reports');
}

// Initialize the map
function initializeMap() {
    // Check if Leaflet library is available and if we're on the dashboard page
    if (typeof L === 'undefined') {
        console.log('Leaflet library not available, skipping map initialization');
        return;
    }
    
    const mapElement = document.getElementById('map');
    if (!mapElement) {
        console.log('Map element not found, skipping map initialization');
        return;
    }
    
    // Initialize map centered on Kanpur, Uttar Pradesh, India
    map = L.map('map').setView([26.4499, 80.3319], 12);
    
    // Add dark tile layer for dark mode
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '© OpenStreetMap contributors, © CARTO',
        subdomains: 'abcd',
        maxZoom: 19
    }).addTo(map);
    
    // Add sample markers
    addReportMarkers();
}

// Add markers for reports on the map
function addReportMarkers() {
    if (!map || !allReports || allReports.length === 0) {
        console.log('No reports to add to map');
        return;
    }
    
    allReports.forEach(report => {
        // Handle both API format and legacy format
        const coordinates = report.location?.coordinates || report.coordinates;
        const reportType = report.category || report.type;
        const reportStatus = report.status;
        
        if (coordinates && coordinates.length === 2) {
            const markerColor = getMarkerColor(reportStatus);
            const icon = getReportIcon(reportType, markerColor);
            
            const marker = L.marker(coordinates, { icon: icon })
                .addTo(map)
                .bindPopup(`
                    <div class="popup-content">
                        <h4>${getReportTypeLabel(reportType)}</h4>
                        <p><strong>Status:</strong> ${reportStatus.charAt(0).toUpperCase() + reportStatus.slice(1)}</p>
                        <p><strong>Location:</strong> ${report.location?.address || report.location}</p>
                        <p><strong>Description:</strong> ${report.description}</p>
                        <p><strong>Reported:</strong> ${formatTimeAgo(new Date(report.createdAt || report.timestamp))}</p>
                    </div>
                `);
            
            reportMarkers.push(marker);
        }
    });
}

// Get marker color based on status
function getMarkerColor(status) {
    switch(status) {
        case 'pending': return '#e74c3c';
        case 'in-progress': return '#f39c12';
        case 'resolved': return '#27ae60';
        default: return '#95a5a6';
    }
}

// Create custom icon for reports
function getReportIcon(type, color) {
    const iconMap = {
        'pothole': 'fa-road',
        'streetlight': 'fa-lightbulb',
        'garbage': 'fa-trash',
        'water': 'fa-tint',
        'construction': 'fa-hard-hat',
        'other': 'fa-exclamation-triangle'
    };
    
    return L.divIcon({
        html: `<i class="fas ${iconMap[type] || iconMap.other}" style="color: white;"></i>`,
        iconSize: [30, 30],
        className: 'custom-marker',
        iconAnchor: [15, 15],
        popupAnchor: [0, -15],
        style: `background-color: ${color}; border-radius: 50%; display: flex; align-items: center; justify-content: center;`
    });
}

// Get human-readable report type label
function getReportTypeLabel(type) {
    const labels = {
        'pothole': 'Pothole',
        'streetlight': 'Broken Streetlight',
        'garbage': 'Garbage Overflow',
        'water': 'Water Leakage',
        'construction': 'Construction Issue',
        'other': 'Other Issue'
    };
    return labels[type] || 'Unknown Issue';
}

// Populate recent activity section
function populateRecentActivity() {
    const activityList = document.getElementById('activityList');
    
    // Check if element exists (only on dashboard page)
    if (!activityList) {
        return;
    }
    
    if (allReports.length === 0) {
        // Show empty state
        activityList.className = 'activity-list empty';
        activityList.innerHTML = `
            <i class="fas fa-clipboard-list"></i>
            <h4>No Recent Activity</h4>
            <p>Community reports will appear here once submitted</p>
        `;
        return;
    }
    
    activityList.className = 'activity-list';
    const sortedReports = [...allReports].sort((a, b) => new Date(b.createdAt || b.timestamp) - new Date(a.createdAt || a.timestamp));
    
    activityList.innerHTML = '';
    
    // Show only the 5 most recent reports
    sortedReports.slice(0, 5).forEach(report => {
        const activityItem = createActivityItem(report);
        activityList.appendChild(activityItem);
    });
}

// Create activity item element
function createActivityItem(report) {
    const item = document.createElement('div');
    item.className = 'activity-item';
    
    const reportType = report.category || report.type;
    const reportStatus = report.status;
    const reportLocation = report.location?.address || report.location;
    const reportTimestamp = new Date(report.createdAt || report.timestamp);
    
    const iconClass = getActivityIconClass(reportStatus);
    const statusText = getStatusText(reportStatus);
    
    item.innerHTML = `
        <div class="activity-icon ${iconClass}">
            <i class="fas ${getActivityIcon(reportStatus)}"></i>
        </div>
        <div class="activity-content">
            <div class="activity-title">${getReportTypeLabel(reportType)} - ${statusText}</div>
            <div class="activity-description">${reportLocation}</div>
            <div class="activity-time">${formatTimeAgo(reportTimestamp)}</div>
        </div>
    `;
    
    return item;
}

// Get activity icon class based on status
function getActivityIconClass(status) {
    switch(status) {
        case 'pending': return 'new';
        case 'in-progress': return 'progress';
        case 'resolved': return 'resolved';
        default: return 'new';
    }
}

// Get activity icon based on status
function getActivityIcon(status) {
    switch(status) {
        case 'pending': return 'fa-plus';
        case 'in-progress': return 'fa-clock';
        case 'resolved': return 'fa-check';
        default: return 'fa-info';
    }
}

// Get status text
function getStatusText(status) {
    switch(status) {
        case 'pending': return 'Reported';
        case 'in-progress': return 'In Progress';
        case 'resolved': return 'Resolved';
        default: return 'Unknown';
    }
}

// Update statistics from API response
function updateStatisticsFromAPI(stats) {
    const totalElement = document.getElementById('totalReports');
    const inProcessElement = document.getElementById('inProcessReports');
    const resolvedElement = document.getElementById('resolvedReports');
    
    if (totalElement) totalElement.textContent = stats.total.toLocaleString();
    if (inProcessElement) inProcessElement.textContent = stats.inProgress.toLocaleString();
    if (resolvedElement) resolvedElement.textContent = stats.resolved.toLocaleString();
    
    // Animate numbers only if elements exist
    if (totalElement && inProcessElement && resolvedElement) {
        animateNumbers();
    }
}

// Update statistics (fallback for when API is not available)
function updateStatistics() {
    const stats = calculateStatistics();
    
    const totalElement = document.getElementById('totalReports');
    const inProcessElement = document.getElementById('inProcessReports');
    const resolvedElement = document.getElementById('resolvedReports');
    
    // Check if elements exist (only on dashboard page)
    if (totalElement) totalElement.textContent = stats.total.toLocaleString();
    if (inProcessElement) inProcessElement.textContent = stats.inProcess.toLocaleString();
    if (resolvedElement) resolvedElement.textContent = stats.resolved.toLocaleString();
    
    // Animate numbers only if elements exist
    if (totalElement && inProcessElement && resolvedElement) {
        animateNumbers();
    }
}

// Calculate statistics from current data
function calculateStatistics() {
    const total = allReports.length;
    const inProcess = allReports.filter(r => r.status === 'in-progress').length;
    const resolved = allReports.filter(r => r.status === 'resolved').length;
    
    return { total, inProcess, resolved };
}

// Animate number counters
function animateNumbers() {
    const counters = document.querySelectorAll('.stat-number');
    
    counters.forEach(counter => {
        const target = parseInt(counter.textContent.replace(/,/g, ''));
        const increment = target / 50;
        let current = 0;
        
        const timer = setInterval(() => {
            current += increment;
            if (current >= target) {
                counter.textContent = target.toLocaleString();
                clearInterval(timer);
            } else {
                counter.textContent = Math.floor(current).toLocaleString();
            }
        }, 30);
    });
}

// Format time ago
function formatTimeAgo(timestamp) {
    const now = new Date();
    const diff = now - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (days > 0) {
        return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
        return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else if (minutes > 0) {
        return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else {
        return 'Just now';
    }
}

// Setup event listeners
function setupEventListeners() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }
    
    // Report form submission (only on dashboard page)
    const reportForm = document.querySelector('.report-form');
    if (reportForm) {
        reportForm.addEventListener('submit', handleReportSubmission);
    }
    
    // Login form submission (only on dashboard page)
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form submission (only on dashboard page)
    const registerForm = document.querySelector('.register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    // Close modal when clicking outside (only on dashboard page)
    window.addEventListener('click', (event) => {
        const reportModal = document.getElementById('reportModal');
        const authModal = document.getElementById('authModal');
        
        if (reportModal && event.target === reportModal) {
            closeReportModal();
        }
        if (authModal && event.target === authModal) {
            closeAuthModal();
        }
    });
    
    // File upload handling for dashboard report modal
    const fileInput = document.getElementById('reportImage');
    if (fileInput) {
        fileInput.addEventListener('change', handleFileUpload);
    }
}

// Modal functions
function openReportModal() {
    // Check if user is logged in
    if (!isUserLoggedIn) {
        openAuthModal();
        return;
    }
    
    const reportModal = document.getElementById('reportModal');
    if (reportModal) {
        reportModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }
}

function closeReportModal() {
    const reportModal = document.getElementById('reportModal');
    if (reportModal) {
        reportModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Reset form
        const reportForm = document.querySelector('.report-form');
        if (reportForm) {
            reportForm.reset();
        }
        
        // Reset file upload area
        const uploadArea = document.querySelector('.file-upload-area');
        if (uploadArea) {
            uploadArea.innerHTML = `
                <i class="fas fa-cloud-upload-alt"></i>
                <span>Click to upload or drag and drop</span>
                <small>PNG, JPG up to 5MB</small>
            `;
        }
        
        // Clear location data and status
        if (typeof currentLocationCoords !== 'undefined') {
            currentLocationCoords = null;
        }
        
        const locationStatus = document.getElementById('locationStatus');
        if (locationStatus) {
            locationStatus.classList.remove('show');
        }
        
        // Remove current location marker from map if it exists
        if (window.currentLocationMarker && map) {
            map.removeLayer(window.currentLocationMarker);
            window.currentLocationMarker = null;
        }
    }
}

// Authentication Modal functions
function openAuthModal() {
    const authModal = document.getElementById('authModal');
    if (authModal) {
        authModal.style.display = 'block';
        document.body.style.overflow = 'hidden';
        
        // Show login form by default
        switchToLogin();
    }
}

function closeAuthModal() {
    const authModal = document.getElementById('authModal');
    if (authModal) {
        authModal.style.display = 'none';
        document.body.style.overflow = 'auto';
        
        // Reset forms
        const loginForm = document.querySelector('.login-form');
        const registerForm = document.querySelector('.register-form');
        
        if (loginForm) loginForm.reset();
        if (registerForm) registerForm.reset();
    }
}

function switchToLogin() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authTitle = document.getElementById('authTitle');
    
    if (loginForm && registerForm && authTitle) {
        loginForm.classList.add('active');
        registerForm.classList.remove('active');
        authTitle.textContent = 'Login to Report Issues';
    }
}

function switchToRegister() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const authTitle = document.getElementById('authTitle');
    
    if (loginForm && registerForm && authTitle) {
        registerForm.classList.add('active');
        loginForm.classList.remove('active');
        authTitle.textContent = 'Create Your Account';
    }
}

// Enhanced registration with API and fallback
async function handleRegister(event) {
    event.preventDefault();
    
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim().toLowerCase();
    const phone = document.getElementById('registerPhone').value.trim();
    const password = document.getElementById('registerPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    // Validate all fields
    if (!name || name.length < 2) {
        showNotification('Please enter a valid name (at least 2 characters).', 'error');
        return;
    }
    
    if (!validateEmail(email)) {
        showNotification('Please enter a valid email address.', 'error');
        return;
    }
    
    if (!validatePhone(phone)) {
        showNotification('Please enter a valid phone number.', 'error');
        return;
    }
    
    if (password.length < 6) {
        showNotification('Password must be at least 6 characters long.', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showNotification('Passwords do not match!', 'error');
        return;
    }
    
    if (!agreeTerms) {
        showNotification('Please agree to the Terms & Conditions', 'error');
        return;
    }
    
    try {
        // Try API registration first
        const response = await api.register({
            name,
            email,
            phone,
            password,
            confirmPassword
        });
        
        if (response.success) {
            // Reset register form
            document.querySelector('.register-form').reset();
            
            // Show success message and switch to login
            showNotification(`Account created successfully, ${name}! Please login with your credentials.`, 'success');
            
            // Switch to login form after successful registration
            setTimeout(() => {
                switchToLogin();
                // Pre-fill email in login form
                document.getElementById('loginEmail').value = email;
                document.getElementById('loginEmail').focus();
            }, 2000);
        }
        
    } catch (error) {
        console.error('Registration error:', error);
        
        // Fallback to offline mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Using offline demo mode.', 'info');
            
            // Simulate successful registration in offline mode
            isUserLoggedIn = true;
            currentUser = { name, email, _id: 'offline-user' };
            
            document.querySelector('.register-form').reset();
            closeAuthModal();
            showNotification(`Welcome ${name}! You're now in demo mode.`, 'success');
        } else {
            showNotification(error.message || 'Registration failed. Please try again.', 'error');
        }
    }
}

// Enhanced login with API and fallback
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    
    if (!validateEmail(email)) {
        showNotification('Please enter a valid email address.', 'error');
        return;
    }
    
    if (!password) {
        showNotification('Please enter your password.', 'error');
        return;
    }
    
    try {
        // Try API login first
        const response = await api.login({ email, password });
        
        if (response.success) {
            isUserLoggedIn = true;
            currentUser = response.data.user;
            
            closeAuthModal();
            showNotification(`Welcome back, ${currentUser.name}! You can now report issues.`, 'success');
            
            setTimeout(() => {
                openReportModal();
            }, 1500);
        }
        
    } catch (error) {
        console.error('Login error:', error);
        
        // Fallback to offline demo mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Using offline demo mode.', 'info');
            
            // Simulate successful login in offline mode
            isUserLoggedIn = true;
            currentUser = { name: 'Demo User', email, _id: 'offline-user' };
            
            closeAuthModal();
            showNotification(`Welcome Demo User! You're now in demo mode.`, 'success');
            
            setTimeout(() => {
                openReportModal();
            }, 1500);
        } else {
            showNotification(error.message || 'Login failed. Please try again.', 'error');
        }
    }
}

// Enhanced report submission with MongoDB API and offline fallback
async function handleReportSubmission(event) {
    event.preventDefault();
    
    // Check if user is logged in
    if (!isUserLoggedIn) {
        showNotification('Please login first to submit a report.', 'error');
        return;
    }
    
    const formData = {
        title: document.getElementById('reportTitle').value,
        category: document.getElementById('issueType').value,
        priority: document.getElementById('reportPriority').value,
        description: document.getElementById('description').value,
        address: document.getElementById('location').value,
        coordinates: currentLocationCoords, // Include GPS coordinates if available
        image: document.getElementById('reportImage').files[0] || null
    };
    
    // Validate required fields
    if (!formData.title || !formData.category || !formData.priority || !formData.description || !formData.address) {
        showNotification('Please fill in all required fields.', 'error');
        return;
    }
    
    try {
        // Try API submission first
        const response = await api.createReport(formData);
        
        if (response.success) {
            // Add to local array for immediate UI update
            allReports.unshift(response.data.report);
            
            // Update UI
            populateRecentActivity();
            updateStatistics();
            
            // Show success message
            showNotification('Thank you! Your report has been submitted successfully.', 'success');
            
            // Close modal and reset form
            closeReportModal();
        }
        
    } catch (error) {
        console.error('Report submission error:', error);
        
        // Fallback to offline mode
        if (error.message.includes('Failed to fetch')) {
            showNotification('Server not available. Report saved locally for demo.', 'info');
            
            // Create offline report
            const offlineReport = {
                _id: 'offline-' + Date.now(),
                title: formData.title,
                description: formData.description,
                category: formData.category,
                priority: formData.priority,
                status: 'pending',
                location: {
                    address: formData.address,
                    coordinates: formData.coordinates ? [formData.coordinates.lng, formData.coordinates.lat] : [80.3319, 26.4499]
                },
                reporter: currentUser,
                createdAt: new Date().toISOString(),
                upvoteCount: 0,
                downvoteCount: 0,
                commentCount: 0
            };
            
            // Add to local array
            allReports.unshift(offlineReport);
            
            // Update UI
            populateRecentActivity();
            updateStatistics();
            
            // Close modal
            closeReportModal();
        } else {
            showNotification(error.message || 'Failed to submit report. Please try again.', 'error');
        }
    }
    
    // Reset location data
    if (typeof currentLocationCoords !== 'undefined') {
        currentLocationCoords = null;
    }
    const locationStatus = document.getElementById('locationStatus');
    if (locationStatus) {
        locationStatus.classList.remove('show');
    }
}

// Validation helper functions
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validatePhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// Handle file upload for dashboard report modal
function handleFileUpload(event) {
    const file = event.target.files[0];
    const uploadArea = document.querySelector('.file-upload-area');
    
    if (file) {
        if (file.size > 5 * 1024 * 1024) { // 5MB limit
            showNotification('File size must be less than 5MB.', 'error');
            event.target.value = '';
            return;
        }
        
        if (!file.type.startsWith('image/')) {
            showNotification('Please select an image file.', 'error');
            event.target.value = '';
            return;
        }
        
        uploadArea.innerHTML = `
            <i class="fas fa-check-circle" style="color: #00ff9d;"></i>
            <span style="color: #00ff9d;">Image uploaded: ${file.name}</span>
            <small>Click to change image</small>
        `;
    }
}

// Location functionality
let currentLocationCoords = null;

// Get current location using GPS
function getCurrentLocation() {
    const locationBtn = document.querySelector('.btn-location');
    const locationStatus = document.getElementById('locationStatus');
    const locationInput = document.getElementById('location');
    
    // Check if geolocation is supported
    if (!navigator.geolocation) {
        showLocationStatus('Geolocation is not supported by this browser.', 'error');
        return;
    }
    
    // Show loading state
    locationBtn.classList.add('loading');
    locationBtn.disabled = true;
    showLocationStatus('Getting your location...', 'loading');
    
    // Get current position
    navigator.geolocation.getCurrentPosition(
        // Success callback
        function(position) {
            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;
            const accuracy = position.coords.accuracy;
            
            currentLocationCoords = { lat: latitude, lng: longitude };
            
            // Use coordinates directly for demo
            locationInput.value = `${latitude.toFixed(6)}, ${longitude.toFixed(6)}`;
            showLocationStatus(`Location found (±${Math.round(accuracy)}m accuracy)`, 'success');
            
            // Reset button state
            locationBtn.classList.remove('loading');
            locationBtn.disabled = false;
        },
        // Error callback
        function(error) {
            let errorMessage = 'Unable to get your location. ';
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage += 'Location access denied by user.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage += 'Location information unavailable.';
                    break;
                case error.TIMEOUT:
                    errorMessage += 'Location request timed out.';
                    break;
                default:
                    errorMessage += 'An unknown error occurred.';
                    break;
            }
            
            showLocationStatus(errorMessage, 'error');
            
            // Reset button state
            locationBtn.classList.remove('loading');
            locationBtn.disabled = false;
        },
        // Options
        {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
        }
    );
}

// Show location status message
function showLocationStatus(message, type) {
    const locationStatus = document.getElementById('locationStatus');
    if (!locationStatus) return;
    
    const iconMap = {
        loading: 'fa-spinner fa-spin',
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle'
    };
    
    locationStatus.innerHTML = `<i class="fas ${iconMap[type]}"></i> ${message}`;
    locationStatus.className = `location-status show ${type}`;
    
    // Auto-hide success/error messages after 4 seconds
    if (type !== 'loading') {
        setTimeout(() => {
            locationStatus.classList.remove('show');
        }, 4000);
    }
}

// Show notification function
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.classList.add('show');
    }, 100);
    
    // Remove notification after 4 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(notification)) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 4000);
}

// Add custom CSS for markers
const style = document.createElement('style');
style.textContent = `
    .custom-marker {
        background-color: #e74c3c;
        border: 2px solid white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 2px 5px rgba(0,0,0,0.3);
    }
    
    .leaflet-popup-content-wrapper {
        background-color: #2f3349;
        color: #e4e6ea;
        border-radius: 8px;
    }
    
    .leaflet-popup-tip {
        background-color: #2f3349;
    }
    
    .popup-content h4 {
        margin: 0 0 10px 0;
        color: #3498db;
    }
    
    .popup-content p {
        margin: 5px 0;
        font-size: 0.9rem;
        color: #e4e6ea;
    }
    
    .popup-content strong {
        color: #a0a3bd;
    }
`;
document.head.appendChild(style);