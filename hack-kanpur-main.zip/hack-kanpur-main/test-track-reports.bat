@echo off
echo ========================================
echo   Testing Local Project Tracking
echo ========================================
echo.
echo Starting server and opening Track Reports page...
echo.

REM Start the server
start /min cmd /c "node server-simple.js"

REM Wait for server to start
timeout /t 3 /nobreak >nul

REM Open the track reports page
start http://localhost:3000/track-reports.html

echo.
echo Local Project Tracking Features:
echo.
echo 1. Local Project Structure Display
echo 2. File and folder organization
echo 3. Project statistics and features
echo 4. Direct access to project files
echo 5. Local folder navigation
echo.
echo The page now shows the local hackshood-hacthon project
echo instead of connecting to GitHub repository.
echo.
echo Action Buttons:
echo - Open Project Folder: Opens local directory
echo - View Source Files: Navigate to main application
echo - Run Project: Launch the main dashboard
echo - Documentation: Access project README
echo.
pause