@echo off
echo Starting CivicPulse server for map marker testing...
echo.
echo 1. Starting server...
start "CivicPulse Server" cmd /k "node server-simple.js"

echo 2. Waiting for server to start...
timeout /t 3 /nobreak > nul

echo 3. Opening test page...
start "" "http://localhost:5000/test-report-submission.html"

echo 4. Opening main dashboard...
start "" "http://localhost:5000"

echo.
echo Test Instructions:
echo 1. First, test report submission on the test page
echo 2. Then check the main dashboard to see if the marker appears
echo 3. Check browser console for debugging information
echo.
echo Press any key to continue...
pause > nul