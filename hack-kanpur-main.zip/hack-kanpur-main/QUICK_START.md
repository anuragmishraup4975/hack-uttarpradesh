# CivicPulse - Quick Start Guide

Get your civic issue reporting dashboard up and running in minutes!

## 🚀 One-Minute Setup

### Option 1: Windows Batch Files (Recommended)

1. **Install Dependencies**
   ```cmd
   install.bat
   ```

2. **Start with Sample Data**
   ```cmd
   start-with-data.bat
   ```

3. **Open your browser to http://localhost:3000**

That's it! Your dashboard is ready with sample data.

### Option 2: Manual Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Create Sample Data**
   ```bash
   npm run create-data
   ```

3. **Start Backend Server**
   ```bash
   npm run start:server
   ```

4. **Start Frontend Server** (new terminal)
   ```bash
   npm run start:frontend
   ```

5. **Access the Application**
   - Dashboard: http://localhost:3000
   - Community: http://localhost:3000/community
   - API: http://localhost:5000/api

## 🎯 What You Get

### Sample Data Included
- **3 Users**: Rajesh Kumar, Priya Sharma, Admin User
- **5 Reports**: Various civic issues across Kanpur
- **All passwords**: `password123` (for testing)

### Test Accounts
```
Email: rajesh.kumar@email.com
Password: password123

Email: priya.sharma@email.com  
Password: password123

Email: admin@civicpulse.com
Password: admin123
```

## 🔧 Key Features to Test

1. **Dashboard (http://localhost:3000)**
   - View statistics cards
   - Check recent activity feed
   - Explore interactive map
   - Click "Report Issue" to test authentication

2. **Community Page (http://localhost:3000/community)**
   - Browse all reports
   - Use filters (category, status, priority)
   - Search functionality
   - Sort by different criteria

3. **Authentication Flow**
   - Register new account
   - Login with test credentials
   - Submit new reports (requires login)

4. **API Testing (http://localhost:5000/api)**
   - Health check: `/health`
   - Get reports: `/reports`
   - Get statistics: `/reports/stats`

## 📱 Mobile Testing

The dashboard is fully responsive. Test on:
- Desktop browsers
- Mobile devices
- Tablet screens

## 🗂️ File Structure

```
civicpulse/
├── data/
│   ├── users.json          # User accounts
│   ├── reports.json        # Issue reports
│   └── sample-data.js      # Data generator
├── server-simple.js        # Backend API server
├── serve-frontend.js       # Frontend dev server
├── index.html             # Main dashboard
├── report.html            # Community page
└── js/api.js              # API service
```

## 🚨 Troubleshooting

### Port Already in Use
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <process-id> /F

# Then restart servers
```

### CORS Issues
- Make sure both servers are running
- Backend: http://localhost:5000
- Frontend: http://localhost:3000

### No Data Showing
1. Check if sample data was created: `data/users.json` and `data/reports.json` should exist
2. Restart the backend server
3. Check browser console for errors

## 🎨 Customization

### Change Location Focus
Edit coordinates in `script.js`:
```javascript
// Change from Kanpur to your city
map = L.map('map').setView([YOUR_LAT, YOUR_LNG], 12);
```

### Modify Sample Data
Edit `data/sample-data.js` to add your own test data.

### Update Styling
- Main styles: `styles.css`
- Community styles: `report-styles.css`

## 📊 Next Steps

1. **Add Real Data**: Replace sample data with actual civic issues
2. **Customize Location**: Update coordinates for your city
3. **Deploy**: Use the deployment guide in README.md
4. **Integrate**: Connect with municipal systems or databases

## 🔗 Useful Links

- **Main Dashboard**: http://localhost:3000
- **Community Reports**: http://localhost:3000/community  
- **API Health Check**: http://localhost:5000/api/health
- **API Documentation**: See README.md

## 💡 Pro Tips

1. **Use Chrome DevTools** to test responsive design
2. **Check Network tab** to see API calls in action
3. **Test offline mode** by stopping the backend server
4. **Try GPS location** on mobile devices for accurate reporting

---

**Need Help?** Check the full README.md for detailed documentation and troubleshooting.