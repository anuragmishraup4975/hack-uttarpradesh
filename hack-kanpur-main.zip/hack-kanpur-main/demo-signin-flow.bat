@echo off
echo ========================================
echo   CivicPulse Authentication Demo
echo ========================================
echo.
echo This demo shows the complete authentication flow:
echo.
echo 1. Beautiful sign-in page with real-world forms
echo 2. Sign-up with password strength validation
echo 3. Social login options (Google/GitHub)
echo 4. Automatic dashboard redirect
echo 5. Persistent user sessions
echo.
echo Starting demo...
echo.

REM Start the server first
echo Starting server...
start /min cmd /c "node server-simple.js"

REM Wait a moment for server to start
timeout /t 3 /nobreak >nul

REM Open sign-in page
echo Opening sign-in page...
start http://localhost:3000/signin.html

echo.
echo Demo Features to Test:
echo.
echo SIGN UP:
echo - Enter your name, email, and password
echo - Watch password strength indicator
echo - Password must be at least 8 characters
echo - Passwords must match
echo - Agree to terms and conditions
echo.
echo SIGN IN:
echo - Use the account you just created
echo - Or try demo account: test@demo.com / password123
echo - Toggle password visibility
echo - Remember me option
echo.
echo SOCIAL LOGIN:
echo - Click Google or GitHub buttons
echo - Demo mode will create mock accounts
echo.
echo FORGOT PASSWORD:
echo - Click "Forgot password?" link
echo - Enter email to simulate reset
echo.
echo After successful authentication:
echo - Automatic redirect to dashboard
echo - User info displayed in navigation
echo - Persistent session across page reloads
echo.
echo Press any key to open dashboard directly...
pause >nul
start http://localhost:3000/index.html
echo.
echo Demo complete! Check both pages to see the authentication flow.
echo.
pause