@echo off
echo ========================================
echo CivicPulse Installation Script
echo ========================================
echo.

echo [1/5] Checking Node.js installation...
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Node.js is not installed. Please install Node.js from https://nodejs.org/
    pause
    exit /b 1
)
echo ✓ Node.js is installed

echo.
echo [2/5] Checking MongoDB installation...
mongod --version >nul 2>&1
if %errorlevel% neq 0 (
    echo WARNING: MongoDB is not installed or not in PATH
    echo Please install MongoDB from https://www.mongodb.com/try/download/community
    echo Or make sure MongoDB is running on localhost:27017
)
echo ✓ MongoDB check completed

echo.
echo [3/5] Installing Node.js dependencies...
npm install
if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)
echo ✓ Dependencies installed successfully

echo.
echo [4/5] Creating uploads directory...
if not exist "uploads" mkdir uploads
echo ✓ Uploads directory created

echo.
echo [5/5] Setting up environment file...
if not exist ".env" (
    copy ".env" ".env.backup" >nul 2>&1
    echo ✓ Environment file is ready
) else (
    echo ✓ Environment file already exists
)

echo.
echo ========================================
echo Installation completed successfully!
echo ========================================
echo.
echo Next steps:
echo 1. Make sure MongoDB is running
echo 2. Run 'npm run dev' to start the development server
echo 3. Open index.html in your browser
echo.
echo API will be available at: http://localhost:5000/api
echo Health check: http://localhost:5000/api/health
echo.
pause