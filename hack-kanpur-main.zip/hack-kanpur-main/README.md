# CivicPulse - Smart City Issue Reporting Dashboard

A modern, dark-themed civic issue reporting platform focused on Kanpur, Uttar Pradesh, India. Citizens can report local issues like potholes, broken streetlights, garbage overflow, and water leakage with an intuitive interface and real-time tracking.

## 🚀 Features

### Core Functionality
- **Issue Reporting**: Submit detailed reports with photos, location, and priority levels
- **Interactive Map**: View all reported issues on a Leaflet-based map centered on Kanpur
- **Real-time Dashboard**: Live statistics and recent activity feed
- **Community View**: Browse and filter all community reports
- **User Authentication**: Secure registration and login system
- **File-based Storage**: Simple JSON file storage system (no database required)

### Technical Features
- **Dark Mode Design**: Modern glassmorphism UI with neon accents
- **Responsive Layout**: Works on desktop, tablet, and mobile devices
- **API Integration**: RESTful API with comprehensive error handling
- **Offline Fallback**: Graceful degradation when server is unavailable
- **GPS Location**: Automatic location detection for accurate reporting
- **File Upload**: Image attachment support for issue reports

## 🛠️ Technology Stack

### Frontend
- **HTML5/CSS3**: Modern semantic markup and styling
- **JavaScript (ES6+)**: Vanilla JavaScript with async/await
- **Leaflet.js**: Interactive mapping functionality
- **Font Awesome**: Icon library for UI elements

### Backend
- **Node.js**: Server runtime environment
- **Express.js**: Web application framework
- **File Storage**: JSON-based data persistence
- **bcryptjs**: Password hashing and security
- **JWT**: JSON Web Token authentication
- **Multer**: File upload handling
- **CORS**: Cross-origin resource sharing

### Security & Performance
- **Helmet.js**: Security headers and protection
- **Rate Limiting**: API request throttling
- **Input Validation**: Comprehensive data validation
- **Error Handling**: Graceful error management

## 📁 Project Structure

```
civicpulse/
├── data/                     # JSON data storage
│   ├── users.json           # User accounts and profiles
│   ├── reports.json         # Issue reports and details
│   └── sample-data.js       # Sample data generator
├── js/                      # Frontend JavaScript
│   └── api.js              # API service layer
├── middleware/              # Express middleware
│   └── auth.js             # Authentication middleware
├── models/                  # Data models (legacy)
│   ├── User.js             # User model schema
│   └── Report.js           # Report model schema
├── routes/                  # API routes (legacy)
│   ├── auth.js             # Authentication routes
│   ├── users.js            # User management routes
│   └── reports.js          # Report management routes
├── utils/                   # Utility functions
│   └── fileStorage.js      # File-based storage system
├── index.html              # Main dashboard page
├── report.html             # Community reports page
├── styles.css              # Main stylesheet
├── report-styles.css       # Community page styles
├── script.js               # Dashboard JavaScript
├── report-script.js        # Community page JavaScript
├── server-simple.js        # File-based server
├── serve-frontend.js       # Frontend development server
├── package.json            # Node.js dependencies
├── .env                    # Environment variables
└── README.md              # This file
```

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm (Node Package Manager)

### Installation

1. **Clone or download the project**
   ```bash
   cd civicpulse
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Create sample data**
   ```bash
   npm run create-data
   ```

4. **Start the backend server**
   ```bash
   npm run start:server
   ```

5. **Start the frontend server** (in a new terminal)
   ```bash
   npm run start:frontend
   ```

6. **Access the application**
   - Dashboard: http://localhost:3000
   - Community: http://localhost:3000/community
   - API: http://localhost:5000/api

### Alternative Quick Start (Windows)

Use the provided batch files:

1. **Install dependencies**
   ```cmd
   install.bat
   ```

2. **Start with sample data**
   ```cmd
   start-with-data.bat
   ```

3. **Access the application at http://localhost:3000**

## 📊 API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile

### Reports
- `GET /api/reports` - Get all reports (with filtering)
- `GET /api/reports/stats` - Get report statistics
- `GET /api/reports/:id` - Get specific report
- `POST /api/reports` - Create new report (authenticated)

### Users
- `GET /api/users/stats` - Get user statistics

### System
- `GET /api/health` - Health check endpoint

## 🗄️ Data Storage

The application uses a simple file-based storage system with JSON files:

### Users Data (`data/users.json`)
```json
{
  "id": "unique-timestamp-id",
  "name": "User Name",
  "email": "user@example.com",
  "phone": "+91 9876543210",
  "password": "hashed-password",
  "role": "user",
  "isActive": true,
  "reportsSubmitted": 0,
  "createdAt": "2026-01-19T17:42:59.086Z"
}
```

### Reports Data (`data/reports.json`)
```json
{
  "id": "unique-timestamp-id",
  "title": "Issue Title",
  "description": "Detailed description",
  "category": "pothole|streetlight|garbage|water|construction|other",
  "priority": "low|medium|high|urgent",
  "status": "pending|in-progress|resolved|rejected",
  "location": {
    "address": "Full address",
    "coordinates": [longitude, latitude]
  },
  "reporter": "user-id",
  "votes": {
    "upvotes": [],
    "downvotes": []
  },
  "comments": [],
  "statusHistory": [],
  "isPublic": true,
  "createdAt": "2026-01-19T17:42:59.117Z",
  "updatedAt": "2026-01-19T17:42:59.117Z"
}
```

## 🎨 Design System

### Color Palette
- **Primary Background**: `#1a1d29` (Dark navy)
- **Secondary Background**: `#2f3349` (Lighter navy)
- **Accent Colors**:
  - Cyan: `#00ff9d` (Success, primary actions)
  - Orange: `#ff6b35` (Warnings, urgent items)
  - Blue: `#00d4ff` (Information, links)
- **Text Colors**:
  - Primary: `#e4e6ea` (Main text)
  - Secondary: `#a0a3bd` (Muted text)

### Typography
- **Primary Font**: System fonts (San Francisco, Segoe UI, Roboto)
- **Headings**: Bold weights with proper hierarchy
- **Body Text**: Regular weight, optimized for readability

### Components
- **Glassmorphism Cards**: Translucent backgrounds with backdrop blur
- **Neon Accents**: Glowing borders and highlights
- **Smooth Animations**: CSS transitions for better UX
- **Responsive Grid**: Flexible layouts for all screen sizes

## 🔧 Configuration

### Environment Variables (`.env`)
```env
PORT=5000
JWT_SECRET=your-secret-key-change-in-production
NODE_ENV=development
```

### Package Scripts
```json
{
  "start": "node server-simple.js",
  "start:server": "node server-simple.js",
  "start:frontend": "node serve-frontend.js",
  "create-data": "node data/sample-data.js",
  "dev": "npm run start:server & npm run start:frontend"
}
```

## 🚀 Deployment

### Production Setup

1. **Set environment variables**
   ```env
   NODE_ENV=production
   JWT_SECRET=your-secure-production-secret
   PORT=5000
   ```

2. **Install production dependencies**
   ```bash
   npm install --production
   ```

3. **Create initial data**
   ```bash
   npm run create-data
   ```

4. **Start the server**
   ```bash
   npm start
   ```

### Deployment Options
- **VPS/Cloud Server**: Deploy directly on Ubuntu/CentOS servers
- **Docker**: Containerize the application for easy deployment
- **Heroku**: Use Heroku's Node.js buildpack
- **Vercel/Netlify**: Deploy frontend separately with API backend

## 🔒 Security Features

- **Password Hashing**: bcrypt with salt rounds
- **JWT Authentication**: Secure token-based auth
- **Rate Limiting**: Prevent API abuse
- **Input Validation**: Comprehensive data validation
- **CORS Protection**: Controlled cross-origin access
- **Security Headers**: Helmet.js protection
- **File Upload Security**: Type and size validation

## 🧪 Testing

### Manual Testing Checklist

1. **User Registration/Login**
   - [ ] Register new user
   - [ ] Login with credentials
   - [ ] Invalid login handling

2. **Report Submission**
   - [ ] Submit report with all fields
   - [ ] Image upload functionality
   - [ ] GPS location detection
   - [ ] Form validation

3. **Dashboard Features**
   - [ ] Statistics display
   - [ ] Recent activity feed
   - [ ] Interactive map
   - [ ] Responsive design

4. **Community Page**
   - [ ] Report listing
   - [ ] Filtering and sorting
   - [ ] Search functionality
   - [ ] Pagination

5. **API Endpoints**
   - [ ] Health check
   - [ ] Reports CRUD operations
   - [ ] Authentication flow
   - [ ] Error handling

## 🐛 Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Kill process using port 5000
   netstat -ano | findstr :5000
   taskkill /PID <process-id> /F
   ```

2. **CORS Errors**
   - Ensure both servers are running
   - Check API_BASE_URL in `js/api.js`
   - Verify CORS configuration in server

3. **File Upload Issues**
   - Check file size limits (5MB max)
   - Verify file type restrictions
   - Ensure uploads directory exists

4. **Authentication Problems**
   - Clear localStorage tokens
   - Check JWT_SECRET configuration
   - Verify token expiration

### Debug Mode
Enable detailed logging by setting:
```env
NODE_ENV=development
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Code Style
- Use ES6+ features
- Follow consistent indentation (2 spaces)
- Add comments for complex logic
- Use meaningful variable names

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Leaflet.js** - Interactive mapping library
- **Font Awesome** - Icon library
- **Express.js** - Web framework
- **bcryptjs** - Password hashing
- **Kanpur Municipal Corporation** - Inspiration for civic engagement

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the API documentation

---

**CivicPulse** - Empowering citizens to build better communities through technology.