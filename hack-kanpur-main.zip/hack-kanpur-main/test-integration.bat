@echo off
echo ========================================
echo   Testing CivicPulse Integration
echo ========================================
echo.

REM Start server in background
echo Starting server...
start /min cmd /c "node server-simple.js"

REM Wait for server to start
timeout /t 3 /nobreak >nul

echo Opening CivicPulse application...
echo.
echo Testing URLs:
echo 1. Main Dashboard
start http://localhost:5000

timeout /t 2 /nobreak >nul

echo 2. Track Reports (Embedded)
start http://localhost:5000/track-reports-embedded.html

timeout /t 2 /nobreak >nul

echo 3. Kanpur Sewa Portal (Direct)
start http://localhost:5000/hackshood-hacthon

echo.
echo All applications should now be open in your browser.
echo.
echo Integration Features:
echo - Click "Track Reports" in the navbar to see embedded React app
echo - The React app loads inside the CivicPulse interface
echo - Both applications share the same server and authentication
echo.
pause