@echo off
echo Testing Location Preview Fix for CivicPulse...
echo.

echo 1. Starting server...
start "CivicPulse Server" cmd /k "node server-simple.js"

echo 2. Waiting for server to start...
timeout /t 3 /nobreak > nul

echo 3. Opening location preview test page...
start "" "http://localhost:5000/test-location-preview.html"

echo 4. Opening main dashboard for comparison...
start "" "http://localhost:5000"

echo.
echo Location Preview Fix Test:
echo ✅ Fixed popup formatting - no more jumbled text
echo ✅ Proper spacing and line breaks
echo ✅ Clear section headers and icons
echo ✅ Formatted coordinates display
echo ✅ Action buttons (Confirm/Cancel)
echo ✅ Enhanced visual styling
echo.
echo Test Instructions:
echo 1. Enter an address (e.g., "Mall Road, Kanpur")
echo 2. Click the orange preview button
echo 3. Check that popup shows properly formatted information
echo 4. Try the main dashboard report form as well
echo.
echo The preview popup should now display clean, readable information!
echo Press any key to continue...
pause > nul